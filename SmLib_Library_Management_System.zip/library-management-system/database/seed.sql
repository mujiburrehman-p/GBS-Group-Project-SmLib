-- =====================================================================
-- SmLib seed data (REQUIRED): default Admin account and system settings
-- Run AFTER schema.sql
-- Admin login:  username = admin   password = Admin@12345   (change it after first login!)
-- =====================================================================
USE library_db;

INSERT INTO users (user_id, username, password_hash, user_role, status, member_id, full_name, email)
VALUES ('U001', 'admin', '$2b$10$bv59KGt2MBEGfNKWVe4V/er6JFg3S05EkNS3ddT3/vKclJ456CCgS', 'Admin', 'Active', NULL, 'System Administrator', 'admin@smlib.co.uk');

INSERT INTO system_settings (setting_id, setting_key, setting_value, description, updated_by) VALUES
  ('ST01', 'loan_days',             '14',   'Number of days a book can be borrowed (also used for each renewal)', 'U001'),
  ('ST02', 'fine_per_day',          '0.50', 'Overdue fine charged per day',                                       'U001'),
  ('ST03', 'max_books_per_member',  '3',    'Maximum number of active loans per member',                          'U001'),
  ('ST04', 'max_renewals',          '1',    'Maximum number of renewals per loan',                                'U001'),
  ('ST05', 'reservation_hold_days', '3',    'Days a Ready reservation is held before it expires',                 'U001'),
  ('ST06', 'renewal_after_days',    '10',   'Days after the issue date before a book can be renewed',             'U001');
