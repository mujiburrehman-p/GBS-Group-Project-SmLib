-- SmLib (Smart Library) Management System - corrected database schema (v2)
-- Target: MySQL 8.0.16+
-- This script creates the schema and tables; it does not insert sample data.
--
-- Data store numbers (D1-D11) match the Level 0 DFD:
--   D1 Users, D2 Members, D3 Books, D4 Authors, D5 Publishers, D6 Categories,
--   D7 Loans, D8 Reservations, D9 Fines, D10 Damage_lost, D11 Settings.
-- Tables are created in dependency order (a table is created before any
-- table whose foreign keys point to it), so the order below differs from
-- the D-number order.
--
-- Changes in v2:
--   1. Fixed the waiver CHECK in fines and damage_lost ('Partially Waived'
--      was forced to equal the full amount; 'Not Waived' was not checked).
--   2. Renamed waiver value 'No Waived' -> 'Not Waived'.
--   3. Added paid_status 'Waived' for fully waived charges.
--   4. Paid/unpaid payment details are now checked both ways.
--   5. Added full_name and email to users (full_name required for Admin).
--   6. A 'Fulfilled' reservation must be linked to a loan.
--   7. last_renewed_on cannot be before issue_date.
--   8. D-numbers in comments now match the DFD; indentation tidied.
--   9. fines and damage_lost keep waiver_type ENUM('Not Waived','Partially Waived','Fully Waived');
--      payment_method is now ENUM('Cash','Card','No charge') (Waived rows use 'No charge');
--      paid_date is the settlement date: the payment date, or the saved date for a Waived or No charge row.
--  10. books.scrapped_copies added; chk_books_counts: total >= available + damaged + lost + scrapped.
--      Damaged, Scrapped and Lost each add to their own counter.
--  11. books.product_description (VARCHAR 255) and books.cover_page (LONGBLOB, the cover image) added.
--      The columns are part of this schema: load it into a fresh database (see DROP DATABASE below).
--
-- Important application-level rules not fully enforceable by these table
-- definitions alone are noted in comments below.
--
-- While testing, run this first so the new definitions are applied
-- (CREATE TABLE IF NOT EXISTS skips tables that already exist):
-- DROP DATABASE IF EXISTS library_db;

CREATE DATABASE IF NOT EXISTS library_db
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE library_db;

-- D2: members (created before users because users.member_id references it)
CREATE TABLE IF NOT EXISTS members (
  member_id    VARCHAR(10)  NOT NULL COMMENT 'Primary key, e.g. M001',
  id_no        VARCHAR(50)  NOT NULL COMMENT 'Student, staff, or librarian college ID',
  member_name  VARCHAR(120) NOT NULL,
  email        VARCHAR(120) NOT NULL,
  phone        VARCHAR(50)  NULL,
  address      VARCHAR(255) NULL,
  member_type  ENUM('Student','Staff','Librarian') NOT NULL,
  status       ENUM('Active','Inactive') NOT NULL DEFAULT 'Active',
  joined_date  DATE NOT NULL DEFAULT (CURRENT_DATE),
  expiry_date  DATE NULL COMMENT 'Membership end date: current date when set Inactive, NULL when set Active',
  PRIMARY KEY (member_id),
  UNIQUE KEY uq_members_id_no (id_no),
  UNIQUE KEY uq_members_email (email),
  CONSTRAINT chk_members_expiry
    CHECK (expiry_date IS NULL OR expiry_date >= joined_date)
) ENGINE=InnoDB;

-- D1: users (login accounts for Admin, Librarian, Member)
-- Application rule: user_role must match the linked member's member_type
-- (role 'Librarian' -> member_type 'Librarian'; role 'Member' ->
-- member_type 'Student' or 'Staff'). Check this in application logic or a
-- trigger, because a CHECK constraint cannot read another table.
CREATE TABLE IF NOT EXISTS users (
  user_id       VARCHAR(10)  NOT NULL COMMENT 'Primary key, e.g. U001',
  username      VARCHAR(50)  NOT NULL,
  password_hash VARCHAR(255) NOT NULL COMMENT 'Store a password hash, never plaintext',
  user_role     ENUM('Admin','Librarian','Member') NOT NULL,
  status        ENUM('Active','Inactive') NOT NULL DEFAULT 'Active',
  member_id     VARCHAR(10)  NULL COMMENT 'Required for Member/Librarian; NULL for Admin',
  full_name     VARCHAR(120) NULL COMMENT 'Required for Admin (Admin has no members row)',
  email         VARCHAR(120) NULL,
  created_date  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (user_id),
  UNIQUE KEY uq_users_username (username),
  UNIQUE KEY uq_users_member_id (member_id),
  UNIQUE KEY uq_users_email (email),
  CONSTRAINT fk_users_member
    FOREIGN KEY (member_id) REFERENCES members(member_id),
  CONSTRAINT chk_users_member_role
    CHECK (
      (user_role IN ('Member','Librarian') AND member_id IS NOT NULL)
      OR (user_role = 'Admin' AND member_id IS NULL)
    ),
  CONSTRAINT chk_users_admin_name
    CHECK (user_role <> 'Admin' OR full_name IS NOT NULL)
) ENGINE=InnoDB;

-- D6: categories
CREATE TABLE IF NOT EXISTS categories (
  category_id   VARCHAR(10)  NOT NULL COMMENT 'Primary key, e.g. C001',
  category_name VARCHAR(80)  NOT NULL,
  description   VARCHAR(255) NULL,
  created_by    VARCHAR(10)  NOT NULL,
  created_date  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (category_id),
  UNIQUE KEY uq_categories_name (category_name),
  CONSTRAINT fk_categories_created_by
    FOREIGN KEY (created_by) REFERENCES users(user_id)
) ENGINE=InnoDB;

-- D5: publishers
CREATE TABLE IF NOT EXISTS publishers (
  publisher_id   VARCHAR(10)  NOT NULL COMMENT 'Primary key, e.g. P001',
  publisher_name VARCHAR(120) NOT NULL,
  address        VARCHAR(200) NULL,
  email          VARCHAR(120) NULL,
  phone          VARCHAR(50)  NULL,
  created_by     VARCHAR(10)  NOT NULL,
  created_date   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (publisher_id),
  UNIQUE KEY uq_publishers_name (publisher_name),
  CONSTRAINT fk_publishers_created_by
    FOREIGN KEY (created_by) REFERENCES users(user_id)
) ENGINE=InnoDB;

-- D4: authors
CREATE TABLE IF NOT EXISTS authors (
  author_id    VARCHAR(10)  NOT NULL COMMENT 'Primary key, e.g. A001',
  author_name  VARCHAR(255) NOT NULL,
  description  VARCHAR(255) NULL,
  created_by   VARCHAR(10)  NOT NULL,
  created_date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (author_id),
  CONSTRAINT fk_authors_created_by
    FOREIGN KEY (created_by) REFERENCES users(user_id)
) ENGINE=InnoDB;

-- D3: books
-- Issued copies are derived from active loans rather than stored.
-- Intended inventory rule: total = available + issued + damaged + lost.
-- Design limitation: one author per book (author_id). Supporting several
-- authors would need a book_authors link table.
CREATE TABLE IF NOT EXISTS books (
  book_id          VARCHAR(10)  NOT NULL COMMENT 'Primary key, e.g. B001',
  title            VARCHAR(200) NOT NULL,
  isbn             VARCHAR(20)  NULL,
  author_id        VARCHAR(10)  NOT NULL,
  publisher_id     VARCHAR(10)  NOT NULL,
  category_id      VARCHAR(10)  NOT NULL,
  publish_year     INT          NULL,
  edition          VARCHAR(100) NULL,
  price            DECIMAL(8,2) NULL COMMENT 'Suggested replacement cost',
  shelf_location   VARCHAR(30)  NULL COMMENT 'Shelf code, e.g. A-01',
  product_description VARCHAR(255) NULL COMMENT 'Short description of the book shown in the catalogue',
  cover_page       LONGBLOB     NULL COMMENT 'Cover image (PNG, JPEG, GIF or WEBP, max 2 MB). MySQL has no IMAGE type: images are binary data',
  total_copies     INT NOT NULL DEFAULT 1,
  available_copies INT NOT NULL DEFAULT 1 COMMENT 'Copies on the shelf; includes copies held for Ready reservations (issuable = available - held)',
  damaged_copies   INT NOT NULL DEFAULT 0 COMMENT 'Copies recorded as Damaged',
  lost_copies      INT NOT NULL DEFAULT 0 COMMENT 'Copies recorded as Lost',
  scrapped_copies  INT NOT NULL DEFAULT 0 COMMENT 'Copies recorded as Scrapped (removed from circulation)',
  created_by       VARCHAR(10)  NOT NULL,
  created_date     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (book_id),
  UNIQUE KEY uq_books_isbn (isbn),
  CONSTRAINT fk_books_author
    FOREIGN KEY (author_id) REFERENCES authors(author_id),
  CONSTRAINT fk_books_publisher
    FOREIGN KEY (publisher_id) REFERENCES publishers(publisher_id),
  CONSTRAINT fk_books_category
    FOREIGN KEY (category_id) REFERENCES categories(category_id),
  CONSTRAINT fk_books_created_by
    FOREIGN KEY (created_by) REFERENCES users(user_id),
  CONSTRAINT chk_books_counts
    CHECK (
      total_copies >= 0
      AND available_copies >= 0
      AND damaged_copies >= 0
      AND lost_copies >= 0
      AND scrapped_copies >= 0
      AND total_copies >= (available_copies + damaged_copies + lost_copies + scrapped_copies)
    ),
  CONSTRAINT chk_books_price
    CHECK (price IS NULL OR price >= 0)
) ENGINE=InnoDB;

-- D7: loans
-- Business rule: issued_by should be Admin if the borrower is a Librarian,
-- otherwise Librarian. Enforce this in application logic or a trigger.
CREATE TABLE IF NOT EXISTS loans (
  loan_id         VARCHAR(10) NOT NULL COMMENT 'Primary key, e.g. L001',
  member_id       VARCHAR(10) NOT NULL,
  book_id         VARCHAR(10) NOT NULL,
  issue_date      DATE NOT NULL,
  due_date        DATE NOT NULL COMMENT 'Calculated using the configured loan period',
  return_date     DATE NULL COMMENT 'Date the book came back (Returned) or the date it was recorded as lost (Lost); NULL while Issued',
  status          ENUM('Issued','Returned','Lost') NOT NULL DEFAULT 'Issued',
  renewal_count   INT NOT NULL DEFAULT 0,
  last_renewed_on DATE NULL,
  issued_by       VARCHAR(10) NOT NULL,
  returned_to     VARCHAR(10) NULL,
  PRIMARY KEY (loan_id),
  KEY idx_loans_member (member_id, status),
  KEY idx_loans_book (book_id, status),
  CONSTRAINT fk_loans_member
    FOREIGN KEY (member_id) REFERENCES members(member_id),
  CONSTRAINT fk_loans_book
    FOREIGN KEY (book_id) REFERENCES books(book_id),
  CONSTRAINT fk_loans_issued_by
    FOREIGN KEY (issued_by) REFERENCES users(user_id),
  CONSTRAINT fk_loans_returned_to
    FOREIGN KEY (returned_to) REFERENCES users(user_id),
  CONSTRAINT chk_loans_dates
    CHECK (due_date >= issue_date AND (return_date IS NULL OR return_date >= issue_date)),
  CONSTRAINT chk_loans_renewal
    CHECK (
      renewal_count >= 0
      AND (
        (renewal_count = 0 AND last_renewed_on IS NULL)
        OR (renewal_count > 0 AND last_renewed_on IS NOT NULL AND last_renewed_on >= issue_date)
      )
    ),
  CONSTRAINT chk_loans_return
    CHECK ((status <> 'Returned' OR (return_date IS NOT NULL AND returned_to IS NOT NULL))
           AND (status <> 'Lost' OR return_date IS NOT NULL))
) ENGINE=InnoDB;

-- D9: fines (one overdue fine per loan)
-- net_amount is generated so it cannot become inconsistent with the fine
-- and waived amounts. Do not insert/update net_amount directly.
-- Application rule: only create a fine for a loan that was returned late
-- (return_date > due_date) or is still out past its due_date.
CREATE TABLE IF NOT EXISTS fines (
  fine_id        VARCHAR(10)  NOT NULL COMMENT 'Primary key, e.g. F001',
  loan_id        VARCHAR(10)  NOT NULL,
  fine_amount    DECIMAL(8,2) NOT NULL DEFAULT 0.00,
  waived_amount  DECIMAL(8,2) NOT NULL DEFAULT 0.00,
  net_amount     DECIMAL(8,2) GENERATED ALWAYS AS (fine_amount - waived_amount) STORED,
  paid_status    ENUM('Unpaid','Paid','Waived') NOT NULL DEFAULT 'Unpaid',
  waiver_type    ENUM('Not Waived','Partially Waived','Fully Waived') NOT NULL DEFAULT 'Not Waived',
  fine_date      DATE NOT NULL DEFAULT (CURRENT_DATE),
  paid_date      DATE NULL COMMENT 'Payment date; for a Fully Waived or No charge row it is the date that was saved',
  payment_method ENUM('Cash','Card','No charge') NULL,
  remark         VARCHAR(255) NULL,
  created_by     VARCHAR(10)  NOT NULL,
  PRIMARY KEY (fine_id),
  UNIQUE KEY uq_fines_loan_id (loan_id),
  CONSTRAINT fk_fines_loan
    FOREIGN KEY (loan_id) REFERENCES loans(loan_id),
  CONSTRAINT fk_fines_created_by
    FOREIGN KEY (created_by) REFERENCES users(user_id),
  CONSTRAINT chk_fines_amounts
    CHECK (fine_amount >= 0 AND waived_amount >= 0 AND waived_amount <= fine_amount),
  CONSTRAINT chk_fines_waiver
    CHECK (
      (waiver_type = 'Not Waived'          AND waived_amount = 0)
      OR (waiver_type = 'Partially Waived' AND waived_amount > 0 AND waived_amount < fine_amount)
      OR (waiver_type = 'Fully Waived'     AND waived_amount = fine_amount)
    ),
  CONSTRAINT chk_fines_waived_status
    CHECK ((paid_status = 'Waived') = (waiver_type = 'Fully Waived')),
  CONSTRAINT chk_fines_paid
    CHECK (
      (paid_status = 'Paid'   AND paid_date IS NOT NULL AND payment_method IN ('Cash','Card'))
      OR (paid_status = 'Waived' AND paid_date IS NOT NULL AND payment_method = 'No charge')
      OR (paid_status = 'Unpaid' AND paid_date IS NULL AND payment_method IS NULL)
    )
) ENGINE=InnoDB;

-- D10: damage_lost
-- damage_type Damaged  -> books.damaged_copies  + 1
-- damage_type Lost     -> books.lost_copies     + 1  (a borrowed copy also marks its loan Lost)
-- damage_type Scrapped -> books.scrapped_copies + 1
-- The copy leaves available_copies (shelf copy) or its loan (borrowed copy) and the rule
--   total_copies >= available_copies + damaged_copies + lost_copies + scrapped_copies
-- is checked by the application before saving (damage_service.record) and enforced by chk_books_counts.
-- net_amount is generated for consistency.
-- Application rule: when loan_id is given, member_id must be the member on
-- that loan.
CREATE TABLE IF NOT EXISTS damage_lost (
  damage_id      VARCHAR(10)  NOT NULL COMMENT 'Primary key, e.g. DL001',
  book_id        VARCHAR(10)  NOT NULL,
  loan_id        VARCHAR(10)  NULL COMMENT 'NULL if no loan was involved',
  member_id      VARCHAR(10)  NULL COMMENT 'NULL if no member is charged',
  amount         DECIMAL(8,2) NOT NULL DEFAULT 0.00,
  waived_amount  DECIMAL(8,2) NOT NULL DEFAULT 0.00,
  net_amount     DECIMAL(8,2) GENERATED ALWAYS AS (amount - waived_amount) STORED,
  paid_status    ENUM('Unpaid','Paid','Waived') NOT NULL DEFAULT 'Unpaid',
  waiver_type    ENUM('Not Waived','Partially Waived','Fully Waived') NOT NULL DEFAULT 'Not Waived',
  record_date    DATE NOT NULL DEFAULT (CURRENT_DATE),
  paid_date      DATE NULL COMMENT 'Payment date; for a Fully Waived or No charge row it is the date that was saved',
  damage_type    ENUM('Damaged','Scrapped','Lost') NOT NULL,
  payment_method ENUM('Cash','Card','No charge') NULL,
  remark         VARCHAR(255) NULL,
  created_by     VARCHAR(10)  NOT NULL,
  PRIMARY KEY (damage_id),
  KEY idx_dl_book (book_id),
  KEY idx_dl_loan (loan_id),
  KEY idx_dl_member (member_id),
  CONSTRAINT fk_dl_book
    FOREIGN KEY (book_id) REFERENCES books(book_id),
  CONSTRAINT fk_dl_loan
    FOREIGN KEY (loan_id) REFERENCES loans(loan_id),
  CONSTRAINT fk_dl_member
    FOREIGN KEY (member_id) REFERENCES members(member_id),
  CONSTRAINT fk_dl_created_by
    FOREIGN KEY (created_by) REFERENCES users(user_id),
  CONSTRAINT chk_dl_amounts
    CHECK (amount >= 0 AND waived_amount >= 0 AND waived_amount <= amount),
  CONSTRAINT chk_dl_waiver
    CHECK (
      (waiver_type = 'Not Waived'          AND waived_amount = 0)
      OR (waiver_type = 'Partially Waived' AND waived_amount > 0 AND waived_amount < amount)
      OR (waiver_type = 'Fully Waived'     AND waived_amount = amount)
    ),
  CONSTRAINT chk_dl_waived_status
    CHECK ((paid_status = 'Waived') = (waiver_type = 'Fully Waived')),
  CONSTRAINT chk_dl_paid
    CHECK (
      (paid_status = 'Paid'   AND paid_date IS NOT NULL AND payment_method IN ('Cash','Card'))
      OR (paid_status = 'Waived' AND paid_date IS NOT NULL AND payment_method = 'No charge')
      OR (paid_status = 'Unpaid' AND paid_date IS NULL AND payment_method IS NULL)
      OR (paid_status = 'Unpaid' AND paid_date IS NOT NULL AND payment_method = 'No charge' AND amount = 0)
    ),
  CONSTRAINT chk_dl_charge_link
    CHECK (
      (loan_id IS NULL AND member_id IS NULL)
      OR (loan_id IS NOT NULL AND member_id IS NOT NULL)
    )
) ENGINE=InnoDB;

-- D8: reservations
-- Rule: one active (Pending/Ready) reservation per member per book.
-- This conditional uniqueness rule needs application logic or triggers;
-- a regular UNIQUE key cannot enforce it only for selected status values.
CREATE TABLE IF NOT EXISTS reservations (
  reservation_id   VARCHAR(10) NOT NULL COMMENT 'Primary key, e.g. R001',
  member_id        VARCHAR(10) NOT NULL,
  book_id          VARCHAR(10) NOT NULL,
  reservation_date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  status           ENUM('Pending','Ready','Fulfilled','Cancelled','Expired') NOT NULL DEFAULT 'Pending',
  expiry_date      DATE NULL,
  loan_id          VARCHAR(10) NULL COMMENT 'Set when the reservation becomes a loan',
  PRIMARY KEY (reservation_id),
  KEY idx_reservations_member_book_status (member_id, book_id, status),
  CONSTRAINT fk_reservations_member
    FOREIGN KEY (member_id) REFERENCES members(member_id),
  CONSTRAINT fk_reservations_book
    FOREIGN KEY (book_id) REFERENCES books(book_id),
  CONSTRAINT fk_reservations_loan
    FOREIGN KEY (loan_id) REFERENCES loans(loan_id),
  CONSTRAINT chk_reservations_ready_expiry
    CHECK (status <> 'Ready' OR expiry_date IS NOT NULL),
  CONSTRAINT chk_reservations_fulfilled
    CHECK (status <> 'Fulfilled' OR loan_id IS NOT NULL)
) ENGINE=InnoDB;

-- D11: system_settings
CREATE TABLE IF NOT EXISTS system_settings (
  setting_id    VARCHAR(10)  NOT NULL COMMENT 'Primary key, e.g. ST01',
  setting_key   VARCHAR(100) NOT NULL,
  setting_value VARCHAR(100) NOT NULL,
  description   VARCHAR(255) NULL,
  updated_by    VARCHAR(10)  NOT NULL,
  updated_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (setting_id),
  UNIQUE KEY uq_system_settings_key (setting_key),
  CONSTRAINT fk_system_settings_updated_by
    FOREIGN KEY (updated_by) REFERENCES users(user_id)
) ENGINE=InnoDB;
