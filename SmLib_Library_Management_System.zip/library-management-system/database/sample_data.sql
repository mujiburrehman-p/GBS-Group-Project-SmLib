-- =====================================================================
-- SmLib sample / test data (OPTIONAL). Run AFTER schema.sql and seed.sql.
-- ALL data is fictitious. Every e-mail address ends in @smlib.co.uk.
-- All dates are relative to the day you load it (CURDATE() +/- days), so
-- "overdue", "due soon" and "expires" always behave as described.
--
-- LOGINS
--   admin    (Admin@12345)                       -> seed.sql
--   Librarians (Librarian@123): mujibur, wasim
--   Staff (Member@123):         abigel, timothy, kelvin
--   Students (Member@123):      yakken, lutifyah, tahsin, irfan, oliver, george
--   emily    (Member@123) -> INACTIVE account (login must be refused)
--   harry    (Member@123) -> membership EXPIRED (cannot borrow)
--   Charlotte Brown (M013) -> member WITHOUT a login
--   george   (Member@123) -> member with NO loans
--   14 members = 2 Librarian + 3 Staff + 9 Student; plus the Admin user
--
-- DATA VOLUME: 5 categories, 5 authors, 5 publishers, 30 books,
--   34 loans, 6 reservations, 10 fines, 7 damaged / lost / scrapped records
-- =====================================================================

USE library_db;

-- ---------- D2 members ----------
INSERT INTO members (member_id, id_no, member_name, email, phone, address, member_type, status, joined_date, expiry_date) VALUES
  ('M001','LIB-001','Mujibur Rehman','mujibur.rehman@smlib.co.uk','07700 900001','2 College Street','Librarian','Active',(CURDATE() - INTERVAL 300 DAY),NULL),
  ('M002','LIB-002','Wasim Khan Raja','wasim.khan.raja@smlib.co.uk','07700 900002','3 College Street','Librarian','Active',(CURDATE() - INTERVAL 290 DAY),NULL),
  ('M003','STF1001','Abigel Sara Fosu','abigel.sara.fosu@smlib.co.uk','07700 900003','4 College Street','Staff','Active',(CURDATE() - INTERVAL 280 DAY),NULL),
  ('M004','STF1002','Timothy Anthony Shakespeare','timothy.anthony.shakespeare@smlib.co.uk','07700 900004','5 College Street','Staff','Active',(CURDATE() - INTERVAL 270 DAY),NULL),
  ('M005','STF1003','Kelvin Gibbah','kelvin.gibbah@smlib.co.uk','07700 900005','6 College Street','Staff','Active',(CURDATE() - INTERVAL 260 DAY),NULL),
  ('M006','STU2026001','Yakken Ahmed','yakken.ahmed@smlib.co.uk','07700 900006','7 College Street','Student','Active',(CURDATE() - INTERVAL 200 DAY),NULL),
  ('M007','STU2026002','Lutifyah Begum','lutifyah.begum@smlib.co.uk','07700 900007','8 College Street','Student','Active',(CURDATE() - INTERVAL 199 DAY),NULL),
  ('M008','STU2026003','Tahsin Islam','tahsin.islam@smlib.co.uk','07700 900008','9 College Street','Student','Active',(CURDATE() - INTERVAL 198 DAY),NULL),
  ('M009','STU2026004','Irfan Hussain','irfan.hussain@smlib.co.uk','07700 900009','10 College Street','Student','Active',(CURDATE() - INTERVAL 197 DAY),NULL),
  ('M010','STU2026005','Oliver Smith','oliver.smith@smlib.co.uk','07700 900010','11 College Street','Student','Active',(CURDATE() - INTERVAL 150 DAY),(CURDATE() + INTERVAL 180 DAY)),
  ('M011','STU2026006','Emily Johnson','emily.johnson@smlib.co.uk','07700 900011','12 College Street','Student','Inactive',(CURDATE() - INTERVAL 250 DAY),(CURDATE() - INTERVAL 30 DAY)),
  ('M012','STU2026007','Harry Williams','harry.williams@smlib.co.uk','07700 900012','13 College Street','Student','Active',(CURDATE() - INTERVAL 400 DAY),(CURDATE() - INTERVAL 30 DAY)),
  ('M013','STU2026008','Charlotte Brown','charlotte.brown@smlib.co.uk',NULL,NULL,'Student','Active',(CURDATE() - INTERVAL 100 DAY),NULL),
  ('M014','STU2026009','George Taylor','george.taylor@smlib.co.uk','07700 900014','15 College Street','Student','Active',(CURDATE() - INTERVAL 60 DAY),NULL);

-- ---------- D1 users (admin U001 is in seed.sql; Charlotte Brown M013 has NO login) ----------
INSERT INTO users (user_id, username, password_hash, user_role, status, member_id) VALUES
  ('U002','mujibur','$2b$10$4atuuKr6S0AUrq7Cn1rogukPUZsu2GkBzya60b4xkU0HFWHNKxC42','Librarian','Active','M001'),
  ('U003','wasim','$2b$10$4atuuKr6S0AUrq7Cn1rogukPUZsu2GkBzya60b4xkU0HFWHNKxC42','Librarian','Active','M002'),
  ('U004','abigel','$2b$10$d0U9acRKHZQR8XlgG1a/ZeFTMEtlcZKHqNkSrYiZcvrCv8SYZlS8i','Member','Active','M003'),
  ('U005','timothy','$2b$10$d0U9acRKHZQR8XlgG1a/ZeFTMEtlcZKHqNkSrYiZcvrCv8SYZlS8i','Member','Active','M004'),
  ('U006','kelvin','$2b$10$d0U9acRKHZQR8XlgG1a/ZeFTMEtlcZKHqNkSrYiZcvrCv8SYZlS8i','Member','Active','M005'),
  ('U007','yakken','$2b$10$d0U9acRKHZQR8XlgG1a/ZeFTMEtlcZKHqNkSrYiZcvrCv8SYZlS8i','Member','Active','M006'),
  ('U008','lutifyah','$2b$10$d0U9acRKHZQR8XlgG1a/ZeFTMEtlcZKHqNkSrYiZcvrCv8SYZlS8i','Member','Active','M007'),
  ('U009','tahsin','$2b$10$d0U9acRKHZQR8XlgG1a/ZeFTMEtlcZKHqNkSrYiZcvrCv8SYZlS8i','Member','Active','M008'),
  ('U010','irfan','$2b$10$d0U9acRKHZQR8XlgG1a/ZeFTMEtlcZKHqNkSrYiZcvrCv8SYZlS8i','Member','Active','M009'),
  ('U011','oliver','$2b$10$d0U9acRKHZQR8XlgG1a/ZeFTMEtlcZKHqNkSrYiZcvrCv8SYZlS8i','Member','Active','M010'),
  ('U012','emily','$2b$10$d0U9acRKHZQR8XlgG1a/ZeFTMEtlcZKHqNkSrYiZcvrCv8SYZlS8i','Member','Inactive','M011'),
  ('U013','harry','$2b$10$d0U9acRKHZQR8XlgG1a/ZeFTMEtlcZKHqNkSrYiZcvrCv8SYZlS8i','Member','Active','M012'),
  ('U014','george','$2b$10$d0U9acRKHZQR8XlgG1a/ZeFTMEtlcZKHqNkSrYiZcvrCv8SYZlS8i','Member','Active','M014');

-- ---------- D6 categories ----------
INSERT INTO categories (category_id, category_name, description, created_by) VALUES
  ('C001','Computer Science','Programming, databases and software testing','U002'),
  ('C002','Mathematics','Algebra, calculus, statistics and geometry','U002'),
  ('C003','Fiction','Novels and short stories','U002'),
  ('C004','Business','Management, marketing and finance','U002'),
  ('C005','Science','Physics, chemistry, biology and earth science','U002');

-- ---------- D5 publishers ----------
INSERT INTO publishers (publisher_id, publisher_name, address, email, phone, created_by) VALUES
  ('P001','Northbridge Press','London, UK','northbridge@smlib.co.uk','020 7000 0001','U002'),
  ('P002','Kingsway Publishing','Manchester, UK','kingsway@smlib.co.uk','0161 000 0002','U002'),
  ('P003','Riverside Books','Bristol, UK','riverside@smlib.co.uk','0117 000 0003','U002'),
  ('P004','Oakfield Academic','Oxford, UK','oakfield@smlib.co.uk','01865 000004','U002'),
  ('P005','Harbour and Gate','Edinburgh, UK','harbourgate@smlib.co.uk','0131 000 0005','U002');

-- ---------- D4 authors ----------
INSERT INTO authors (author_id, author_name, description, created_by) VALUES
  ('A001','Alan Whitmore','Computing lecturer and textbook author','U002'),
  ('A002','Helen Carter','Mathematics teacher and author','U002'),
  ('A003','James Holloway','English novelist','U002'),
  ('A004','Margaret Ellison','Business and finance writer','U002'),
  ('A005','Robert Hargreaves','Science writer and educator','U002');

-- ---------- D3 books (total = available + on loan + damaged + lost + scrapped) ----------
INSERT INTO books (book_id,title,isbn,author_id,publisher_id,category_id,publish_year,edition,price,shelf_location,product_description,total_copies,available_copies,damaged_copies,lost_copies,scrapped_copies,created_by) VALUES
  ('B001','Introduction to Database Design','9781000000001','A001','P001','C001',2016,'2nd',16.49,'A-01','Fictitious sample book: Introduction to Database Design.',3,2,1,0,0,'U002'),
  ('B002','Practical SQL for Beginners','9781000000002','A001','P002','C001',2017,'3rd',22.99,'A-02','Fictitious sample book: Practical SQL for Beginners.',3,2,1,0,0,'U002'),
  ('B003','Python Programming Essentials','9781000000003','A001','P003','C001',2018,'1st',30.49,'A-03','Fictitious sample book: Python Programming Essentials.',3,1,1,0,0,'U002'),
  ('B004','Web Development with Flask','9781000000004','A001','P004','C001',2019,'2nd',36.99,'A-04','Fictitious sample book: Web Development with Flask.',2,2,0,0,0,'U002'),
  ('B005','Software Testing Fundamentals','9781000000005','A001','P005','C001',2020,'3rd',44.49,'A-05','Fictitious sample book: Software Testing Fundamentals.',2,2,0,0,0,'U002'),
  ('B006','Data Structures Made Simple','9781000000006','A001','P001','C001',2021,'1st',10.99,'A-06','Fictitious sample book: Data Structures Made Simple.',2,2,0,0,0,'U002'),
  ('B007','Foundations of Algebra','9781000000007','A002','P002','C002',2022,'2nd',18.49,'B-01','Fictitious sample book: Foundations of Algebra.',2,2,0,0,0,'U002'),
  ('B008','Calculus Step by Step','9781000000008','A002','P003','C002',2023,'3rd',24.99,'B-02','Fictitious sample book: Calculus Step by Step.',2,2,0,0,0,'U002'),
  ('B009','Statistics for Everyday Life','9781000000009','A002','P004','C002',2024,'1st',32.49,'B-03','Fictitious sample book: Statistics for Everyday Life.',3,2,0,0,1,'U002'),
  ('B010','Discrete Mathematics','9781000000010','A002','P005','C002',2015,'2nd',38.99,'B-04','Fictitious sample book: Discrete Mathematics.',3,2,0,0,1,'U002'),
  ('B011','Geometry and Trigonometry','9781000000011','A002','P001','C002',2016,'3rd',46.49,'B-05','Fictitious sample book: Geometry and Trigonometry.',2,2,0,0,0,'U002'),
  ('B012','Probability Explained','9781000000012','A002','P002','C002',2017,'1st',12.99,'B-06','Fictitious sample book: Probability Explained.',2,2,0,0,0,'U002'),
  ('B013','The Silent Harbour','9781000000013','A003','P003','C003',2018,'2nd',20.49,'C-01','Fictitious sample book: The Silent Harbour.',2,2,0,0,0,'U002'),
  ('B014','Letters from Marlow Street','9781000000014','A003','P004','C003',2019,'3rd',26.99,'C-02','Fictitious sample book: Letters from Marlow Street.',2,2,0,0,0,'U002'),
  ('B015','The Last Lighthouse Keeper','9781000000015','A003','P005','C003',2020,'1st',34.49,'C-03','Fictitious sample book: The Last Lighthouse Keeper.',2,2,0,0,0,'U002'),
  ('B016','A Winter in Kingsbridge','9781000000016','A003','P001','C003',2021,'2nd',40.99,'C-04','Fictitious sample book: A Winter in Kingsbridge.',2,2,0,0,0,'U002'),
  ('B017','The Clockmakers Daughter','9781000000017','A003','P002','C003',2022,'3rd',48.49,'C-05','Fictitious sample book: The Clockmakers Daughter.',2,2,0,0,0,'U002'),
  ('B018','Beyond the Moorland',NULL,'A003','P003','C003',2023,NULL,14.99,'R-01','Fictitious sample book: Beyond the Moorland.',2,2,0,0,0,'U002'),
  ('B019','Starting a Small Business','9781000000019','A004','P004','C004',2024,'2nd',22.49,'D-01','Fictitious sample book: Starting a Small Business.',3,2,0,1,0,'U002'),
  ('B020','Principles of Marketing','9781000000020','A004','P005','C004',2015,'3rd',28.99,'D-02','Fictitious sample book: Principles of Marketing.',3,2,0,1,0,'U002'),
  ('B021','Managing People and Teams','9781000000021','A004','P001','C004',2016,'1st',36.49,'D-03','Fictitious sample book: Managing People and Teams.',3,2,0,0,0,'U002'),
  ('B022','Personal Finance Basics','9781000000022','A004','P002','C004',2017,'2nd',42.99,'D-04','Fictitious sample book: Personal Finance Basics.',3,2,0,0,0,'U002'),
  ('B023','Project Management in Practice','9781000000023','A004','P003','C004',2018,'3rd',10.49,'D-05','Fictitious sample book: Project Management in Practice.',3,2,0,0,0,'U002'),
  ('B024','Understanding Accounting','9781000000024','A004','P004','C004',2019,'1st',16.99,'D-06','Fictitious sample book: Understanding Accounting.',3,2,0,0,0,'U002'),
  ('B025','Physics in Everyday Life','9781000000025','A005','P005','C005',2020,'2nd',24.49,'E-01','Fictitious sample book: Physics in Everyday Life.',3,2,0,0,0,'U002'),
  ('B026','Chemistry Fundamentals','9781000000026','A005','P001','C005',2021,'3rd',30.99,'E-02','Fictitious sample book: Chemistry Fundamentals.',3,2,0,0,0,'U002'),
  ('B027','Introduction to Biology','9781000000027','A005','P002','C005',2022,'1st',38.49,'E-03','Fictitious sample book: Introduction to Biology.',3,2,0,0,0,'U002'),
  ('B028','The Earth and Its Climate','9781000000028','A005','P003','C005',2023,'2nd',44.99,'E-04','Fictitious sample book: The Earth and Its Climate.',3,2,0,0,0,'U002'),
  ('B029','Exploring the Solar System','9781000000029','A005','P004','C005',2024,'3rd',12.49,'E-05','Fictitious sample book: Exploring the Solar System.',1,0,0,0,0,'U002'),
  ('B030','Energy and the Environment','9781000000030','A005','P005','C005',2015,'1st',18.99,'E-06','Fictitious sample book: Energy and the Environment.',2,1,0,0,0,'U002');

-- ---------- D7 loans ----------
INSERT INTO loans (loan_id, member_id, book_id, issue_date, due_date, return_date, status, renewal_count, last_renewed_on, issued_by, returned_to) VALUES
  ('L001','M006','B001',(CURDATE() - INTERVAL 60 DAY),(CURDATE() - INTERVAL 46 DAY),(CURDATE() - INTERVAL 36 DAY),'Returned',0,NULL,'U002','U002'),
  ('L002','M007','B002',(CURDATE() - INTERVAL 80 DAY),(CURDATE() - INTERVAL 66 DAY),(CURDATE() - INTERVAL 56 DAY),'Returned',0,NULL,'U003','U003'),
  ('L003','M003','B003',(CURDATE() - INTERVAL 70 DAY),(CURDATE() - INTERVAL 56 DAY),(CURDATE() - INTERVAL 49 DAY),'Returned',0,NULL,'U002','U002'),
  ('L004','M006','B004',(CURDATE() - INTERVAL 50 DAY),(CURDATE() - INTERVAL 36 DAY),(CURDATE() - INTERVAL 24 DAY),'Returned',0,NULL,'U003','U003'),
  ('L005','M008','B005',(CURDATE() - INTERVAL 45 DAY),(CURDATE() - INTERVAL 31 DAY),(CURDATE() - INTERVAL 21 DAY),'Returned',0,NULL,'U002','U002'),
  ('L006','M004','B006',(CURDATE() - INTERVAL 40 DAY),(CURDATE() - INTERVAL 26 DAY),(CURDATE() - INTERVAL 12 DAY),'Returned',0,NULL,'U003','U003'),
  ('L007','M009','B007',(CURDATE() - INTERVAL 35 DAY),(CURDATE() - INTERVAL 21 DAY),(CURDATE() - INTERVAL 11 DAY),'Returned',0,NULL,'U002','U002'),
  ('L008','M010','B008',(CURDATE() - INTERVAL 30 DAY),(CURDATE() - INTERVAL 16 DAY),(CURDATE() - INTERVAL 8 DAY),'Returned',0,NULL,'U003','U003'),
  ('L009','M005','B009',(CURDATE() - INTERVAL 45 DAY),(CURDATE() - INTERVAL 31 DAY),(CURDATE() - INTERVAL 28 DAY),'Returned',0,NULL,'U002','U002'),
  ('L010','M001','B010',(CURDATE() - INTERVAL 25 DAY),(CURDATE() - INTERVAL 11 DAY),(CURDATE() - INTERVAL 9 DAY),'Returned',0,NULL,'U001','U001'),
  ('L011','M006','B011',(CURDATE() - INTERVAL 30 DAY),(CURDATE() - INTERVAL 16 DAY),(CURDATE() - INTERVAL 20 DAY),'Returned',0,NULL,'U002','U002'),
  ('L012','M007','B012',(CURDATE() - INTERVAL 28 DAY),(CURDATE() - INTERVAL 14 DAY),(CURDATE() - INTERVAL 16 DAY),'Returned',0,NULL,'U003','U003'),
  ('L013','M008','B013',(CURDATE() - INTERVAL 27 DAY),(CURDATE() - INTERVAL 13 DAY),(CURDATE() - INTERVAL 15 DAY),'Returned',0,NULL,'U002','U002'),
  ('L014','M009','B014',(CURDATE() - INTERVAL 26 DAY),(CURDATE() - INTERVAL 12 DAY),(CURDATE() - INTERVAL 14 DAY),'Returned',0,NULL,'U003','U003'),
  ('L015','M010','B015',(CURDATE() - INTERVAL 24 DAY),(CURDATE() - INTERVAL 10 DAY),(CURDATE() - INTERVAL 12 DAY),'Returned',0,NULL,'U002','U002'),
  ('L016','M002','B016',(CURDATE() - INTERVAL 22 DAY),(CURDATE() - INTERVAL 8 DAY),(CURDATE() - INTERVAL 10 DAY),'Returned',0,NULL,'U001','U001'),
  ('L017','M003','B017',(CURDATE() - INTERVAL 20 DAY),(CURDATE() - INTERVAL 6 DAY),(CURDATE() - INTERVAL 8 DAY),'Returned',0,NULL,'U003','U003'),
  ('L018','M004','B018',(CURDATE() - INTERVAL 18 DAY),(CURDATE() - INTERVAL 4 DAY),(CURDATE() - INTERVAL 6 DAY),'Returned',0,NULL,'U002','U002'),
  ('L019','M004','B019',(CURDATE() - INTERVAL 60 DAY),(CURDATE() - INTERVAL 46 DAY),(CURDATE() - INTERVAL 45 DAY),'Lost',0,NULL,'U002',NULL),
  ('L020','M007','B020',(CURDATE() - INTERVAL 50 DAY),(CURDATE() - INTERVAL 36 DAY),(CURDATE() - INTERVAL 40 DAY),'Lost',0,NULL,'U003',NULL),
  ('L021','M006','B021',(CURDATE() - INTERVAL 11 DAY),(CURDATE() + INTERVAL 3 DAY),NULL,'Issued',0,NULL,'U002',NULL),
  ('L022','M006','B022',(CURDATE() - INTERVAL 30 DAY),(CURDATE() - INTERVAL 16 DAY),NULL,'Issued',0,NULL,'U003',NULL),
  ('L023','M006','B023',(CURDATE() - INTERVAL 12 DAY),(CURDATE() + INTERVAL 2 DAY),NULL,'Issued',0,NULL,'U002',NULL),
  ('L024','M008','B024',(CURDATE() - INTERVAL 20 DAY),(CURDATE() + INTERVAL 8 DAY),NULL,'Issued',1,(CURDATE() - INTERVAL 7 DAY),'U003',NULL),
  ('L025','M009','B003',(CURDATE() - INTERVAL 22 DAY),(CURDATE() - INTERVAL 8 DAY),NULL,'Issued',0,NULL,'U002',NULL),
  ('L026','M010','B025',(CURDATE() - INTERVAL 3 DAY),(CURDATE() + INTERVAL 11 DAY),NULL,'Issued',0,NULL,'U003',NULL),
  ('L027','M002','B026',(CURDATE() - INTERVAL 2 DAY),(CURDATE() + INTERVAL 12 DAY),NULL,'Issued',0,NULL,'U001',NULL),
  ('L028','M005','B027',(CURDATE() - INTERVAL 10 DAY),(CURDATE() + INTERVAL 4 DAY),NULL,'Issued',0,NULL,'U002',NULL),
  ('L029','M003','B028',(CURDATE() - INTERVAL 18 DAY),(CURDATE() - INTERVAL 4 DAY),NULL,'Issued',0,NULL,'U003',NULL),
  ('L030','M004','B029',(CURDATE() - INTERVAL 5 DAY),(CURDATE() + INTERVAL 9 DAY),NULL,'Issued',0,NULL,'U002',NULL),
  ('L031','M010','B030',(CURDATE() - INTERVAL 4 DAY),(CURDATE() + INTERVAL 10 DAY),NULL,'Issued',0,NULL,'U003',NULL),
  ('L032','M012','B005',(CURDATE() - INTERVAL 120 DAY),(CURDATE() - INTERVAL 106 DAY),(CURDATE() - INTERVAL 110 DAY),'Returned',0,NULL,'U002','U002'),
  ('L033','M011','B006',(CURDATE() - INTERVAL 150 DAY),(CURDATE() - INTERVAL 136 DAY),(CURDATE() - INTERVAL 140 DAY),'Returned',0,NULL,'U003','U003'),
  ('L034','M013','B007',(CURDATE() - INTERVAL 90 DAY),(CURDATE() - INTERVAL 76 DAY),(CURDATE() - INTERVAL 80 DAY),'Returned',0,NULL,'U002','U002');

-- ---------- D8 reservations ----------
INSERT INTO reservations (reservation_id, member_id, book_id, reservation_date, status, expiry_date, loan_id) VALUES
  ('R001','M003','B029',(CURDATE() - INTERVAL 10 DAY),'Pending',NULL,NULL),
  ('R002','M005','B029',(CURDATE() - INTERVAL 8 DAY),'Pending',NULL,NULL),
  ('R003','M007','B030',(CURDATE() - INTERVAL 6 DAY),'Ready',(CURDATE() + INTERVAL 2 DAY),NULL),
  ('R004','M008','B024',(CURDATE() - INTERVAL 15 DAY),'Fulfilled',NULL,'L024'),
  ('R005','M009','B029',(CURDATE() - INTERVAL 20 DAY),'Cancelled',NULL,NULL),
  ('R006','M006','B013',(CURDATE() - INTERVAL 15 DAY),'Expired',(CURDATE() - INTERVAL 5 DAY),NULL);

-- ---------- D9 fines (net_amount is generated) ----------
INSERT INTO fines (fine_id, loan_id, fine_amount, waived_amount, paid_status, waiver_type, fine_date, paid_date, payment_method, remark, created_by) VALUES
  ('F001','L001',5.00,0.00,'Unpaid','Not Waived',(CURDATE() - INTERVAL 36 DAY),NULL,NULL,'Returned 10 days late','U002'),
  ('F002','L002',5.00,0.00,'Paid','Not Waived',(CURDATE() - INTERVAL 56 DAY),(CURDATE() - INTERVAL 56 DAY),'Cash','Returned 10 days late','U003'),
  ('F003','L003',3.50,3.50,'Waived','Fully Waived',(CURDATE() - INTERVAL 49 DAY),(CURDATE() - INTERVAL 48 DAY),'No charge','Returned 7 days late - fully waived by librarian','U002'),
  ('F004','L004',6.00,2.00,'Unpaid','Partially Waived',(CURDATE() - INTERVAL 24 DAY),NULL,NULL,'Returned 12 days late - part waived','U003'),
  ('F005','L005',5.00,0.00,'Paid','Not Waived',(CURDATE() - INTERVAL 21 DAY),(CURDATE() - INTERVAL 21 DAY),'Card','Returned 10 days late','U002'),
  ('F006','L006',7.00,0.00,'Unpaid','Not Waived',(CURDATE() - INTERVAL 12 DAY),NULL,NULL,'Returned 14 days late','U003'),
  ('F007','L007',5.00,0.00,'Unpaid','Not Waived',(CURDATE() - INTERVAL 11 DAY),NULL,NULL,'Returned 10 days late','U002'),
  ('F008','L008',4.00,0.00,'Paid','Not Waived',(CURDATE() - INTERVAL 8 DAY),(CURDATE() - INTERVAL 8 DAY),'Cash','Returned 8 days late','U003'),
  ('F009','L009',1.50,0.00,'Unpaid','Not Waived',(CURDATE() - INTERVAL 28 DAY),NULL,NULL,'Returned 3 days late (book then scrapped)','U002'),
  ('F010','L010',1.00,0.00,'Unpaid','Not Waived',(CURDATE() - INTERVAL 9 DAY),NULL,NULL,'Returned 2 days late (Librarian borrower, handled by Admin)','U001');

-- ---------- D10 damage_lost (net_amount is generated) ----------
INSERT INTO damage_lost (damage_id, book_id, loan_id, member_id, amount, waived_amount, paid_status, waiver_type, record_date, paid_date, damage_type, payment_method, remark, created_by) VALUES
  ('DL001','B019','L019','M004',8.99,0.00,'Unpaid','Not Waived',(CURDATE() - INTERVAL 45 DAY),NULL,'Lost',NULL,'Lost on loan - replacement cost charged','U002'),
  ('DL002','B002',NULL,NULL,0.00,0.00,'Unpaid','Not Waived',(CURDATE() - INTERVAL 30 DAY),(CURDATE() - INTERVAL 30 DAY),'Damaged','No charge','Torn cover repaired and kept on shelf (no charge)','U002'),
  ('DL003','B009','L009','M005',20.00,0.00,'Paid','Not Waived',(CURDATE() - INTERVAL 28 DAY),(CURDATE() - INTERVAL 28 DAY),'Scrapped','Card','Returned water damaged - scrapped, charge paid','U002'),
  ('DL004','B010',NULL,NULL,0.00,0.00,'Unpaid','Not Waived',(CURDATE() - INTERVAL 15 DAY),(CURDATE() - INTERVAL 15 DAY),'Scrapped','No charge','Shelf copy scrapped (no member charged)','U002'),
  ('DL005','B003','L003','M003',5.00,2.00,'Unpaid','Partially Waived',(CURDATE() - INTERVAL 4 DAY),NULL,'Damaged',NULL,'Damaged on loan - part waived','U002'),
  ('DL006','B020','L020','M007',14.99,14.99,'Waived','Fully Waived',(CURDATE() - INTERVAL 40 DAY),(CURDATE() - INTERVAL 39 DAY),'Lost','No charge','Lost on loan - charge fully waived','U003'),
  ('DL007','B001','L001','M006',3.00,0.00,'Paid','Not Waived',(CURDATE() - INTERVAL 2 DAY),(CURDATE() - INTERVAL 1 DAY),'Damaged','Cash','Damaged on loan - charge paid','U002');
