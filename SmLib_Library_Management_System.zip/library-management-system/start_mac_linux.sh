#!/usr/bin/env bash
# First time:  chmod +x start_mac_linux.sh && ./start_mac_linux.sh
cd "$(dirname "$0")"
[ -d venv ] || python3 -m venv venv
source venv/bin/activate
pip install -q -r requirements.txt
[ -f .env ] || { cp .env.example .env; echo "Edit .env and set DB_PASSWORD, then run this script again."; exit 0; }
python scripts/setup_database.py && python run.py
