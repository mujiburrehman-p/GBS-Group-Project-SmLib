# SmLib Test Data Guide

All data is fictitious. All e-mail addresses end in @smlib.co.uk. Dates are relative to the day the data is loaded, so overdue and due-soon situations are always true. Load with: python scripts/setup_database.py --reset


## 1. Data volume

| Table | Records |
|---|---|
| users (incl. admin) | 14 |
| members | 14 (2 Librarian, 3 Staff, 9 Student) |
| categories | 5 |
| authors | 5 |
| publishers | 5 |
| books | 30 (74 copies) |
| loans | 34 |
| reservations | 6 |
| fines | 10 |
| damage_lost | 7 |
| system_settings | 6 |


## 2. Users and logins

| Member | User | Username | Role | Status | Password | Person and test purpose | E-mail |
|---|---|---|---|---|---|---|---|
| - | U001 | admin | Admin | Active | Admin@12345 | System Administrator (user only, not a member) | admin@smlib.co.uk |
| M001 | U002 | mujibur | Librarian | Active | Librarian@123 | Mujibur Rehman - Librarian; borrows a book issued by Admin (L010) | mujibur.rehman@smlib.co.uk |
| M002 | U003 | wasim | Librarian | Active | Librarian@123 | Wasim Khan Raja - Librarian; open loan issued by Admin (L027) | wasim.khan.raja@smlib.co.uk |
| M003 | U004 | abigel | Member | Active | Member@123 | Abigel Sara Fosu - Staff; fully waived fine, partly waived damage, overdue loan L029 | abigel.sara.fosu@smlib.co.uk |
| M004 | U005 | timothy | Member | Active | Member@123 | Timothy Anthony Shakespeare - Staff; lost book, unpaid fine, loan of the last copy of B029 | timothy.anthony.shakespeare@smlib.co.uk |
| M005 | U006 | kelvin | Member | Active | Member@123 | Kelvin Gibbah - Staff; scrapped book, open loan | kelvin.gibbah@smlib.co.uk |
| M006 | U007 | yakken | Member | Active | Member@123 | Yakken Ahmed - Student; AT 3-BOOK LIMIT, overdue loan L022, unpaid fine, paid damage | yakken.ahmed@smlib.co.uk |
| M007 | U008 | lutifyah | Member | Active | Member@123 | Lutifyah Begum - Student; paid fine (Cash), lost book fully waived, Ready reservation | lutifyah.begum@smlib.co.uk |
| M008 | U009 | tahsin | Member | Active | Member@123 | Tahsin Islam - Student; paid fine (Card), renewed loan L024 (maximum reached) | tahsin.islam@smlib.co.uk |
| M009 | U010 | irfan | Member | Active | Member@123 | Irfan Hussain - Student; OVERDUE loan L025 with no fine yet, cancelled reservation | irfan.hussain@smlib.co.uk |
| M010 | U011 | oliver | Member | Active | Member@123 | Oliver Smith - Student; two open loans, paid fine (Cash) | oliver.smith@smlib.co.uk |
| M011 | U012 | emily | Member | Inactive | Member@123 | Emily Johnson - Student; INACTIVE account - login refused | emily.johnson@smlib.co.uk |
| M012 | U013 | harry | Member | Active | Member@123 | Harry Williams - Student; EXPIRED membership - cannot borrow | harry.williams@smlib.co.uk |
| M013 | - | (none) | - | - | - | Charlotte Brown - Student; member WITHOUT a login | charlotte.brown@smlib.co.uk |
| M014 | U014 | george | Member | Active | Member@123 | George Taylor - Student; NO loans - clean member for issue tests | george.taylor@smlib.co.uk |


## 3. Categories, authors and publishers

| ID | Category | Books |
|---|---|---|
| C001 | Computer Science | 6 |
| C002 | Mathematics | 6 |
| C003 | Fiction | 6 |
| C004 | Business | 6 |
| C005 | Science | 6 |

| ID | Author | Books |
|---|---|---|
| A001 | Alan Whitmore | 6 |
| A002 | Helen Carter | 6 |
| A003 | James Holloway | 6 |
| A004 | Margaret Ellison | 6 |
| A005 | Robert Hargreaves | 6 |

| ID | Publisher | E-mail | Books |
|---|---|---|---|
| P001 | Northbridge Press | northbridge@smlib.co.uk | 6 |
| P002 | Kingsway Publishing | kingsway@smlib.co.uk | 6 |
| P003 | Riverside Books | riverside@smlib.co.uk | 6 |
| P004 | Oakfield Academic | oakfield@smlib.co.uk | 6 |
| P005 | Harbour and Gate | harbourgate@smlib.co.uk | 6 |

All five authors, publishers and categories are used by books, so none can be deleted (this is the "linked record cannot be deleted" test). To test a successful delete, first add a new author, publisher or category, then delete it.


## 4. Books (30)

| ID | Title | ISBN | Author | Category | Shelf | Total | Avail. | On loan | Dam. | Lost | Scr. |
|---|---|---|---|---|---|---|---|---|---|---|---|
| B001 | Introduction to Database Design | 9781000000001 | Alan Whitmore | Computer Science | A-01 | 3 | 2 | 0 | 1 | 0 | 0 |
| B002 | Practical SQL for Beginners | 9781000000002 | Alan Whitmore | Computer Science | A-02 | 3 | 2 | 0 | 1 | 0 | 0 |
| B003 | Python Programming Essentials | 9781000000003 | Alan Whitmore | Computer Science | A-03 | 3 | 1 | 1 | 1 | 0 | 0 |
| B004 | Web Development with Flask | 9781000000004 | Alan Whitmore | Computer Science | A-04 | 2 | 2 | 0 | 0 | 0 | 0 |
| B005 | Software Testing Fundamentals | 9781000000005 | Alan Whitmore | Computer Science | A-05 | 2 | 2 | 0 | 0 | 0 | 0 |
| B006 | Data Structures Made Simple | 9781000000006 | Alan Whitmore | Computer Science | A-06 | 2 | 2 | 0 | 0 | 0 | 0 |
| B007 | Foundations of Algebra | 9781000000007 | Helen Carter | Mathematics | B-01 | 2 | 2 | 0 | 0 | 0 | 0 |
| B008 | Calculus Step by Step | 9781000000008 | Helen Carter | Mathematics | B-02 | 2 | 2 | 0 | 0 | 0 | 0 |
| B009 | Statistics for Everyday Life | 9781000000009 | Helen Carter | Mathematics | B-03 | 3 | 2 | 0 | 0 | 0 | 1 |
| B010 | Discrete Mathematics | 9781000000010 | Helen Carter | Mathematics | B-04 | 3 | 2 | 0 | 0 | 0 | 1 |
| B011 | Geometry and Trigonometry | 9781000000011 | Helen Carter | Mathematics | B-05 | 2 | 2 | 0 | 0 | 0 | 0 |
| B012 | Probability Explained | 9781000000012 | Helen Carter | Mathematics | B-06 | 2 | 2 | 0 | 0 | 0 | 0 |
| B013 | The Silent Harbour | 9781000000013 | James Holloway | Fiction | C-01 | 2 | 2 | 0 | 0 | 0 | 0 |
| B014 | Letters from Marlow Street | 9781000000014 | James Holloway | Fiction | C-02 | 2 | 2 | 0 | 0 | 0 | 0 |
| B015 | The Last Lighthouse Keeper | 9781000000015 | James Holloway | Fiction | C-03 | 2 | 2 | 0 | 0 | 0 | 0 |
| B016 | A Winter in Kingsbridge | 9781000000016 | James Holloway | Fiction | C-04 | 2 | 2 | 0 | 0 | 0 | 0 |
| B017 | The Clockmakers Daughter | 9781000000017 | James Holloway | Fiction | C-05 | 2 | 2 | 0 | 0 | 0 | 0 |
| B018 | Beyond the Moorland | (none) | James Holloway | Fiction | R-01 | 2 | 2 | 0 | 0 | 0 | 0 |
| B019 | Starting a Small Business | 9781000000019 | Margaret Ellison | Business | D-01 | 3 | 2 | 0 | 0 | 1 | 0 |
| B020 | Principles of Marketing | 9781000000020 | Margaret Ellison | Business | D-02 | 3 | 2 | 0 | 0 | 1 | 0 |
| B021 | Managing People and Teams | 9781000000021 | Margaret Ellison | Business | D-03 | 3 | 2 | 1 | 0 | 0 | 0 |
| B022 | Personal Finance Basics | 9781000000022 | Margaret Ellison | Business | D-04 | 3 | 2 | 1 | 0 | 0 | 0 |
| B023 | Project Management in Practice | 9781000000023 | Margaret Ellison | Business | D-05 | 3 | 2 | 1 | 0 | 0 | 0 |
| B024 | Understanding Accounting | 9781000000024 | Margaret Ellison | Business | D-06 | 3 | 2 | 1 | 0 | 0 | 0 |
| B025 | Physics in Everyday Life | 9781000000025 | Robert Hargreaves | Science | E-01 | 3 | 2 | 1 | 0 | 0 | 0 |
| B026 | Chemistry Fundamentals | 9781000000026 | Robert Hargreaves | Science | E-02 | 3 | 2 | 1 | 0 | 0 | 0 |
| B027 | Introduction to Biology | 9781000000027 | Robert Hargreaves | Science | E-03 | 3 | 2 | 1 | 0 | 0 | 0 |
| B028 | The Earth and Its Climate | 9781000000028 | Robert Hargreaves | Science | E-04 | 3 | 2 | 1 | 0 | 0 | 0 |
| B029 | Exploring the Solar System | 9781000000029 | Robert Hargreaves | Science | E-05 | 1 | 0 | 1 | 0 | 0 | 0 |
| B030 | Energy and the Environment | 9781000000030 | Robert Hargreaves | Science | E-06 | 2 | 1 | 1 | 0 | 0 | 0 |

Special books: B018 has no ISBN (reference copy); B029 has one copy, on loan, so it has no copy to issue and a reservation queue; B030 has one copy held for a Ready reservation; B001, B002 and B003 have a damaged copy; B009 and B010 have scrapped copies; B019 and B020 have a lost copy.


## 5. Loans (34)

| Loan | Member | Book | Issued | Due | Returned | Status | Renew | Days late / overdue |
|---|---|---|---|---|---|---|---|---|
| L001 | M006 | B001 | 2026-09-07 | 2026-09-21 | 2026-10-01 | Returned | 0 | 10 |
| L002 | M007 | B002 | 2026-08-18 | 2026-09-01 | 2026-09-11 | Returned | 0 | 10 |
| L003 | M003 | B003 | 2026-08-28 | 2026-09-11 | 2026-09-18 | Returned | 0 | 7 |
| L004 | M006 | B004 | 2026-09-17 | 2026-10-01 | 2026-10-13 | Returned | 0 | 12 |
| L005 | M008 | B005 | 2026-09-22 | 2026-10-06 | 2026-10-16 | Returned | 0 | 10 |
| L006 | M004 | B006 | 2026-09-27 | 2026-10-11 | 2026-10-25 | Returned | 0 | 14 |
| L007 | M009 | B007 | 2026-10-02 | 2026-10-16 | 2026-10-26 | Returned | 0 | 10 |
| L008 | M010 | B008 | 2026-10-07 | 2026-10-21 | 2026-10-29 | Returned | 0 | 8 |
| L009 | M005 | B009 | 2026-09-22 | 2026-10-06 | 2026-10-09 | Returned | 0 | 3 |
| L010 | M001 | B010 | 2026-10-12 | 2026-10-26 | 2026-10-28 | Returned | 0 | 2 |
| L011 | M006 | B011 | 2026-10-07 | 2026-10-21 | 2026-10-17 | Returned | 0 | 0 |
| L012 | M007 | B012 | 2026-10-09 | 2026-10-23 | 2026-10-21 | Returned | 0 | 0 |
| L013 | M008 | B013 | 2026-10-10 | 2026-10-24 | 2026-10-22 | Returned | 0 | 0 |
| L014 | M009 | B014 | 2026-10-11 | 2026-10-25 | 2026-10-23 | Returned | 0 | 0 |
| L015 | M010 | B015 | 2026-10-13 | 2026-10-27 | 2026-10-25 | Returned | 0 | 0 |
| L016 | M002 | B016 | 2026-10-15 | 2026-10-29 | 2026-10-27 | Returned | 0 | 0 |
| L017 | M003 | B017 | 2026-10-17 | 2026-10-31 | 2026-10-29 | Returned | 0 | 0 |
| L018 | M004 | B018 | 2026-10-19 | 2026-11-02 | 2026-10-31 | Returned | 0 | 0 |
| L019 | M004 | B019 | 2026-09-07 | 2026-09-21 | 2026-09-22 | Lost | 0 | 1 |
| L020 | M007 | B020 | 2026-09-17 | 2026-10-01 | 2026-09-27 | Lost | 0 | 0 |
| L021 | M006 | B021 | 2026-10-26 | 2026-11-09 | - | Issued | 0 | 0 |
| L022 | M006 | B022 | 2026-10-07 | 2026-10-21 | - | Issued | 0 | 16 |
| L023 | M006 | B023 | 2026-10-25 | 2026-11-08 | - | Issued | 0 | 0 |
| L024 | M008 | B024 | 2026-10-17 | 2026-11-14 | - | Issued | 1 | 0 |
| L025 | M009 | B003 | 2026-10-15 | 2026-10-29 | - | Issued | 0 | 8 |
| L026 | M010 | B025 | 2026-11-03 | 2026-11-17 | - | Issued | 0 | 0 |
| L027 | M002 | B026 | 2026-11-04 | 2026-11-18 | - | Issued | 0 | 0 |
| L028 | M005 | B027 | 2026-10-27 | 2026-11-10 | - | Issued | 0 | 0 |
| L029 | M003 | B028 | 2026-10-19 | 2026-11-02 | - | Issued | 0 | 4 |
| L030 | M004 | B029 | 2026-11-01 | 2026-11-15 | - | Issued | 0 | 0 |
| L031 | M010 | B030 | 2026-11-02 | 2026-11-16 | - | Issued | 0 | 0 |
| L032 | M012 | B005 | 2026-07-09 | 2026-07-23 | 2026-07-19 | Returned | 0 | 0 |
| L033 | M011 | B006 | 2026-06-09 | 2026-06-23 | 2026-06-19 | Returned | 0 | 0 |
| L034 | M013 | B007 | 2026-08-08 | 2026-08-22 | 2026-08-18 | Returned | 0 | 0 |

Dates shown are the dates of the load day this guide was produced; they move with the day you load the data.


## 6. Fines, damaged/lost/scrapped records, reservations

| Fine | Loan | Fine £ | Waived £ | Net £ | Status | Waiver | Method |
|---|---|---|---|---|---|---|---|
| F001 | L001 | 5 | 0 | 5 | Unpaid | Not Waived | - |
| F002 | L002 | 5 | 0 | 5 | Paid | Not Waived | Cash |
| F003 | L003 | 3.5 | 3.5 | 0 | Waived | Fully Waived | No charge |
| F004 | L004 | 6 | 2 | 4 | Unpaid | Partially Waived | - |
| F005 | L005 | 5 | 0 | 5 | Paid | Not Waived | Card |
| F006 | L006 | 7 | 0 | 7 | Unpaid | Not Waived | - |
| F007 | L007 | 5 | 0 | 5 | Unpaid | Not Waived | - |
| F008 | L008 | 4 | 0 | 4 | Paid | Not Waived | Cash |
| F009 | L009 | 1.5 | 0 | 1.5 | Unpaid | Not Waived | - |
| F010 | L010 | 1 | 0 | 1 | Unpaid | Not Waived | - |

| Record | Book | Loan | Type | Amount £ | Waived £ | Net £ | Status | Method |
|---|---|---|---|---|---|---|---|---|
| DL001 | B019 | L019 | Lost | 8.99 | 0 | 8.99 | Unpaid | - |
| DL002 | B002 | - | Damaged | 0 | 0 | 0 | Unpaid | No charge |
| DL003 | B009 | L009 | Scrapped | 20 | 0 | 20 | Paid | Card |
| DL004 | B010 | - | Scrapped | 0 | 0 | 0 | Unpaid | No charge |
| DL005 | B003 | L003 | Damaged | 5 | 2 | 3 | Unpaid | - |
| DL006 | B020 | L020 | Lost | 14.99 | 14.99 | 0 | Waived | No charge |
| DL007 | B001 | L001 | Damaged | 3 | 0 | 3 | Paid | Cash |

| Reservation | Member | Book | Status | Expiry | Loan |
|---|---|---|---|---|---|
| R001 | M003 | B029 | Pending | - | - |
| R002 | M005 | B029 | Pending | - | - |
| R003 | M007 | B030 | Ready | 2026-11-08 | - |
| R004 | M008 | B024 | Fulfilled | - | L024 |
| R005 | M009 | B029 | Cancelled | - | - |
| R006 | M006 | B013 | Expired | 2026-11-01 | - |


## 7. Test coverage by type of test

Result column: "Verified" = run on this data set and the result matched. Other rows are for you to run and tick.

| Area | Type | Test and data | Expected result | Result |
|---|---|---|---|---|
| Login | Positive | Log in as admin, mujibur, wasim, abigel, timothy, kelvin, yakken, lutifyah, tahsin, irfan, oliver, george | Correct dashboard for each role | Verified |
| Login | Negative | Log in as emily (Inactive) / unknown user / wrong password | Refused with a message | Verified |
| Access control | Security | Librarian opens /staff/reports/revenue; member opens staff pages | 403 Not allowed | Verified |
| Access control | Security | Remove the _csrf token from any form and submit | 400, nothing saved | Run |
| Registration | Positive / Negative | Register a new student; repeat an existing username or e-mail; password under 8 characters | Created / rejected with message | Run |
| Issue book | Positive | Issue B011 to George (M014, no loans) | Loan created, due in 14 days | Verified |
| Issue book | Boundary | Issue a 4th book to Yakken (M006 has 3) | Refused: maximum of 3 books | Verified |
| Issue book | Negative | Issue to Harry (expired) / Emily (inactive) | Refused: membership expired / inactive | Verified |
| Issue book | Negative | Issue B029 (no copy available) | Refused: no copy available | Verified |
| Renew | Positive | Renew L021 (issued 11 days ago) | Renewed, new due date | Verified |
| Renew | Boundary | Renew L024 (already renewed once) | Refused: maximum 1 renewal | Verified |
| Renew | Negative | Renew an overdue loan (L022, L025, L029) or a loan under 10 days old (L026) | Refused with message | Run |
| Return | Positive | Return an on-time loan (L028) | Returned, no fine | Run |
| Return | Business rule | Return overdue loan L022 (16 days late) | Fine of 8.00 created, payment screen opens | Verified |
| Fines | Positive | Pay F001 by Cash; pay F006 by Card | Status Paid | Run |
| Fines | Business rule | Waive part of F006; fully waive F007 | Partially / Fully Waived, net updated | Run |
| Fines | Business rule | Calculate fines for overdue loans (L025, L029 have none) | New fines created | Run |
| Damaged / lost | Positive | Record a new Damaged, Lost and Scrapped copy | Counts on the book change; charge recorded | Run |
| Reservations | Positive | Reserve B029 as George; view queue R001, R002 | Pending, in order | Run |
| Reservations | Business rule | Return B030 loan L031 while R003 is Ready | Copy held, expiry set | Run |
| Reservations | Negative | Reserve a book you already have reserved (R001 Abigel, B029) | Refused: already reserved | Run |
| Catalogue | Search | Search "Python", "Marketing", ISBN 9781000000003, shelf E-01, category Fiction | Correct books listed | Run |
| Books | Negative | Add a book with an existing ISBN (9781000000001) | Rejected: ISBN must be unique | Run |
| Books | Positive | Add a book without an ISBN (like B018) | Saved | Run |
| Data integrity | Constraint | Delete author A001 / publisher P001 / category C001 / book B001 | Refused: records in use | Run |
| Data integrity | Constraint | SQL: UPDATE fines SET waived_amount=999 WHERE fine_id='F001' | CHECK constraint error (3819) | Run |
| Reports | Positive | Open all 17 Admin, 13 Librarian and 9 Member reports; export PDF and CSV | Pages open; files download | Verified (pages) |
| Reports | Filter | Loans: status Overdue (3 rows: L022, L025, L029); Fines: Paid + Cash; Inventory: Damaged | Filtered rows | Run |
| Member view | Security | Log in as yakken: My Overdue shows L022; My Unpaid shows F001, F004 | Only own data | Verified (pages) |
| Settings | Positive | Admin changes max_books to 4, then issues a 4th book to Yakken; reset to 3 | Rule changes without code | Run |


## 8. Sample constraint and integrity SQL (MySQL Workbench)

    UPDATE fines SET waived_amount = 999 WHERE fine_id = 'F001';   -- CHECK violated
    INSERT INTO books (book_id,title,isbn,author_id,publisher_id,category_id,created_by) VALUES ('B999','Test','9781000000001','A001','P001','C001','U002');   -- duplicate ISBN
    DELETE FROM authors WHERE author_id = 'A001';   -- used by books
    INSERT INTO loans (loan_id,member_id,book_id,issue_date,due_date,status,issued_by) VALUES ('L999','M001','B001',CURDATE(),CURDATE() - INTERVAL 1 DAY,'Issued','U002');   -- due before issue