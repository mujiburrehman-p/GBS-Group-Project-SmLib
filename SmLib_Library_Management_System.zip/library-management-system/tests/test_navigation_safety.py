"""Navigation safety checks (run:  python tests/test_navigation_safety.py).

1. Opening / refreshing / going Back to ANY page (HTTP GET) never writes to the database.
2. Every state-changing route accepts POST only (a GET is rejected with 405).
3. Pages are sent with Cache-Control: no-store so Back/Forward/Refresh always show live data.
4. A successful POST answers with a redirect (Post/Redirect/Get).

The database layer is replaced by a recorder, so no MySQL server is needed for this test.
"""
import os
import sys
from unittest import mock

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from app import create_app, db  # noqa: E402

writes = []
app = create_app()
app.config["TESTING"] = False
client = app.test_client()


def fake_query(sql, args=None):
    return []


def fake_one(sql, args=None):
    return {"n": 0, "t": 0, "setting_value": "1"}


def record(name):
    def f(*a, **k):
        writes.append((name, str(a[:1])[:80]))
        return 0
    return f


ROLES = {"Admin": None, "Librarian": "M001", "Member": "M002"}
failures = []

with mock.patch.object(db, "query", fake_query), mock.patch.object(db, "one", fake_one), \
        mock.patch.object(db, "execute", record("execute")), mock.patch.object(db, "commit", record("commit")), \
        mock.patch.object(db, "rollback", lambda: None):
    get_rules, post_only = [], []
    for rule in app.url_map.iter_rules():
        if rule.endpoint == "static":
            continue
        if "GET" in rule.methods:
            get_rules.append(rule)
        elif "POST" in rule.methods:
            post_only.append(rule)

    def fill(rule):
        url = rule.rule
        for arg in rule.arguments:
            url = url.replace(f"<{arg}>", "x").replace(f"<string:{arg}>", "x")
            import re
            url = re.sub(rf"<[^>]*{arg}>", "x", url)
        return url

    for role, mid in ROLES.items():
        with client.session_transaction() as s:
            s["user"] = {"user_id": "U001", "name": "T", "username": "t", "role": role, "member_id": mid}
        for rule in get_rules:
            writes.clear()
            r = client.get(fill(rule))
            if writes:
                failures.append(f"GET {rule.rule} as {role} wrote to the database: {writes[:2]}")
            if r.status_code == 200 and "no-store" not in r.headers.get("Cache-Control", ""):
                failures.append(f"GET {rule.rule} missing Cache-Control: no-store")
        for rule in post_only:
            writes.clear()
            r = client.get(fill(rule))
            if r.status_code not in (405, 302, 403, 404) or writes:
                failures.append(f"POST-only route {rule.rule} answered GET with {r.status_code}")

print(f"checked {len(get_rules)} read routes and {len(post_only)} POST-only routes for 3 roles")
if failures:
    print("FAILED:")
    print("\n".join(" -", *failures) if False else "\n".join(" - " + f for f in failures))
    sys.exit(1)
print("OK: no page writes to the database when opened, refreshed or revisited")
