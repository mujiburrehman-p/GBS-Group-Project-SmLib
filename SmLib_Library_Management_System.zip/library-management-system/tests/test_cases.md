# SmLib - Full Test Conditions

All cases use the data in `database/sample_data.sql` (loaded by `python scripts/setup_database.py`).
Dates in the sample data are relative to the day it is loaded, so "overdue" and "due soon" are always true.
To get a clean start before a test run: `python scripts/setup_database.py --reset`.
Each case is independent unless it says "after TC-xx". Tick the **Pass** column when the result matches **Expected**.

**Default settings:** loan 14 days - fine 0.50 per day - max 3 books - max 1 renewal - renewal only after 10 days from issue - hold 3 days.

## Logins

| Role | Username | Password | Notes |
|---|---|---|---|
| Admin | admin | Admin@12345 | seed.sql |
| Librarian (5) | librarian (Sarah Collins), michael, kelvin, abigel, timothy | Librarian@123 | kelvin, abigel, timothy are project team members |
| Student / Staff | aisha, daniel, priya, jamal, omar, yakeen, lutfiyah, mujibur, wasim ... (full list in Appendix A) | Member@123 | aisha has 3 open loans (at the limit) |
| Expired membership | robert (M008) | Member@123 | membership ended 30 days ago; cannot borrow |
| Inactive | emma (M007) | Member@123 | account Inactive; login must be refused |
| No login | Lina Haddad (M009), Liam O'Connor (M024), Tariq Mahmood (M040) | - | members without a user account |

**Members: 45 in total = 30 Students + 10 Staff + 5 Librarians** (Admin is a user only, not a member).

## Key sample records

| Topic | Records |
|---|---|
| Open loans | L011 (issued 11 days ago, due +3), L012 (due +2), L013 (renewed once), **L014 and L015 overdue, no fine yet**, L016 (issued 3 days ago), L017 (Librarian borrower, issued by Admin), L019 (issued 10 days ago) |
| Returned on time | L007, L008 |
| Returned late with fine | L001-L006, L009, L010, L020, L021 -> F001-F010 |
| Lost loans | L018, L022 |
| Fines | F001 Unpaid - F002 Paid Cash - F003 Fully Waived - F004 Partially Waived - F005 Paid Card - F006 Unpaid - F007 Unpaid - F008 Paid Cash - F009 Unpaid - F010 Unpaid |
| Damaged / Lost | DL001 Lost Unpaid - DL002 Damaged no charge (B002) - DL003 Scrapped Paid - DL004 Scrapped shelf - DL005 Damaged part waived (B003, loan L003) - DL006 Lost fully waived - DL007 Damaged Paid (B001, loan L001) |
| Reservations | R001, R002 Pending (queue for B008) - R003 Ready (B006 held for jamal) - R004 Fulfilled - R005 Cancelled - R006 Expired |
| Books | B001-B012. B006 has a copy held; B008, B009 all copies out; B001, B002, B003 have 1 damaged copy each; B010 has 2 scrapped; B004, B005 have 1 lost; B011 free to issue; B012 has no ISBN |
| Unused (safe to delete) | author A010, publisher P007, category C007 |

---
## 1. Login, logout, access control

| TC | Role | Steps | Expected | Pass |
|---|---|---|---|---|
| 1.01 | - | Open the home page `/` while logged out | Redirected to Login | |
| 1.02 | - | Login admin / Admin@12345 | Admin dashboard | |
| 1.03 | - | Login librarian / Librarian@123 | Librarian dashboard | |
| 1.04 | - | Login aisha / Member@123 | Member dashboard | |
| 1.05 | - | Login aisha with a wrong password | "Invalid username or password"; stays on Login | |
| 1.06 | - | Login with an unknown username | Same generic message (no hint which part is wrong) | |
| 1.07 | - | Login emma / Member@123 (Inactive) | Login refused | |
| 1.08 | Any | Logout | Back to Login; Back button does not show private pages | |
| 1.09 | Member | Open `/books/` | 403 Not allowed | |
| 1.10 | Member | Open `/admin/settings` and `/admin/librarians` | 403 Not allowed | |
| 1.11 | Librarian | Open `/admin/settings` | 403 Not allowed | |
| 1.12 | Librarian | Open `/loans/issue`, `/fines`, `/reports` | Pages open | |
| 1.13 | Any | Submit any form without the security token (remove `_csrf` in dev tools) | 400 error, nothing saved | |
| 1.14 | Any | Open `/forgot-password` link | Message "Future Enhancements" (feature not built) | |

## 2. Registration and profile

| TC | Role | Steps | Expected | Pass |
|---|---|---|---|---|
| 2.01 | - | Register as Student with new username and a valid password | Account created; can log in as Member | |
| 2.02 | - | Register with username `aisha` | "Already exists"; nothing saved | |
| 2.03 | - | Register with email `aisha.khan@college.edu` | Rejected (email unique) | |
| 2.04 | - | Register with username shorter than 5 characters or with symbols | Validation message | |
| 2.05 | - | Register with a password shorter than 8 characters | Validation message | |
| 2.06 | Member | Open Manage Profile, change phone | Saved | |
| 2.07 | Member | Change password with the wrong current password | Rejected | |
| 2.08 | Member | Change password correctly, logout, login with the new one | Works | |

## 3. Books, authors, publishers, categories (Librarian / Admin)

| TC | Steps | Expected | Pass |
|---|---|---|---|
| 3.01 | Add category "History", author, publisher | Created with next IDs (C008, A011, P008); Created by = your user | |
| 3.02 | Add a book with 2 copies | Total 2 / Available 2 | |
| 3.03 | Add a book with ISBN `9780133970777` | Rejected: "Another book already uses this ISBN" | |
| 3.04 | Add a book with no ISBN | Saved (B012 shows this case) | |
| 3.05 | Add a book without author, publisher or category | Rejected: field is required | |
| 3.06 | Edit book B011 title | Saved | |
| 3.07 | Edit B011, enter 5 in "Add copies" | Total 7, Available 7 | |
| 3.08 | Edit B011, enter 1001 in "Add copies" | "Add copies cannot be more than 1000 at a time" | |
| 3.09 | Delete unused category C007, author A010, publisher P007 | Each deleted | |
| 3.10 | Delete category C001, author A001, publisher P001 (in use) | "Linked to other records"; kept | |
| 3.11 | Open book B010 | Total 4, Available 1, Damaged 0, Scrapped 2, Lost 0 | |
| 3.11b | Open Manage Books | Columns: ID, Cover, Title / ISBN, Author / Category, Shelf, Total, Available, Issued, Dmg, Scrapped, Lost (B001 Dmg 1, B010 Scrapped 2, B004 Lost 1) | |
| 3.12 | Open book B004 | Total 2, Available 1, Lost 1 | |
| 3.13 | Check every book | total = available + on loan + damaged + lost + scrapped (and total >= available + damaged + lost + scrapped) | |

## 3C. Book product description and cover page

| TC | Role | Steps | Expected | Pass |
|---|---|---|---|---|
| 3C.01 | Librarian | Add a book with a Product description and a PNG Cover page | Saved; description and image stored in the books table | |
| 3C.02 | Librarian | Add a book without description and cover | Saved; both columns NULL | |
| 3C.03 | Librarian | Product description of 256 characters | "Product description cannot be longer than 255 characters"; not saved | |
| 3C.04 | Librarian | Cover page is a text file named fake.png | "The cover must be a PNG, JPEG, GIF or WEBP image"; not saved | |
| 3C.05 | Librarian | Cover page larger than 2 MB | "The cover image is too big. The maximum size is 2 MB."; not saved | |
| 3C.06 | Librarian | Open /books/B001/cover and the cover of a new book saved without one | B001 returns the image (image/jpeg); the book without a cover gives 404 | |
| 3C.07 | Not logged in | Open /books/B001/cover | Sent to the Login page | |
| 3C.08 | Member | Open Search Catalogue and the details of B001 | Thumbnail for every book in the list; cover and description on the details page | |
| 3C.09 | Librarian | Edit B011: choose a new cover, then save again without a file | New cover replaces the old one; saving without a file keeps it | |
| 3C.10 | Librarian | Edit B011: tick "Remove the current cover" | cover_page becomes NULL | |
| 3C.11 | Librarian | Edit B011: change the description | New description saved | |
| 3C.12 | Admin | Open Manage Books, the Book Inventory report and its PDF | Pages open; images are links, not embedded in the page | |
| 3C.13 | Any | Check the sample data | All 12 books (B001 to B012) have a description and a cover image | |
| 3C.14 | Any | Check schema.sql | product_description VARCHAR(255) and cover_page LONGBLOB are defined in the books table; no separate alter script | |

## 4. Members and Librarians

| TC | Role | Steps | Expected | Pass |
|---|---|---|---|---|
| 4.01 | Librarian | Add a Student with a login | Member M046 and user U044 created; student can log in | |
| 4.02 | Librarian | Add a Staff member | Created | |
| 4.03 | Librarian | Add a member with email `priya.nair@college.edu` | Rejected (duplicate email) | |
| 4.04 | Librarian | Add a member with ID number `STU2026001` | Rejected (duplicate ID no) | |
| 4.05 | Librarian | Edit M003 phone | Saved | |
| 4.06 | Librarian | Deactivate omar (M010), then login as omar | Login refused | |
| 4.07 | Librarian | Deactivate aisha (has 3 open loans), then login as aisha | Member and login become Inactive; login refused. Her open loans stay open and staff can still return them. Re-activate afterwards | |
| 4.07b | Librarian | After 4.07 try to issue a book to aisha | "Membership is inactive" | |
| 4.08 | Librarian | Open the Librarians menu | Not available (Admin only) | |
| 4.09 | Admin | Manage Librarians > Add librarian | Member (type Librarian) and user (role Librarian) created | |
| 4.10 | Admin | Add a librarian with an existing email | Rejected | |
| 4.11 | Admin | Deactivate michael, login as michael | Login refused | |
| 4.12 | Librarian | Open member M002 | Shows loans, fines, charges, reservations of Aisha only | |
| 4.13 | Librarian | Manage Students: look at the Edit button of Active members and of Inactive member M007 | Active: Edit works. Inactive: Edit is greyed out (cannot be clicked) with the hint "Inactive members cannot be edited" | |
| 4.14 | Librarian | Manage Staff: deactivate omar (M010), look at Edit; type /members/M010/edit in the address bar | Edit greyed out; the address is refused with "Inactive members cannot be edited. Activate the member first."; after Activate, Edit works again | |
| 4.15 | Admin | Manage Librarians: deactivate michael (M005), look at Edit; open /admin/librarians/M005/edit; Activate again | Edit greyed out; the address is refused with "Inactive librarians cannot be edited..."; after Activate, Edit works again | |
| 4.16 | Librarian | Open member detail of Inactive M007 | The Edit button is greyed out | |
| 4.17 | Librarian | Manage Students: Deactivate an Active student who has an expiry date (e.g. M006), then check the membership end date | Status Inactive and the membership end date (expiry_date) = today's date | |
| 4.18 | Librarian | Manage Students: Activate the same student again | Status Active and the membership end date is empty (NULL) | |
| 4.19 | Librarian | Manage Staff: Deactivate then Activate a staff member (e.g. omar, M010) | Inactive: expiry_date = today; Active: expiry_date empty | |
| 4.20 | Admin | Manage Librarians: Deactivate then Activate a librarian (e.g. michael, M005) | Inactive: expiry_date = today; Active: expiry_date empty | |

## 4B. Member volume and lists (45 members)

| TC | Role | Steps | Expected | Pass |
|---|---|---|---|---|
| 4B.01 | Librarian | Open Manage Students | 30 students listed (M002, M003, M006, M007, M009, M021-M045) | |
| 4B.02 | Librarian | Open Manage Staff | 10 staff listed (M004, M008, M010, M014-M020) | |
| 4B.03 | Admin | Open Manage Librarians | 5 librarians (M001, M005, M011, M012, M013) | |
| 4B.04 | Librarian | Search Students for "Khan" | Aisha Khan (M002) only; staff list "Khan" gives Wasim Khan Raja (M015) | |
| 4B.05 | Librarian | Search for "Grace" in Students, then in Staff | Grace Ellis (M039) in Students; Grace Mensah (M016) in Staff | |
| 4B.06 | Librarian | Search "Yakeen", "Lutfiyah", "Mujibur" | Yakeen Ahmed M021, Lutfiyah Begum M022, Mujibur Rehman M014 | |
| 4B.07 | Librarian | Search by ID number `STF1004` and by email `kelvin` | Mujibur Rehman; Kelvin Gibbah appears only under Librarians (Admin) | |
| 4B.08 | Librarian | Search "O'Connor" (apostrophe) | Liam O'Connor (M024) found, no error | |
| 4B.09 | Librarian | Open Lina (M009), Liam (M024), Tariq (M040) | Pages open; no username shown (no login) | |
| 4B.10 | Librarian | Filter members by status Inactive | Emma Wilson (M007) only | |
| 4B.11 | Admin | Dashboard at first load | Active librarians 5, Active members (Student) 29, Active members (Staff) 10 (Emma is inactive) | |
| 4B.12 | Librarian | Reports > Member activity | 45 rows: 30 Students, 10 Staff, 5 Librarians, each with active loans count | |
| 4B.13 | Admin | Reports > Member activity | The same 45 rows | |
| 4B.14 | Librarian | Download the Member activity CSV | Header + 45 rows; "Liam O'Connor" intact | |
| 4B.15 | Librarian | Issue B003 (2 available) to M021, then M022, then M023 | The first two work; B003 available 2 -> 1 -> 0; the third member is refused "No copy is available" | |
| 4B.16 | Librarian | Open M021 (Yakeen) | Shows 1 returned loan (L023) and no fines | |
| 4B.17 | Admin | Add the 6th librarian | Manage Librarians shows 6; dashboard Active librarians 6 | |
| 4B.18 | Any | Log in as every team member (kelvin, abigel, timothy, mujibur, wasim, yakeen, lutfiyah) | Each login works with the password in the table | |
| 4B.19 | kelvin (Librarian) | Open Admin pages | 403 Not allowed (Librarian, not Admin) | |
| 4B.20 | Admin | Issue a book to Kelvin (Librarian borrower) | Works; a Librarian cannot do it | |

## 5. Catalogue search (all roles)

| TC | Steps | Expected | Pass |
|---|---|---|---|
| 5.01 | Search "clean" | B007 and B008 | |
| 5.02 | Search author "Orwell" | B003, B004 | |
| 5.03 | Search ISBN `9780132350884` | B007 | |
| 5.04 | Filter category Fiction | B003, B004 | |
| 5.05 | Search "zzzz" | "No books match your search." | |
| 5.06 | Open B008 as a Member who does not hold it (e.g. omar) | All copies out; Reserve button shown (Aisha holds B008 on loan L014, so she sees "You already have this book on loan" instead) | |
| 5.07 | Open B011 as a Member | Available; no Reserve needed | |

## 6. Issue books

| TC | Role | Steps | Expected | Pass |
|---|---|---|---|---|
| 6.01 | Librarian | Issue B011 to omar (M010) | New loan, due = today + 14, B011 available - 1 | |
| 6.02 | Librarian | Issue B011 to omar again | "Already has this book on loan" | |
| 6.03 | Librarian | Issue B011 to aisha (M002, 3 loans) | "Already has the maximum of 3 books" | |
| 6.04 | Librarian | Issue B011 to emma (M007, Inactive) | "Membership is inactive" | |
| 6.05 | Librarian | Issue B011 to robert (M008, expired) | "Membership expired on ..." | |
| 6.06 | Librarian | Issue B011 to michael (M005, Librarian) | "Only an Admin can issue books to a Librarian" | |
| 6.07 | Admin | Issue B012 to michael (M005) | Loan created | |
| 6.08 | Librarian | Issue B008 to omar (all copies out) | "No copy is available to issue" | |
| 6.09 | Librarian | Issue B006 to omar (last copy held for jamal) | "No copy is available to issue" | |
| 6.10 | Librarian | Issue B006 to jamal (M006, holder of Ready R003) | Loan created; R003 becomes Fulfilled with the loan ID | |
| 6.11 | Librarian | Issue a book with an unknown member ID (M999) | Rejected: member not found | |
| 6.12 | Admin | Change loan days to 7, issue a book | Due = today + 7 (restore 14 after) | |

## 7. Return and renew

| TC | Role | Steps | Expected | Pass |
|---|---|---|---|---|
| 7.01 | Librarian | Press Return on L011 (on time) | Confirmation box "Return book ... ?" with IDs in bold red; Cancel does nothing; Confirm returns it with no fine and no payment screen; stays on Return a Book; available + 1 | |
| 7.02 | Librarian | Return L014 (overdue 16 days) | A confirmation box (IDs in bold red) appears; after Confirm the book is returned; fine F011 = 8.00 Unpaid created; B008 available + 1; R001 becomes Ready with hold date = today + 3; R002 stays Pending; the Fine Payment screen opens (see 7B) | |
| 7.03 | Librarian | Return L014 again | "Not currently issued" | |
| 7.04 | Librarian | Return L017 (Librarian borrower) | "Only an Admin can process a book return for a Librarian" | |
| 7.05 | Admin | Return L017 | Loan returned | |
| 7.05b | Librarian | Renew L016 (issued 3 days ago) | "A book can be renewed only after 10 days from the issue date. Loan L016 can be renewed from <issue date + 10>"; nothing changes | |
| 7.06 | Librarian | Renew L011 (issued 11 days ago) | New due date = old due + 14; renewals 1 | |
| 7.07 | Librarian | Renew L011 again | "Already renewed the maximum of 1 time(s)" | |
| 7.08 | Librarian | Renew L013 (already renewed in sample data) | Same refusal | |
| 7.09 | Librarian | Renew L014 (overdue) | "An overdue loan cannot be renewed. Return the book first" | |
| 7.10 | Librarian | Reserve B009 as jamal, then renew L019 (issued exactly 10 days ago) | "Another member has reserved this book" | |
| 7.11 | Librarian | Return L015, then L016 | Fine for L015 (days late x 0.50); none for L016 | |
| 7.12 | Librarian | Return a Book: press **Lost** on L012 (not overdue), then Confirm | Confirmation "Mark book B002 - Database System Concepts of M003 - Daniel Okoye (loan L012) as Lost?" (IDs bold red); Confirm records the loss at once (no Record screen) and saves today as the loan's return date: loan L012 Lost, B002 Lost +1, charge = book price (79.50) Unpaid; the Damaged / Scrapped / Lost Payment screen opens (Pay Later returns to Return a Book) | |
| 7.13 | Librarian | Press **Lost** on L014 (overdue 16 days), then Confirm | The loan becomes Lost with return date = today, the overdue fine F011 (8.00) and the Lost charge DL008 (book price 39.99) are created, and the **Fine & Lost Payment** screen opens: member box (left), book and loan box (right); below, the fine panel on the left (fine amount, Payment Status, Waiver type, Waived amount, Remarks, net) and the lost panel on the right (same fields); one mandatory Payment method, Total to pay, Confirm Payment and Pay Later - Back to Return a Book | |
| 7.14 | Librarian | Press Lost on L017 (Librarian borrower) | Only an Admin may record it | |
| 7.15 | Librarian | On Fine & Lost Payment: waived 2.00 on the fine, 10.00 on the lost charge, method Card, Confirm Payment | Confirmation "Confirm payment of £... (fine F011 £... + lost charge DL008 £...) by Card from M002 - Aisha Khan?" (IDs bold red); Confirm saves both as Paid / Partially Waived in one step; returns to Return a Book | |
| 7.16 | Librarian | Same screen: leave method empty, or waive everything (both fully waived) | Empty method: browser stops the form; both fully waived: method becomes No charge and both are saved Waived with the date | |
| 7.17 | Librarian | Same screen: fine waived amount larger than the fine | Refused; nothing saved for either (fine and lost charge stay Unpaid) | |
| 7.18 | Librarian | Pay Later on Fine & Lost Payment | Returns to Return a Book; both stay Unpaid (pay them later from Manage Fines and Damaged / Lost) | |

## 7B. Fine Payment screen (opens after an overdue return)

| TC | Role | Steps | Expected | Pass |
|---|---|---|---|---|
| 7B.01 | Librarian | Return L014 (Aisha Khan, overdue) | Fine Payment screen opens for F011 | |
| 7B.02 | Librarian | Look at the screen | Member details (ID, name, type, ID no, email, phone, address, status), loan and book details (loan, book, ISBN, issued, due, returned, fine per day) shown read-only | |
| 7B.03 | Librarian | Look at the entry fields | Row 1 (display only): Fine amount 8.00, Payment Status Unpaid, Waiver type Not Waived. Row 2: Waived amount (0.00) and Payment method * (mandatory). Under them: Net amount to pay (larger font) under Waived amount, Remarks under Payment method | |
| 7B.04 | Librarian | Choose method Cash, press **Confirm Payment** | Payment Status changes to Paid on screen; a confirmation box appears ("Confirm payment of £8.00 by Cash for fine F011 from M002 - Aisha Khan?", IDs bold red); Cancel keeps the screen; Confirm saves: Paid, Cash, paid date today; returns to Return a Book | |
| 7B.04b | Librarian | Waived amount = fine amount (8.00) | Payment Status shows Waived, method switches to No charge; Confirm Payment asks "Confirm full waiver of £8.00 for fine F011 ...?"; Confirm saves Waived / No charge | |
| 7B.05 | Librarian | Leave Payment method on "- Select method -" (empty) and press Confirm Payment | Payment method is mandatory: the browser stops the form ("Please select an item"), no confirmation box appears; if posted directly the server refuses with "Payment method is mandatory ..."; nothing saved | |
| 7B.06 | Librarian | Waived amount 2.00, method Card | Payment Status Paid, Waiver type shows Partially Waived, net 6.00; saved Paid / Card / Partially Waived | |
| 7B.07 | Librarian | Waived amount = fine (8.00) | Waiver type Fully Waived, Payment Status Waived, method No charge, net 0.00; saved after Confirm | |
| 7B.08 | Librarian | (Posted directly) method No charge with waived below the fine | "'No charge' is only for a fully waived fine" | |
| 7B.09 | Librarian | Waived amount larger than the fine amount | "Cannot be more than the fine amount" | |
| 7B.10 | Librarian | Payment Status box | Cannot be typed in; it follows the waived amount and method | |
| 7B.11 | Librarian | Waive all on Manage Fines / Damaged-Lost | Status Waived, payment_method No charge; partial waiver keeps Unpaid with method empty | |
| 7B.12 | Librarian | Try to type in the Fine amount box | Not editable: it is a display-only calculated value and not mandatory; the value saved is the calculated fine | |
| 7B.13 | Librarian | Press **Pay Later - Back to Return a Book** | Returns to Return a Book; fine F011 stays Unpaid (shows in Manage Fines) | |
| 7B.14 | Librarian | Open the same payment screen again after it is Paid | Shows "already settled"; no entry fields | |
| 7B.15 | Librarian | Open Manage Fines, Damaged / Lost, My Fines / My Charges (member) and the Fines / Damaged-Lost reports | Columns after the fine/amount: **Payment Status**, **Waiver type**, then Waived and Net | |
| 7B.15b | Admin | Return a Librarian's overdue loan as Admin | Same screen opens for the Admin | |
| 7B.16 | Member | Open `/fines/F011/payment` | 403 Not allowed | |
| 7B.17 | Librarian | After Pay Later, pay the fine from Manage Fines | Works as in 9.03 | |

## 8. Reservations

| TC | Role | Steps | Expected | Pass |
|---|---|---|---|---|
| 8.01 | Member (omar) | Reserve B008 | "Reservation placed"; status Pending, position after R001, R002 | |
| 8.02 | Member (omar) | Reserve B008 again | "Already have an active reservation" | |
| 8.03 | Member (aisha) | Reserve B009 (she has it on loan) | "You already have this book on loan" | |
| 8.04 | Member (omar) | Cancel his reservation | Cancelled | |
| 8.05 | Member (priya) | Cancel R001 of another member | Not found / refused | |
| 8.06 | Librarian | Open Reservations (Active tab), then the All tab | Active tab: R001, R002, R003; All tab adds R004-R006 (history) | |
| 8.06a | Librarian / Admin | Reservations list headings | ID, Member Name / ID, Book / ID, Shelf, Reserved, Status, Hold until, Loan (member ID and book ID shown under the name and title) | |
| 8.06b | Librarian / Admin | Reservations: press **Issue** on R003, then Confirm | Confirmation "Issue book B006 - A Brief History of Time to M006 - Jamal Rahman (reservation R003)?" (IDs bold red); Cancel in the box does nothing; Confirm issues the book at once (no Issue Books screen): message "This book B006 ... is issued to M006 - Jamal Rahman (reservation R003). Loan L040, due back ...", R003 becomes Fulfilled with the loan, B006 available 1 -> 0 | |
| 8.06c | Librarian / Admin | Reservations: press **Cancel** on R001 | Confirmation "Cancel reservation R001 of book B008 - Clean Architecture for M004 - Priya Nair?" (IDs bold red); Cancel in the box keeps it; Confirm cancels ("Reservation R001 cancelled.") | |
| 8.07 | Librarian | Cancel R003 (Ready) | Cancelled; the hold is released | |
| 8.08 | Librarian | Press Expire old holds after the hold date passed | Ready reservations past date become Expired, next person promoted | |
| 8.09 | Member (omar) | Reserve a book that has free copies (B011) | Reservation becomes Ready at once (copy held) | |
| 8.10 | Member (emma) | Reserve (account inactive) | Cannot log in | |

## 9. Fines and payments

| TC | Role | Steps | Expected | Pass |
|---|---|---|---|---|
| 9.01 | Librarian | Manage Fines - All and Unpaid tabs | Columns: Fine ID / Date, Member Name / ID, Book / ID, Loan ID, Fine, Waived, Net, Waiver type, Payment Status, Actions; Actions has one **Payment** button on Unpaid rows (none on Paid / Waived rows in the All tab) | |
| 9.01b | Librarian | Manage Fines - Paid and Waived tabs | Same column titles and order as All / Unpaid (Fine ID / Date ... Payment Status); no Actions column and no buttons | |
| 9.01c | Librarian | Press **Payment** on F001 | Opens the Fine Payment screen for F001 (member and loan details, payment box); "Pay Later - Back to Manage Fines" returns to Manage Fines without saving; Confirm Payment saves and returns to Manage Fines | |
| 9.02 | Librarian | Press "Calculate fines for overdue loans" | F011 (L014) and F012 (L015) created; running it again only re-prices them | |
| 9.03 | Librarian | Payment button on F001, method Cash, Confirm Payment | Paid; paid date today; method Cash | |
| 9.04 | Librarian | Open the F001 payment screen again | Shows "already settled"; no entry fields | |
| 9.05 | Librarian | Payment screen for F006 without choosing a method | Browser stops the form (method mandatory) | |
| 9.06 | Librarian | Payment screen for F006, method Card | Paid | |
| 9.07 | Librarian | Payment screen for F007: waived 2.00, method Cash | Partially Waived, Paid; net 3.00 | |
| 9.08 | Librarian | Payment screen for F009: waived more than 1.50 | "The waived amount cannot be more than the fine amount" | |
| 9.09 | Librarian | Payment screen for F009: waived 1.50 | Waiver type Fully Waived, status Waived, No charge; net 0.00 | |
| 9.10 | Librarian | Pay F002 (already Paid) / F003 (Waived) | Refused | |
| 9.10b | Librarian | Look at Payment Status of a Waived fine (F003) | Same layout as Paid: badge, then date and method on the next line ("14 Sep ... · No charge"); the date is the waiver date | |
| 9.11 | Librarian | Check sample F004 | Fine 6.00, waived 2.00, net 4.00, Partially Waived, Unpaid | |
| 9.12 | Admin | Admin-only reports "Fines - amount check" | Every row shows OK (net = fine - waived) | |
| 9.13 | Member (aisha) | My Fines | Only F001, F004 (and her new fines) | |
| 9.14 | Member | Pay button | Not shown (staff records payment) | |

## 10. Damaged, scrapped and lost

| TC | Role | Steps | Expected | Pass |
|---|---|---|---|---|
| 10.01 | Librarian | Record B011 Damaged, no loan, amount 0 | Saved as "No charge" with the record date saved as the payment date (shown under Payment Status: "<date> · No charge"); B011 Damaged +1, Available -1 | |
| 10.02 | Librarian | Record B011 Lost with amount 10 and no loan | "To charge an amount, select the loan the book was borrowed on." | |
| 10.03 | Librarian | Record B011 Lost from the shelf, amount 0 | Lost +1, Available -1 | |
| 10.03b | Librarian | Record B011 Scrapped from the shelf, amount 0 | Scrapped +1 (Damaged and Lost unchanged), Available -1 | |
| 10.04 | Librarian | Record B010 Lost on loan L016, amount 54 | Loan L016 becomes Lost; its return date = today; lost +1; charge Unpaid 54.00 | |
| 10.05 | Librarian | Record B010 Scrapped and choose loan L016 (not possible: choose Type Scrapped and look at the Loan list; or force it by address) | When Type = Scrapped the Borrowed-on-loan list and the Amount are disabled (greyed, loan cleared, amount 0); if forced, "A scrapped copy is taken from the shelf: it cannot be linked to a loan or charged to a member." and nothing is saved | |
| 10.05e | Librarian | Scrapped with an Amount of 5 (forced) | Same message; nothing saved | |
| 10.05b | Librarian | Record B010 Damaged on loan L016 | Loan returned; Damaged +1; charge as entered | |
| 10.05c | Librarian | Record Damaged/Scrapped/Lost when Available is 0 and no loan chosen | "There is no available copy on the shelf to mark as ..."; nothing saved | |
| 10.05d | Admin/DB | Update books.scrapped_copies so that total < available + damaged + lost + scrapped | Rejected by CHECK chk_books_counts (the app checks the same rule before saving: "Not saved: total copies (n) must be at least available + damaged + lost + scrapped (m)") | |
| 10.06 | Librarian | Record a record with a loan for a different book | "Loan does not belong to the selected book" | |
| 10.07 | Librarian | Record a negative amount | "Cannot be negative" | |
| 10.08 | Librarian | Scrap B009 shelf copy while Available is 0 | "No available copy on the shelf to mark as scrapped" | |
| 10.09 | Librarian | Payment button on DL001, method Card, Confirm Payment | Paid; saved date and Card shown under Payment Status | |
| 10.10 | Librarian | Payment screen of DL005: waived 5.00 (= amount) | Waiver type Fully Waived, status Waived, method No charge, waiver date saved | |
| 10.13 | Librarian | Open Damaged / Scrapped / Lost (All, Unpaid) | Columns: ID / Date, Type, Book / ID, Member Name / ID, Loan ID / Date, Amount, Waived, Net, Waiver type, Payment Status, Actions; **Payment** button only on Unpaid rows with an amount | |
| 10.14 | Librarian | Paid, Waived and No charge tabs | Same column titles; no Actions column and no buttons | |
| 10.15 | Librarian | Press Payment on DL001 | "Damaged / Scrapped / Lost Payment" screen: member box (left), book and loan box (right), payment box centred: Amount (read-only), Payment Status, Waiver type (display only), Waived amount, Payment method * (mandatory), Remarks, Net amount | |
| 10.16 | Librarian | Confirm Payment with Card on DL001 | Confirmation box with bold red IDs; Confirm saves Paid and returns to the list; "Pay Later - Back to Damaged / Scrapped / Lost" saves nothing | |
| 10.17 | Librarian | Open the payment screen of DL002 (no charge) or DL003 (Paid) | "Already settled or has no charge"; no entry fields | |
| 10.18 | Librarian | Record screen: fill the form and press **Save record** | Confirmation box "Save lost record for book B011 - ... from the shelf, amount £12.50?" (IDs bold red); Cancel in the box saves nothing; Confirm saves | |
| 10.19 | Librarian | Press **Cancel** on the record screen | No action and nothing saved; the screen only refreshes (empty form) | |
| 10.20 | Librarian | Press **Return to Damaged / Scrapped / Lost** | Goes to the Damaged / Scrapped / Lost list without saving | |
| 10.21 | Librarian | Open the record screen and look at the Book list | Only books whose Available (as on Manage Books, after held copies) is above 0 are listed: B002, B006, B008, B009 (Available 0) are not; opened from a loan's Lost button, that loan's book is still listed | |
| 10.22 | Librarian | Open Issue Books and look at the Book suggestions | Same rule: books with Available 0 (B002, B006, B008, B009) are not suggested | |
| 3.11c | Librarian | Manage Books, book B006 | Available 0 shown with "(+1 held)" next to it | |
| 10.11 | Librarian | Record against a Librarian's loan | Only Admin allowed | |
| 10.12 | Member (priya) | My Charges | DL001 and DL005 | |

## 11. Reports

| TC | Role | Steps | Expected | Pass |
|---|---|---|---|---|
| 11.01 | Librarian | Open each of the 7 reports | Rows shown; Overdue report lists L014, L015 | |
| 11.02 | Librarian | Download CSV and PDF of Fines | Files open with the same rows | |
| 11.02a | Librarian / Admin | Download PDF of any report | Every page: header (all bold): left "SmLib", centre report title only in capitals (e.g. MY PREVIOUS LOANS, no member name), right "ID Member name" of the logged-in user; footer (all bold): left date and time, right "Page current/total" (e.g. Page 1/2) | |
| 11.02b | Librarian | Open the PDF file properties / fonts of any report | Header and footer text use a bold font (Helvetica-Bold) | |
| 11.03 | Librarian | Print view | Clean page, no menu | |
| 11.04 | Librarian | Open the Admin-only amount-check report URL | 403 | |
| 11.05 | Admin | Open the 2 amount-check reports | Visible; all rows OK | |
| 11.06 | Member | My Reports: all 9 report tabs (see 11.08-11.16) | Only own data | |
| 11.08 | Member (aisha) | My Reports > My Current Loans | L011, L014, L019; Books on loan 3, Overdue 1 | |
| 11.09 | Member (aisha) | My Reports > My Previous Loans | L001, L004, L007 (returned or lost loans only) | |
| 11.10 | Member (aisha) | My Reports > My Borrowing History | All 6 loans (L001, L004, L007, L011, L014, L019): Returned 3, On loan now 3; an overdue open loan shows Overdue | |
| 11.11 | Member (aisha) | My Reports > My Overdue Loan | Only L014 with days overdue 16 and Estimated fine 8.00 | |
| 11.12 | Member (jamal) | My Reports > My Active Reservation | R003 (Ready, hold until date); Ready to collect 1 | |
| 11.13 | Member (jamal) | My Reports > My Reservation History | R006 (Expired) only; active reservations are not listed | |
| 11.14 | Member (daniel) | My Reports > My Payment History | F002, F005, DL003 with payment method and payment date; Total paid 30.00 | |
| 11.15 | Member (aisha) | My Reports > Unpaid Fines & Charges | F001, F004; Total unpaid 9.00 | |
| 11.16 | Member (daniel) | My Reports > Paid Fines & Charges | F002, F005, DL003; Total paid 30.00 | |
| 11.17 | Member | Download PDF / CSV of each of the 9 reports | Each opens; PDF title in capitals (e.g. MY BORROWING HISTORY) with the member's ID and name on the right | |
| 11.18 | Member (aisha) | My Borrowing History: From date = 11 days ago, Show report | Only loans issued on/after that date (L011, L019); summary counts recalculate; a "Period" box shows the dates | |
| 11.19 | Member (aisha) | My Borrowing History: From and To dates covering only her September loans | Only loans issued inside the range; none outside | |
| 11.20 | Member (aisha) | My Overdue Loan: From = today / To = yesterday / last 30 days | From today: none; To yesterday: L014 (filters on due date); last 30 days: L014 | |
| 11.21 | Member (jamal) | My Active Reservation / My Reservation History with dates | Filters on Reserved date: R003 shows in last 30 days, not from today; history range from 5 days ago shows none | |
| 11.22 | Member | Unpaid / Payment History / Paid with dates | Unpaid (aisha) from today: none, from 400 days ago: F001, F004; Payment History and Paid (daniel) filter on payment date | |
| 11.23 | Member | Enter an invalid date, or From later than To | "From date is not a valid date" / "From date cannot be after To date, so the date filter was not applied"; report shows without the filter | |
| 11.24 | Member (aisha) | Apply a date range, then Download PDF and CSV | Both contain only the filtered rows; PDF shows the Period line; tabs and download links keep the dates | |
| 11.25 | Member | Open any of the 9 reports | From date, To date, Show report, Clear dates and quick ranges (Last 30 days, This month, This year) are shown; the filter box is hidden when printing | |
| 11.26 | Member | Open the loan and reservation reports | Bottom row **Total** with the record count (e.g. aisha My Current Loans: 3 record(s)); My Overdue Loan bottom row **Net Total** = sum of Estimated fine (8.00); a report with no rows has no total row | |
| 11.27 | Member | Open Unpaid Fines & Charges, Payment History and Paid Fines & Charges | Bottom row **Net Total** sums Amount, Waived and Net columns (aisha Unpaid: 15.00 / 2.00 / 13.00 style totals from the rows shown; daniel Payment History / Paid net 30.00) | |
| 11.28 | Member | Download CSV and PDF of a report | The Net Total row is the last line of the CSV and the last row of the PDF table; totals follow the date filter | |
| 11.07 | Member | Open a staff report URL (`/reports/...`) | 403 | |

## 11B. Librarian Reports (Librarian login: menu Reports)

The Librarian gets the same report engine as the Administrator (parameters, Download PDF, Download CSV, Print, Net Total / Total row) for the list, circulation and fine reports only.

| TC | Role | Steps | Expected | Pass |
|---|---|---|---|---|
| 11B.01 | Librarian / Member | Menu Reports, open each report; try the Administrator-only addresses | 13 reports: Members List, Category List, Author List, Publication List, Book Inventory, Loan, Today Loan, Reservation Report, Most Borrowed Books, Fine, Damaged, Lost, Scrapped. Dashboard & Statistics, System Activity, Librarian List and Library Revenue Report give 403; Member 403; logged out goes to Login | |
| 11B.02 | Librarian | Members List: Member type, Status, Join date from / to | Member type offers Student and Staff only (no Librarian); 40 members (30 Students + 10 Staff); Staff 10; Inactive = M007; join date range filters | |
| 11B.03 | Librarian | Open every report and its parameters | Book Inventory (All, Lost, Damaged, Scrapped, Available); Loan (All, Issued, Returned, Overdue, Lost + dates); Today Loan (Status); Reservation Report (Status, Reserve date from / to, Expiry date from / to); Most Borrowed Books (Top N + dates); Fine / Damaged / Lost (Payment status, Waiver type, Payment method, From / To date); Scrapped (From / To date); Category, Author, Publication lists have no parameters. Rows equal the Administrator's | |
| 11B.04 | Librarian | Download PDF and CSV of each report, with parameters | Files open; PDF header SmLib / TITLE / "M001 Sarah Collins" and footer date-time / Page n/N; parameters carried; coloured Download PDF, Download CSV, Print bar | |
| 11B.05 | Librarian | Look at the menu and the dashboard buttons | "Reports" in the menu and on the dashboard; page title "Reports" (the Administrator sees "Administrator Reports") | |
| 11B.06 | Librarian / Admin | Reservation Report: Status (All, Pending, Ready, Fulfilled, Cancelled, Expired), Reserve date from / to, Expiry date from / to, alone and combined | Lists reservation ID, reserved on, member, book, status, hold-until / expiry date and loan; Status gives only that status (e.g. Ready = R003); date ranges filter on the reserved date and the expiry date; bottom row Total with the record count; same rows for the Administrator; From later than To is refused with a message | |
| 11B.07 | Librarian / Admin | Today Loan: open before any loan is issued today, issue two books, return one, then open again; Status All / Issued / Returned / Lost | Before: "Nothing to show". After: only the loans issued today (loan, member, book, issued, due, returned / lost on, issued by, status); Status gives only that status; bottom row Total with the record count; same rows for the Administrator | |

## 11A. Administrator Reports (Admin only: menu Administration > Administrator Reports)

Every report has its own parameters (shown above the table), a **Show report** / **Reset** button, Download PDF, Download CSV and Print. The parameters are carried into the PDF and CSV, the PDF shows a "Parameters" line, and the bottom row is **Net Total** (reports with money) or **Total** (counts).

| TC | Role | Steps | Expected | Pass |
|---|---|---|---|---|
| 11A.01 | Admin / Librarian / Member | Open each of the 17 report URLs | Admin: all 17 open; Librarian: the 4 Administrator-only reports (Dashboard & Statistics, System Activity, Librarian List, Library Revenue Report) give 403 (the other 13 are in 11B); Member: 403; logged out: redirected to Login | |
| 11A.02 | Admin | Dashboard & Statistics | Statistics: 12 book titles, 12 available copies, 8 on loan, 29 active students, 10 active staff, 5 active librarians, 2 overdue loans, 3 active reservations, unpaid / paid / waived money | |
| 11A.03 | Admin | System Activity; Activity = Fine; Activity = Book returned with From date | All 6 activity kinds listed newest first (Book issued, Book returned, Fine, Damaged / Scrapped / Lost, Reservation, Member joined) with "Done by"; filters give only that kind and date range | |
| 11A.04 | Admin | Members List: Member type Student / Staff, Status All / Active / Inactive, Join date from / to | Member type offers Student and Staff only (no Librarian). All = 40 (30 Students + 10 Staff); Student 30; Staff 10; Active 39; Inactive = M007; Staff + Inactive = none ("Nothing to show"); Join date range shows only members who joined between the two dates (From tomorrow = none) | |
| 11A.05 | Admin | Librarian List: Status All / Active / Inactive, Join date from / to, then deactivate michael and repeat | 5 / 5 / none; Join date range shows only librarians who joined between the two dates; afterwards Inactive = M005, Active = 4 | |
| 11A.06 | Admin | Category List, Author List, Publication List | One row per record; Books column counts the books; bottom Total = 12 books | |
| 11A.07 | Admin | Book Inventory: Show All / Available / Damaged / Lost / Scrapped | 12 / 9 / B001 B002 B003 / B004 B005 / B010; bottom Total sums Total, Available, On loan, Damaged, Lost, Scrapped | |
| 11A.08 | Admin | Loan: status All / Issued / Returned / Overdue / Lost, and From / To issue dates | Counts equal the loans table; Overdue = L014, L015; Lost = L018, L022 | |
| 11A.09 | Admin | Look for Overdue Loans in the report list; use Loan > Loan status = Overdue | No separate Overdue Loans report; overdue loans are listed by Loan with Overdue (L014, L015) | |
| 11A.10 | Admin | Most Borrowed Books: Top 10 / 20 / 50 / All, From / To dates | Ranked 1..n by Times borrowed, highest first; Top All lists every borrowed book | |
| 11A.11 | Admin | Fine: Payment status, Waiver type, Payment method, From / To fine date (each alone and combined) | Rows equal the same query on the fines table, e.g. Unpaid = F001 F004 F006 F007 F009 F010; Paid + Cash = F002 F008 | |
| 11A.12 | Admin | Fine report bottom row | **Net Total** of Fine, Waived and Net; with a filter the total covers only the rows shown | |
| 11A.13 | Admin | Damaged: Payment status (Unpaid / Paid / Waived / No charge), Waiver type, Payment method, dates | Only Damaged records (DL002, DL005, DL007); every filter matches the database | |
| 11A.14 | Admin | Lost: same parameters as 11A.13 | Only Lost records (DL001, DL006); every filter matches the database | |
| 11A.15 | Admin | Scrapped: From / To dates only | Scrapped records DL003, DL004; only the two date parameters are offered; From today shows "Nothing to show" | |
| 11A.16 | Admin | Look at the parameters of each report | Today Loan: Status; Reservation Report: Status + Reserve date from / to + Expiry date from / to; Members: Member type (All, Student, Staff) + Status + Join date from / to; Librarians: Status + Join date from / to; Inventory: Show; Loan: Loan status + dates; Fine / Damaged / Lost: Payment status, Waiver type, Payment method, dates; Scrapped: dates; Library Revenue Report: Month from / Month to / Type / Payment status | |
| 11A.17 | Admin | Enter an invalid date, From later than To, or a made-up option in the URL | Message shown; the dates are ignored; unknown options fall back to All | |
| 11A.18 | Admin | Download PDF and CSV of all 17 reports, with parameters | PDF header (SmLib / report title in capitals / U001 System Administrator) and footer (date time / Page n/N); a Parameters line (e.g. "Payment status: Unpaid; Payment method: Cash"); CSV holds the filtered rows plus the total line | |
| 11A.19 | Admin | Look at the last row of each report | **Net Total** (money reports) or **Total** with "n record(s)" | |
| 11A.20 | Admin / Librarian | Look at the menu | "Administrator Reports" under Administration for the Admin only | |
| 11A.21 | Admin | Library Revenue Report (no parameters) | One row per month (Sep 2026, Oct 2026) with three separate groups: Fines (count, charged, waived, net), Damaged (records, charged, waived, net; includes scrapped copies) and Lost (records, charged, waived, net), then Total net revenue, Collected (Paid), Outstanding (Unpaid). Bottom **Net Total** equals the database: fines net 37.50, damaged net 26.00, lost net 8.99, total 72.49, collected 37.00, outstanding 35.49 | |
| 11A.22 | Admin | Library Revenue Report: Month from / Month to / Type / Payment status (month pickers), single month, wide range, From later than To, invalid month | Only the chosen months are listed (months without any money show as zero rows); From later than To shows "cannot be after" and ignores the months; invalid month shows "not a valid month" | |
| 11A.23 | Admin | Library Revenue Report: Download PDF and CSV with Month from / to | PDF header LIBRARY REVENUE REPORT, a Parameters line (Month from: Sep 2026; Month to: Oct 2026); CSV has header, one line per month and the total line | |
| 11A.24 | Admin | Open each Administrator Report and look above the table | "Export this report" bar with three buttons: **Download PDF** (red), **Download CSV** (green), **Print** (dark). PDF and CSV use the selected parameters; Print prints only the title, parameters and table (menu, filters and buttons hidden) | |
| 11A.25 | Admin | Library Revenue Report: Type (All / Fine / Damaged / Lost), Payment status (All / Paid / Unpaid), Payment method (All / Cash / Card / No charge), Waiver type (All / Not Waived / Partially Waived / Fully Waived), each alone and combined | Type shows only that group's columns; Paid: Outstanding 0; Unpaid: Collected 0; Cash / Card / No charge and each Waiver type give only the matching fines and damaged / lost records. All totals equal the database | |
| 11A.26 | Librarian / Member / Admin | Open any report (Librarian Reports, My Reports, Administrator Reports) and look above the table | The same "Export this report" bar: **Download PDF** (red), **Download CSV** (green), **Print** (dark) (no buttons left in the blue page header) | |
| 11A.27 | Admin / Librarian / Member | Look at the left menu and the dashboard buttons of each role | Admin: only **Administrator Reports** (the separate "Reports" option is removed from the menu, and the dashboard button opens Administrator Reports); Librarian: "Reports" (new, see 11B); Member: "Reports" (My Reports) unchanged | |

## 12. System settings (Admin)

| TC | Steps | Expected | Pass |
|---|---|---|---|
| 12.01 | Open System Settings | 6 settings with current values (incl. renewal_after_days = 10) | |
| 12.02 | Enter "abc" for loan days | Validation message; nothing saved | |
| 12.03 | Set fine per day to 1.00, return an overdue loan | Fine uses 1.00 per day | |
| 12.04 | Set max books to 2, issue to a member with 2 loans | Refused | |
| 12.05 | Add a new setting | Saved; Updated by = admin | |

## 13. Dashboards

| TC | Role | Expected | Pass |
|---|---|---|---|
| 13.01 | Admin / Librarian | First load of sample data shows: Total Books 20, Book available copies 12, Books on loan 8, Overdue loans 2, Unpaid fines & charges 35.49, Active librarians 5, Active members (Student) 29, Active members (Staff) 10, Active reservations 3 | |
| 13.02 | Member | Own active loans, due soon (L012 for daniel), unpaid total | |
| 13.03 | Member (jamal) | Reservations page shows R003 Ready with its hold date until the book is issued | |

## 14. Data integrity (database)

| TC | Check | Expected | Pass |
|---|---|---|---|
| 14.01 | `SELECT * FROM fines` | `net_amount` equals `fine_amount - waived_amount` for every row | |
| 14.02 | Try `INSERT INTO fines ... waiver_type='Partially Waived', waived_amount=0` | Rejected by CHECK chk_fines_waiver | |
| 14.03 | Try Fully Waived with paid_status Unpaid | Rejected by CHECK | |
| 14.04 | Try paid_status Paid without paid_date | Rejected by CHECK | |
| 14.05 | Try updating a book to available_copies = -1 | Rejected by CHECK | |
| 14.06 | Try Fulfilled reservation with loan_id NULL | Rejected by CHECK | |
| 14.07 | Try deleting a member who has loans | Rejected (foreign key) | |
| 14.08 | Try a user role Admin with member_id set | Rejected by CHECK | |
| 14.09 | Try two loans fines for the same loan | Rejected (UNIQUE loan_id) | |
| 14.09b | Try a Lost loan without a return date: `UPDATE loans SET status='Lost', return_date=NULL WHERE loan_id='L011';` | Rejected by CHECK chk_loans_return | |
| 14.10 | `python scripts/check_setup.py` | All checks OK | |
| 14.11 | `python scripts/update_overdue_fines.py` | Fines created/updated, old holds expired | |

## Appendix A - all 45 members

| Member ID | Name | Type | Status | ID no | Username |
|---|---|---|---|---|---|
| M001 | Sarah Collins | Librarian | Active | LIB-001 | librarian |
| M002 | Aisha Khan | Student | Active | STU2026001 | aisha |
| M003 | Daniel Okoye | Student | Active | STU2026002 | daniel |
| M004 | Priya Nair | Staff | Active | STF1001 | priya |
| M005 | Michael Brown | Librarian | Active | LIB-002 | michael |
| M006 | Jamal Rahman | Student | Active | STU2026003 | jamal |
| M007 | Emma Wilson | Student | Inactive | STU2026004 | emma |
| M008 | Robert Taylor | Staff | Active | STF1002 | robert |
| M009 | Lina Haddad | Student | Active | STU2026005 | (no login) |
| M010 | Omar Farouk | Staff | Active | STF1003 | omar |
| M011 | Kelvin Gibbah | Librarian | Active | LIB-003 | kelvin |
| M012 | Abigel Sara Fosu | Librarian | Active | LIB-004 | abigel |
| M013 | Timothy Anthony Shakespeare | Librarian | Active | LIB-005 | timothy |
| M014 | Mujibur Rehman | Staff | Active | STF1004 | mujibur |
| M015 | Wasim Khan Raja | Staff | Active | STF1005 | wasim |
| M016 | Grace Mensah | Staff | Active | STF1006 | gracemensah |
| M017 | Henry Clarke | Staff | Active | STF1007 | henry |
| M018 | Fatima Zahra | Staff | Active | STF1008 | fatimazahra |
| M019 | Peter Osei | Staff | Active | STF1009 | peter |
| M020 | Naomi Adeyemi | Staff | Active | STF1010 | naomi |
| M021 | Yakeen Ahmed | Student | Active | STU2026006 | yakeen |
| M022 | Lutfiyah Begum | Student | Active | STU2026007 | lutfiyah |
| M023 | Sophie Turner | Student | Active | STU2026008 | sophie |
| M024 | Liam O'Connor | Student | Active | STU2026009 | (no login) |
| M025 | Mei Lin Chen | Student | Active | STU2026010 | meilin |
| M026 | Carlos Mendes | Student | Active | STU2026011 | carlos |
| M027 | Zainab Hussain | Student | Active | STU2026012 | zainab |
| M028 | Ethan Walker | Student | Active | STU2026013 | ethan |
| M029 | Chloe Martin | Student | Active | STU2026014 | chloe |
| M030 | Noah Patel | Student | Active | STU2026015 | noahpatel |
| M031 | Isabella Rossi | Student | Active | STU2026016 | isabella |
| M032 | Kwame Boateng | Student | Active | STU2026017 | kwame |
| M033 | Amara Okafor | Student | Active | STU2026018 | amara |
| M034 | Oliver Smith | Student | Active | STU2026019 | oliver |
| M035 | Fatima Noor | Student | Active | STU2026020 | fatimanoor |
| M036 | Lucas Silva | Student | Active | STU2026021 | lucas |
| M037 | Hannah Cohen | Student | Active | STU2026022 | hannah |
| M038 | Ibrahim Yusuf | Student | Active | STU2026023 | ibrahim |
| M039 | Grace Ellis | Student | Active | STU2026024 | graceellis |
| M040 | Tariq Mahmood | Student | Active | STU2026025 | (no login) |
| M041 | Nia Johnson | Student | Active | STU2026026 | nia123 |
| M042 | Arjun Singh | Student | Active | STU2026027 | arjun |
| M043 | Ruth Adeyemi | Student | Active | STU2026028 | ruth123 |
| M044 | Victor Petrov | Student | Active | STU2026029 | victor |
| M045 | Elena Garcia | Student | Active | STU2026030 | elena |

Passwords: Librarians `Librarian@123`, Staff and Students `Member@123`.
