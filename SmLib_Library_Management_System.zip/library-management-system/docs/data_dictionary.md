# SmLib - Data Dictionary (schema v2)

Generated from `database/schema.sql` (MySQL 8.0.16+). PK = primary key, FK = foreign key, UK = unique. D-numbers follow the Level 0 DFD.


## D1 users

| Column | Type | Null | Key | Notes |
|---|---|---|---|---|
| user_id | VARCHAR(10) | NO | PK | Primary key, e.g. U001 |
| username | VARCHAR(50) | NO | UK |  |
| password_hash | VARCHAR(255) | NO |  | Store a password hash, never plaintext |
| user_role | ENUM | NO |  |  |
| status | ENUM | NO |  |  |
| member_id | VARCHAR(10) | YES | FK,UK | Required for Member/Librarian; NULL for Admin |
| full_name | VARCHAR(120) | YES |  | Required for Admin (Admin has no members row) |
| email | VARCHAR(120) | YES | UK |  |
| created_date | TIMESTAMP | NO |  |  |

**Foreign keys:** `member_id` -> `members.member_id`

**Check constraints:** `chk_users_member_role`, `chk_users_admin_name`

## D2 members

| Column | Type | Null | Key | Notes |
|---|---|---|---|---|
| member_id | VARCHAR(10) | NO | PK | Primary key, e.g. M001 |
| id_no | VARCHAR(50) | NO | UK | Student, staff, or librarian college ID |
| member_name | VARCHAR(120) | NO |  |  |
| email | VARCHAR(120) | NO | UK |  |
| phone | VARCHAR(50) | YES |  |  |
| address | VARCHAR(255) | YES |  |  |
| member_type | ENUM | NO |  |  |
| status | ENUM | NO |  |  |
| joined_date | DATE | NO |  |  |
| expiry_date | DATE | YES |  | Membership end date. Set to the current date when the member is made Inactive; NULL again when made Active |

**Check constraints:** `chk_members_expiry`

## D3 books

| Column | Type | Null | Key | Notes |
|---|---|---|---|---|
| book_id | VARCHAR(10) | NO | PK | Primary key, e.g. B001 |
| title | VARCHAR(200) | NO |  |  |
| isbn | VARCHAR(20) | YES | UK |  |
| author_id | VARCHAR(10) | NO | FK |  |
| publisher_id | VARCHAR(10) | NO | FK |  |
| category_id | VARCHAR(10) | NO | FK |  |
| publish_year | INT | YES |  |  |
| edition | VARCHAR(100) | YES |  |  |
| price | DECIMAL(8,2) | YES |  | Suggested replacement cost |
| shelf_location | VARCHAR(30) | YES |  | Shelf code, e.g. A-01 |
| product_description | VARCHAR(255) | YES |  | Short description of the book shown on the book pages |
| cover_page | LONGBLOB | YES |  | Cover image stored as binary data (PNG, JPEG, GIF or WEBP, up to 2 MB). MySQL has no IMAGE type, so an image is kept in a BLOB column. Served by `/books/<id>/cover`; lists never select this column |
| total_copies | INT | NO |  |  |
| available_copies | INT | NO |  | Excludes issued, damaged, lost, and reservation-held copies |
| damaged_copies | INT | NO |  |  |
| lost_copies | INT | NO |  |  |
| scrapped_copies | INT | NO |  |  |
| created_by | VARCHAR(10) | NO | FK |  |
| created_date | TIMESTAMP | NO |  |  |

**Foreign keys:** `author_id` -> `authors.author_id`, `publisher_id` -> `publishers.publisher_id`, `category_id` -> `categories.category_id`, `created_by` -> `users.user_id`

**Check constraints:** `chk_books_counts`, `chk_books_price`

## D4 authors

| Column | Type | Null | Key | Notes |
|---|---|---|---|---|
| author_id | VARCHAR(10) | NO | PK | Primary key, e.g. A001 |
| author_name | VARCHAR(255) | NO |  |  |
| description | VARCHAR(255) | YES |  |  |
| created_by | VARCHAR(10) | NO | FK |  |
| created_date | TIMESTAMP | NO |  |  |

**Foreign keys:** `created_by` -> `users.user_id`

## D5 publishers

| Column | Type | Null | Key | Notes |
|---|---|---|---|---|
| publisher_id | VARCHAR(10) | NO | PK | Primary key, e.g. P001 |
| publisher_name | VARCHAR(120) | NO | UK |  |
| address | VARCHAR(200) | YES |  |  |
| email | VARCHAR(120) | YES |  |  |
| phone | VARCHAR(50) | YES |  |  |
| created_by | VARCHAR(10) | NO | FK |  |
| created_date | TIMESTAMP | NO |  |  |

**Foreign keys:** `created_by` -> `users.user_id`

## D6 categories

| Column | Type | Null | Key | Notes |
|---|---|---|---|---|
| category_id | VARCHAR(10) | NO | PK | Primary key, e.g. C001 |
| category_name | VARCHAR(80) | NO | UK |  |
| description | VARCHAR(255) | YES |  |  |
| created_by | VARCHAR(10) | NO | FK |  |
| created_date | TIMESTAMP | NO |  |  |

**Foreign keys:** `created_by` -> `users.user_id`

## D7 loans

| Column | Type | Null | Key | Notes |
|---|---|---|---|---|
| loan_id | VARCHAR(10) | NO | PK | Primary key, e.g. L001 |
| member_id | VARCHAR(10) | NO | FK |  |
| book_id | VARCHAR(10) | NO | FK |  |
| issue_date | DATE | NO |  |  |
| due_date | DATE | NO |  | Calculated using the configured loan period |
| return_date | DATE | YES |  | Date returned (status Returned) or date recorded as Lost (status Lost); empty while Issued |
| status | ENUM | NO |  |  |
| renewal_count | INT | NO |  |  |
| last_renewed_on | DATE | YES |  |  |
| issued_by | VARCHAR(10) | NO | FK |  |
| returned_to | VARCHAR(10) | YES | FK |  |

**Foreign keys:** `member_id` -> `members.member_id`, `book_id` -> `books.book_id`, `issued_by` -> `users.user_id`, `returned_to` -> `users.user_id`

**Check constraints:** `chk_loans_dates`, `chk_loans_renewal`, `chk_loans_return`

## D8 reservations

| Column | Type | Null | Key | Notes |
|---|---|---|---|---|
| reservation_id | VARCHAR(10) | NO | PK | Primary key, e.g. R001 |
| member_id | VARCHAR(10) | NO | FK |  |
| book_id | VARCHAR(10) | NO | FK |  |
| reservation_date | DATETIME | NO |  |  |
| status | ENUM | NO |  |  |
| expiry_date | DATE | YES |  |  |
| loan_id | VARCHAR(10) | YES | FK | Set when the reservation becomes a loan |

**Foreign keys:** `member_id` -> `members.member_id`, `book_id` -> `books.book_id`, `loan_id` -> `loans.loan_id`

**Check constraints:** `chk_reservations_ready_expiry`, `chk_reservations_fulfilled`

## D9 fines

| Column | Type | Null | Key | Notes |
|---|---|---|---|---|
| fine_id | VARCHAR(10) | NO | PK | Primary key, e.g. F001 |
| loan_id | VARCHAR(10) | NO | FK,UK |  |
| fine_amount | DECIMAL(8,2) | NO |  |  |
| waived_amount | DECIMAL(8,2) | NO |  |  |
| net_amount | DECIMAL(8,2) | YES |  | Generated column |
| paid_status | ENUM | NO |  |  |
| waiver_type | ENUM | NO |  |  |
| fine_date | DATE | NO |  |  |
| paid_date | DATE | YES |  |  |
| payment_method | ENUM | YES |  |  |
| remark | VARCHAR(255) | YES |  |  |
| created_by | VARCHAR(10) | NO | FK |  |

**Foreign keys:** `loan_id` -> `loans.loan_id`, `created_by` -> `users.user_id`

**Check constraints:** `chk_fines_amounts`, `chk_fines_waiver`, `chk_fines_waived_status`, `chk_fines_paid`

## D10 damage_lost

| Column | Type | Null | Key | Notes |
|---|---|---|---|---|
| damage_id | VARCHAR(10) | NO | PK | Primary key, e.g. DL001 |
| book_id | VARCHAR(10) | NO | FK |  |
| loan_id | VARCHAR(10) | YES | FK | NULL if no loan was involved |
| member_id | VARCHAR(10) | YES | FK | NULL if no member is charged |
| amount | DECIMAL(8,2) | NO |  |  |
| waived_amount | DECIMAL(8,2) | NO |  |  |
| net_amount | DECIMAL(8,2) | YES |  | Generated column |
| paid_status | ENUM | NO |  |  |
| waiver_type | ENUM | NO |  |  |
| record_date | DATE | NO |  |  |
| paid_date | DATE | YES |  |  |
| damage_type | ENUM | NO |  |  |
| payment_method | ENUM | YES |  |  |
| remark | VARCHAR(255) | YES |  |  |
| created_by | VARCHAR(10) | NO | FK |  |

**Foreign keys:** `book_id` -> `books.book_id`, `loan_id` -> `loans.loan_id`, `member_id` -> `members.member_id`, `created_by` -> `users.user_id`

**Check constraints:** `chk_dl_amounts`, `chk_dl_waiver`, `chk_dl_waived_status`, `chk_dl_paid`, `chk_dl_charge_link`

## D11 system_settings

| Column | Type | Null | Key | Notes |
|---|---|---|---|---|
| setting_id | VARCHAR(10) | NO | PK | Primary key, e.g. ST01 |
| setting_key | VARCHAR(100) | NO | UK |  |
| setting_value | VARCHAR(100) | NO |  |  |
| description | VARCHAR(255) | YES |  |  |
| updated_by | VARCHAR(10) | NO | FK |  |
| updated_at | TIMESTAMP | NO |  |  |

**Foreign keys:** `updated_by` -> `users.user_id`
