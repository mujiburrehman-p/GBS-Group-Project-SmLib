"""Application settings, loaded from environment variables / .env file."""
import os

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:  # python-dotenv is optional
    pass


class Config:
    SECRET_KEY = os.getenv("SECRET_KEY", "dev-only-change-me")
    DB_HOST = os.getenv("DB_HOST", "localhost")
    DB_PORT = int(os.getenv("DB_PORT", "3306"))
    DB_USER = os.getenv("DB_USER", "root")
    DB_PASSWORD = os.getenv("DB_PASSWORD", "")
    DB_NAME = os.getenv("DB_NAME", "library_db")
    APP_NAME = "SmLib"
    TAGLINE = "Library Management Solutions"
    MAX_CONTENT_LENGTH = 4 * 1024 * 1024          # largest request (a book cover is limited to 2 MB)
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = "Lax"
