"""SmLib - Library Management System (Flask application factory)."""
import logging
import os
from datetime import date

from urllib.parse import urlparse

import pymysql
from flask import Flask, g, session, redirect, request, url_for, flash, render_template

from config import Config
from app import db
from app.extensions import csrf_token, csrf_protect
from app.utils import to_date, BusinessError


APP_VERSION = "2026.10.01"
# Shown on the About page ("Developed By:"). Replace with your group members' names.
DEVELOPED_BY = [
    "Kelvin Gibbah",
    "Mujibur Rehman Pahavudeen",
    "Abigel Sara Fosu",
    "Wasim Khan Raja",
    "Timothy Anthony Shakespeare",
]


def create_app(config_object=Config):
    app = Flask(__name__)
    app.config.from_object(config_object)

    os.makedirs(os.path.join(app.root_path, "..", "logs"), exist_ok=True)
    logging.basicConfig(filename=os.path.join(app.root_path, "..", "logs", "error.log"),
                        level=logging.ERROR)

    app.teardown_appcontext(db.close_db)

    @app.before_request
    def load_user():
        g.user = session.get("user")
        csrf_protect()

    # ---------------------------------------------------------------- templates
    @app.context_processor
    def inject():
        return dict(csrf_token=csrf_token, current_user=g.get("user"), today=date.today(),
                    app_version=APP_VERSION, developed_by=DEVELOPED_BY, copyright_year=2026)

    @app.template_filter("d")
    def fmt_date(v):
        v = to_date(v)
        return v.strftime("%d %b %Y") if v else "-"

    @app.template_filter("dt")
    def fmt_dt(v):
        return str(v)[:16] if v else "-"

    def days_late(due):
        due = to_date(due)
        return max(0, (date.today() - due).days) if due else 0
    app.jinja_env.globals["days_late"] = days_late
    app.jinja_env.filters["opts"] = lambda rows, v, l: [(r[v], r[l]) for r in rows]

    @app.template_filter("gbp")
    def fmt_money(v):
        return f"\u00a3{float(v or 0):,.2f}"

    # ---------------------------------------------------------------- blueprints
    from app.blueprints.auth.routes import bp as auth_bp
    from app.blueprints.dashboard.routes import bp as dashboard_bp
    from app.blueprints.admin.routes import bp as admin_bp
    from app.blueprints.members.routes import bp as members_bp
    from app.blueprints.books.routes import bp as books_bp
    from app.blueprints.catalog.routes import bp as catalog_bp
    from app.blueprints.loans.routes import bp as loans_bp
    from app.blueprints.fines.routes import bp as fines_bp
    from app.blueprints.damage_lost.routes import bp as damage_bp
    from app.blueprints.reservations.routes import bp as reservations_bp
    from app.blueprints.reports.routes import bp as reports_bp
    from app.blueprints.my_reports.routes import bp as my_reports_bp
    from app.blueprints.admin_reports.routes import bp as admin_reports_bp
    for b in (auth_bp, dashboard_bp, admin_bp, members_bp, books_bp, catalog_bp,
              loans_bp, fines_bp, damage_bp, reservations_bp, reports_bp, my_reports_bp, admin_reports_bp):
        app.register_blueprint(b)
    app.register_blueprint(admin_reports_bp, url_prefix="/staff/reports", name="staff_reports")     # Librarian's Reports (same engine, fewer reports)

    @app.after_request
    def no_cache(resp):
        """Pages show live database data: never serve them from the browser cache (Back / Forward / Refresh)."""
        if request.endpoint != "static":
            resp.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
            resp.headers["Pragma"] = "no-cache"
            resp.headers["Expires"] = "0"
        return resp

    # ---------------------------------------------------------------- errors
    def back():
        """Where to send the user after a failed action (never back to the page that just failed)."""
        ref = request.referrer
        # After a failed POST, go back to the page the user was on (a GET page, so nothing is repeated).
        if ref and (request.method == "POST" or urlparse(ref).path != request.path):
            return redirect(ref)
        if request.endpoint != "dashboard.index":
            return redirect(url_for("dashboard.index"))
        return None

    def error_page(message, detail="", status=500):
        return render_template("errors/500.html", message=message, detail=detail), status

    @app.errorhandler(pymysql.MySQLError)
    def database_error(e):
        db.rollback()
        code = e.args[0] if e.args else 0
        detail = " ".join(str(a) for a in e.args)
        fatal = None
        if code in (1146, 1054, 1049):
            fatal = ("The database is missing tables or columns, so it was not installed completely. "
                     "Close the website, then run:  python scripts/setup_database.py --reset")
        elif code in (1045, 2002, 2003, 2006, 2013):
            fatal = ("Cannot talk to MySQL. Check that MySQL is running and that DB_USER / DB_PASSWORD "
                     "in the .env file are correct.")
        if fatal or request.method == "GET":
            logging.error("Database error: %s", detail)
            return error_page(fatal or "A database error occurred while loading this page.", detail)
        if code == 1062:
            msg = "That value already exists (for example a duplicate email, ID number, username or ISBN)."
        elif code in (1451, 1452):
            msg = "This record is linked to other records, so the action is not allowed."
        elif code == 3819:
            msg = "The data breaks a database rule (see constraints). Please check the values."
        else:
            logging.error("Database error: %s", detail)
            msg = f"A database error occurred: {detail}"
        flash(msg, "danger")
        return back() or error_page(msg, detail)

    @app.errorhandler(BusinessError)
    def business_error(e):
        db.rollback()
        flash(str(e), "danger")
        return back() or error_page(str(e))

    @app.errorhandler(413)
    def too_big(e):
        flash("The file is too big. A book cover can be at most 2 MB.", "danger")
        return back() or error_page("The file is too big. A book cover can be at most 2 MB.")

    @app.errorhandler(500)
    def server_error(e):
        db.rollback()
        logging.exception("Unhandled error")
        return error_page("Something went wrong on the server.", str(getattr(e, "original_exception", e)))

    @app.errorhandler(403)
    def forbidden(e):
        return render_template("errors/403.html"), 403

    @app.errorhandler(404)
    def not_found(e):
        return render_template("errors/404.html"), 404

    return app
