"""Role-based home page."""
from datetime import date, datetime
from flask import Blueprint, render_template, g

from app import db
from app.decorators import login_required, STAFF
from app.models import loan, fine, damage_lost, reservation

bp = Blueprint("dashboard", __name__)


@bp.route("/")
@login_required
def index():
    today = date.today()
    now = datetime.now()
    u = g.user
    if u["role"] in STAFF:
        stats = {
            # Total books and available copies exclude damaged, lost and scrapped copies
            "titles": db.one("SELECT COALESCE(SUM(total_copies - damaged_copies - lost_copies - scrapped_copies), 0) AS n "
                             "FROM books")["n"],
            "available": db.one("SELECT COALESCE(SUM(available_copies), 0) AS n FROM books")["n"],
            "students": db.one("SELECT COUNT(*) AS n FROM members WHERE status = 'Active' "
                               "AND member_type = 'Student'")["n"],
            "staff_members": db.one("SELECT COUNT(*) AS n FROM members WHERE status = 'Active' "
                                    "AND member_type = 'Staff'")["n"],
            "librarians": db.one("SELECT COUNT(*) AS n FROM users WHERE user_role = 'Librarian' "
                                 "AND status = 'Active'")["n"],
            "active_loans": db.one("SELECT COUNT(*) AS n FROM loans WHERE status = 'Issued'")["n"],
            "overdue": db.one("SELECT COUNT(*) AS n FROM loans WHERE status = 'Issued' AND due_date < %s",
                              (today,))["n"],
            "unpaid": fine.total_unpaid() + damage_lost.total_unpaid(),
            "reservations": db.one("SELECT COUNT(*) AS n FROM reservations "
                                   "WHERE status = 'Pending' OR (status = 'Ready' AND expiry_date >= %s)",
                                   (today,))["n"],
        }
        return render_template("dashboard.html", staff=True, now=now, stats=stats,
                               recent=loan.search(today=today, exclude_librarians=(g.user["role"] != "Admin"))[-5:])
    mid = u["member_id"]
    loans = loan.search(status="Issued", member_id=mid)
    stats = {
        "active_loans": len(loans),
        "overdue": sum(1 for l in loans if l["due_date"] and str(l["due_date"])[:10] < today.isoformat()),
        "unpaid": fine.total_unpaid(mid) + damage_lost.total_unpaid(mid),
        "paid": fine.total_paid(mid) + damage_lost.total_paid(mid),
    }
    return render_template("dashboard.html", staff=False, now=now, stats=stats, loans=loans,
                           reservations=reservation.search(status="Active", member_id=mid))


@bp.route("/about")
@login_required
def about():
    """About page - identical for every role."""
    return render_template("about.html", title="About")
