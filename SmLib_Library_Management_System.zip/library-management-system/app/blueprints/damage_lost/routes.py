"""Damaged / Scrapped / Lost books - Librarian and Admin."""
from flask import abort, Blueprint, render_template, request, redirect, url_for, flash, g

from app.decorators import role_required, STAFF
from app.models import damage_lost as dl_model, loan as loan_model, book as book_model
from app.services import damage_service, fine_service

bp = Blueprint("damage_lost", __name__, url_prefix="/damage-lost")


@bp.route("/")
@role_required(*STAFF)
def index():
    status, dtype, q = request.args.get("status", ""), request.args.get("type", ""), request.args.get("q", "").strip()
    return render_template("librarian/damage_lost.html", rows=dl_model.search(status or None, dtype or None, q),
                           status=status, dtype=dtype, q=q)


@bp.route("/new", methods=["GET", "POST"])
@role_required(*STAFF)
def new():
    if request.method == "POST":
        did = damage_service.record(g.user, request.form.get("book_id"), request.form.get("damage_type"),
                                    request.form.get("loan_id") or None, request.form.get("amount"),
                                    (request.form.get("remark") or "").strip() or None)
        flash(f"Record {did} saved.", "success")
        return redirect(url_for("damage_lost.index"))
    pre_loan = request.args.get("loan_id", "")
    pre_book = request.args.get("book_id", "")
    if pre_loan:
        l = loan_model.get(pre_loan)
        pre_book = l["book_id"] if l else pre_book
    # Books whose Available is 0 (as shown on Manage Books, after held copies) are not offered; the exception is the book of a loan
    # the screen was opened from (Lost button on Return a Book), so a borrowed copy can still be recorded.
    books = [b for b in book_model.search() if book_model.issuable(b) > 0 or b["book_id"] == pre_book]
    return render_template("librarian/damage_form.html", books=books,
                           loans=loan_model.search(status="Issued", exclude_librarians=(g.user["role"] != "Admin")), pre_loan=pre_loan, pre_book=pre_book,
                           pre_type=request.args.get("type", ""))


@bp.route("/<damage_id>/payment", methods=["GET", "POST"])
@role_required(*STAFF)
def payment(damage_id):
    """Damaged / Scrapped / Lost Payment screen (opened from the Payment button)."""
    d = dl_model.detail(damage_id)
    if not d:
        abort(404)
    if request.method == "POST":
        status = fine_service.settle_charge(damage_id, request.form)
        flash({"Paid": f"Payment confirmed for record {damage_id}.",
               "Waived": f"Record {damage_id} fully waived."}.get(status, f"Record {damage_id} saved."), "success")
        return redirect(url_for("loans.index") if request.args.get("back") == "loans" else url_for("damage_lost.index"))
    from_loans = request.args.get("back") == "loans"
    return render_template("librarian/damage_payment.html", d=d,
                           back_url=url_for("loans.index") if from_loans else url_for("damage_lost.index"),
                           back_name="Return a Book" if from_loans else "Damaged / Scrapped / Lost")
