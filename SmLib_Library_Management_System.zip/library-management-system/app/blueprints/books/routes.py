"""Manage Books (+ authors, publishers, categories) - Librarian and Admin."""
from flask import Blueprint, render_template, request, redirect, url_for, flash, abort, make_response

from app import db
from app.decorators import role_required, login_required, STAFF
from app.models import book as book_model
from app.models.author import authors
from app.models.publisher import publishers
from app.models.category import categories
from app.services.id_generator import next_id
from app.utils import BusinessError, clean, money, to_int
from flask import g

bp = Blueprint("books", __name__, url_prefix="/books")
LOOKUPS = {"authors": authors, "publishers": publishers, "categories": categories}


@bp.route("/")
@role_required(*STAFF)
def index():
    q, cat = request.args.get("q", "").strip(), request.args.get("category", "")
    return render_template("librarian/books.html", rows=book_model.search(q, cat or None), q=q, cat=cat,
                           categories=categories.all(), issuable=book_model.issuable)


MAX_ADD_COPIES = 1000


def _form_data(book_id=None):
    d = clean(request.form, book_model.FIELDS)
    if not d["title"]:
        raise BusinessError("Title is required.")
    for key, label in (("author_id", "Author"), ("publisher_id", "Publisher"), ("category_id", "Category")):
        if not d[key]:
            raise BusinessError(f"{label} is required.")
    if d["isbn"] and book_model.isbn_taken(d["isbn"], book_id):
        raise BusinessError("Another book already uses this ISBN. An ISBN must be unique.")
    d["publish_year"] = to_int(d["publish_year"], "Publish year", 0) if d["publish_year"] else None
    if d["product_description"] and len(d["product_description"]) > book_model.MAX_DESCRIPTION:
        raise BusinessError(f"Product description cannot be longer than {book_model.MAX_DESCRIPTION} characters.")
    d["price"] = money(d["price"]) if d["price"] else None
    if d["price"] is not None and d["price"] < 0:
        raise BusinessError("Price cannot be negative.")
    return d


def _cover_upload():
    """The uploaded cover image as bytes (checked: type and size), or None when no file was chosen."""
    f = request.files.get("cover_page")
    if not f or not f.filename:
        return None
    data = f.read()
    if len(data) > book_model.MAX_COVER_BYTES:
        raise BusinessError("The cover image is too big. The maximum size is 2 MB.")
    if not data or not book_model.image_type(data):
        raise BusinessError("The cover must be a PNG, JPEG, GIF or WEBP image.")
    return data


def _lists():
    return dict(authors=authors.all(), publishers=publishers.all(), categories=categories.all())


@bp.route("/new", methods=["GET", "POST"])
@role_required(*STAFF)
def new():
    if request.method == "POST":
        d = _form_data()
        cover = _cover_upload()
        total = to_int(request.form.get("total_copies"), "Total copies", 0)
        book_id = next_id("books", "book_id", "B")
        book_model.create(book_id, d, total, g.user["user_id"], cover)
        db.commit()
        flash(f"Book added ({book_id}).", "success")
        return redirect(url_for("books.index"))
    return render_template("librarian/book_form.html", row=None, **_lists())


@bp.route("/<book_id>/edit", methods=["GET", "POST"])
@role_required(*STAFF)
def edit(book_id):
    row = book_model.get(book_id)
    if not row:
        abort(404)
    if request.method == "POST":
        d = _form_data(book_id)
        cover = _cover_upload()
        # "Add copies" is a temporary, optional input (not a column): blank = 0. Whatever is entered is added to
        # Total copies (and Available copies) in the database; the Total copies display itself is not editable.
        raw = (request.form.get("add_copies") or "").strip()
        add = to_int(raw, "Add copies", 0) if raw else 0
        if add > MAX_ADD_COPIES:
            raise BusinessError(f"Add copies cannot be more than {MAX_ADD_COPIES} at a time.")
        book_model.update(book_id, d, add, cover, remove_cover=bool(request.form.get("remove_cover")))
        db.commit()
        if add:
            flash(f"Book updated: {book_id} - {add} copy(ies) added, total copies now {row['total_copies'] + add}.", "success")
        else:
            flash(f"Book updated: {book_id}", "success")
        return redirect(url_for("books.index"))
    return render_template("librarian/book_form.html", row=row, **_lists())


@bp.route("/<book_id>/cover")
@login_required
def cover(book_id):
    """Serve the cover image of a book (any logged-in user)."""
    data = book_model.cover(book_id)
    if not data:
        abort(404)
    resp = make_response(data)
    resp.headers["Content-Type"] = book_model.image_type(data) or "application/octet-stream"
    resp.headers["X-Content-Type-Options"] = "nosniff"
    resp.headers["Cache-Control"] = "private, no-cache"       # revalidated with the ETag, so a changed cover shows at once
    resp.add_etag()
    return resp.make_conditional(request)


@bp.route("/<book_id>/delete", methods=["POST"])
@role_required(*STAFF)
def delete(book_id):
    book_model.delete(book_id)
    db.commit()
    flash("Book deleted.", "success")
    return redirect(url_for("books.index"))


# ---------------------------------------------------------------- lookup tables
def _lookup(kind):
    if kind not in LOOKUPS:
        abort(404)
    return LOOKUPS[kind]


@bp.route("/lookups/<kind>")
@role_required(*STAFF)
def lookups(kind):
    lk = _lookup(kind)
    return render_template("librarian/lookups.html", lk=lk, kind=kind, rows=lk.all(), edit=None)


@bp.route("/lookups/<kind>/new", methods=["POST"])
@role_required(*STAFF)
def lookup_new(kind):
    lk = _lookup(kind)
    d = clean(request.form, lk.fields)
    if not d[lk.fields[0]]:
        raise BusinessError(f"{lk.label} name is required.")
    lk.create(d, g.user["user_id"])
    db.commit()
    flash(f"{lk.label} added.", "success")
    return redirect(url_for("books.lookups", kind=kind))


@bp.route("/lookups/<kind>/<id_>/edit", methods=["GET", "POST"])
@role_required(*STAFF)
def lookup_edit(kind, id_):
    lk = _lookup(kind)
    row = lk.get(id_)
    if not row:
        abort(404)
    if request.method == "POST":
        d = clean(request.form, lk.fields)
        if not d[lk.fields[0]]:
            raise BusinessError(f"{lk.label} name is required.")
        lk.update(id_, d)
        db.commit()
        flash(f"{lk.label} updated: {id_} - {d[lk.fields[0]]}", "success")
        return redirect(url_for("books.lookups", kind=kind))
    return render_template("librarian/lookups.html", lk=lk, kind=kind, rows=lk.all(), edit=row)


@bp.route("/lookups/<kind>/<id_>/delete", methods=["POST"])
@role_required(*STAFF)
def lookup_delete(kind, id_):
    lk = _lookup(kind)
    lk.delete(id_)
    db.commit()
    flash(f"{lk.label} deleted.", "success")
    return redirect(url_for("books.lookups", kind=kind))
