"""Manage Members (Students and Staff) - Librarian and Admin."""
from datetime import date
from flask import Blueprint, render_template, request, redirect, url_for, flash, abort

from app import db
from app.decorators import role_required, STAFF
from app.blueprints.auth.routes import create_login, update_login
from app.models import member as member_model, user as user_model, loan, fine, damage_lost, reservation
from app.services.id_generator import next_id
from app.utils import BusinessError, clean
from flask import g

bp = Blueprint("members", __name__, url_prefix="/members")


def _check(d):
    if not (d["id_no"] and d["member_name"] and d["email"]):
        raise BusinessError("ID number, name and email are required.")
    if d["member_type"] not in ("Student", "Staff"):
        raise BusinessError("Member type must be Student or Staff (Librarians are managed by the Admin).")


def _list(member_type):
    q, status = request.args.get("q", "").strip(), request.args.get("status", "")
    plural = "Students" if member_type == "Student" else "Staff"
    return render_template("librarian/members.html", rows=member_model.search(q, (member_type,), status or None),
                           q=q, status=status, member_type=member_type, plural=plural,
                           endpoint="members.students" if member_type == "Student" else "members.staff")


@bp.route("/")
@role_required(*STAFF)
def index():
    return redirect(url_for("members.students"))


@bp.route("/students")
@role_required(*STAFF)
def students():
    return _list("Student")


@bp.route("/staff")
@role_required(*STAFF)
def staff():
    return _list("Staff")


@bp.route("/new")
@role_required(*STAFF)
def new():
    """Old address: send people to the right separate screen."""
    return redirect(url_for("members.new_staff" if request.args.get("type") == "Staff" else "members.new_student"))


def _add(member_type):
    """Add Member screen for ONE member type; the type is fixed here, never taken from the form."""
    endpoint = "members.new_staff" if member_type == "Staff" else "members.new_student"
    back_to = "members.staff" if member_type == "Staff" else "members.students"
    if request.method == "POST":
        d = clean(request.form, member_model.FIELDS)
        d["member_type"] = member_type
        _check(d)
        member_id = next_id("members", "member_id", "M")
        member_model.create(member_id, d)
        username = (request.form.get("username") or "").strip()
        if username:
            create_login(member_id, username, request.form.get("password"), "Member")
        elif request.form.get("password"):
            raise BusinessError("Enter a username too, or leave the login account details empty.")
        db.commit()
        flash(f"{member_type} {d['member_name']} added ({member_id}).", "success")
        return redirect(url_for(back_to))
    return render_template("librarian/member_form.html", row=None, member_type=member_type,
                           back_url=url_for(back_to))


@bp.route("/students/new", methods=["GET", "POST"])
@role_required(*STAFF)
def new_student():
    return _add("Student")


@bp.route("/staff/new", methods=["GET", "POST"])
@role_required(*STAFF)
def new_staff():
    return _add("Staff")


def _get(member_id):
    row = member_model.get(member_id)
    if not row:
        abort(404)
    if row["member_type"] == "Librarian" and g.user["role"] != "Admin":
        abort(403)
    return row


@bp.route("/<member_id>")
@role_required(*STAFF)
def detail(member_id):
    row = _get(member_id)
    return render_template("librarian/member_detail.html", row=row,
                           loans=loan.search(member_id=member_id, today=date.today()),
                           fines=fine.search(member_id=member_id),
                           charges=damage_lost.search(member_id=member_id),
                           reservations=reservation.search(member_id=member_id))


@bp.route("/<member_id>/edit", methods=["GET", "POST"])
@role_required(*STAFF)
def edit(member_id):
    row = _get(member_id)
    if row["member_type"] == "Librarian":
        return redirect(url_for("admin.librarian_edit", member_id=member_id))
    if row["status"] != "Active":
        raise BusinessError("Inactive members cannot be edited. Activate the member first.")
    if request.method == "POST":
        d = clean(request.form, member_model.FIELDS)
        d["member_type"] = row["member_type"]      # the type cannot be changed here
        _check(d)
        member_model.update(member_id, d)
        update_login(row, request.form, "Member")
        db.commit()
        flash(f"Member updated: {member_id}", "success")
        return redirect(url_for("members.staff" if row["member_type"] == "Staff" else "members.students"))
    return render_template("librarian/member_form.html", row=row, member_type=row["member_type"],
                           back_url=url_for("members.staff" if row["member_type"] == "Staff" else "members.students"))


@bp.route("/<member_id>/toggle", methods=["POST"])
@role_required(*STAFF)
def toggle(member_id):
    row = _get(member_id)
    new = "Inactive" if row["status"] == "Active" else "Active"
    member_model.set_status(member_id, new)
    if row["user_id"]:
        user_model.set_status(row["user_id"], new)
    db.commit()
    flash(f"{row['member_name']} is now {new}.", "success")
    return redirect(request.referrer or url_for("members.index"))
