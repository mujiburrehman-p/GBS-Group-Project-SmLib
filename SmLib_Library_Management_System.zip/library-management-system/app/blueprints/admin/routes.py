"""Administrator: Manage Librarians and Manage System Settings."""
import re
from decimal import Decimal
from flask import Blueprint, render_template, request, redirect, url_for, flash, g, session

from app import db
from app.decorators import role_required
from app.extensions import hash_password
from app.blueprints.auth.routes import create_login, update_login
from app.models import member as member_model, user as user_model, setting
from app.services.id_generator import next_id
from app.utils import BusinessError, clean, valid_password, to_int, money

bp = Blueprint("admin", __name__, url_prefix="/admin")
DETAIL_FIELDS = ["id_no", "member_name", "email", "phone", "address", "expiry_date"]


@bp.route("/librarians")
@role_required("Admin")
def librarians():
    q, status = request.args.get("q", "").strip(), request.args.get("status", "")
    return render_template("admin/librarians.html", rows=user_model.librarians(q or None, status or None),
                           q=q, status=status)


@bp.route("/librarians/new", methods=["GET", "POST"])
@role_required("Admin")
def librarian_new():
    if request.method == "POST":
        d = clean(request.form, DETAIL_FIELDS)
        if not (d["id_no"] and d["member_name"] and d["email"]):
            raise BusinessError("ID number, name and email are required.")
        d["member_type"] = "Librarian"
        member_id = next_id("members", "member_id", "M")
        member_model.create(member_id, d)
        create_login(member_id, (request.form.get("username") or "").strip(), request.form.get("password"), "Librarian")
        db.commit()
        flash(f"Librarian {d['member_name']} created ({member_id}).", "success")
        return redirect(url_for("admin.librarians"))
    return render_template("admin/librarian_form.html", row=None)


@bp.route("/librarians/<member_id>/edit", methods=["GET", "POST"])
@role_required("Admin")
def librarian_edit(member_id):
    row = member_model.get(member_id)
    if not row or row["member_type"] != "Librarian":
        raise BusinessError("Librarian not found.")
    if row["status"] != "Active":
        raise BusinessError("Inactive librarians cannot be edited. Activate the librarian first.")
    if request.method == "POST":
        d = clean(request.form, DETAIL_FIELDS)
        if not (d["id_no"] and d["member_name"] and d["email"]):
            raise BusinessError("ID number, name and email are required.")
        d["member_type"] = "Librarian"
        member_model.update(member_id, d)
        update_login(row, request.form, "Librarian")
        db.commit()
        flash(f"Librarian updated: {member_id}", "success")
        return redirect(url_for("admin.librarians"))
    return render_template("admin/librarian_form.html", row=row)


@bp.route("/librarians/<member_id>/toggle", methods=["POST"])
@role_required("Admin")
def librarian_toggle(member_id):
    row = member_model.get(member_id)
    if not row or row["member_type"] != "Librarian":
        raise BusinessError("Librarian not found.")
    new = "Inactive" if row["status"] == "Active" else "Active"
    member_model.set_status(member_id, new)
    user_model.set_status(row["user_id"], new)
    db.commit()
    flash(f"{row['member_name']} is now {new}.", "success")
    return redirect(url_for("admin.librarians"))


BUILT_IN = {"fine_per_day", "loan_days", "max_books_per_member", "max_renewals", "reservation_hold_days",
            "renewal_after_days"}
KEY_RE = re.compile(r"^[a-z][a-z0-9_]{2,99}$")


def _validate(key, value):
    value = (value or "").strip()
    if key not in BUILT_IN:                       # settings added by the Admin: free text
        if not value:
            raise BusinessError(f"Value for {key} is required.")
        if len(value) > 100:
            raise BusinessError(f"Value for {key} must be at most 100 characters.")
        return value
    if key == "fine_per_day":
        v = money(value)
        if v < 0:
            raise BusinessError("Fine per day cannot be negative.")
        return str(v)
    minimum = 0 if key == "max_renewals" else 1
    return str(to_int(value, key.replace("_", " ").capitalize(), minimum))


@bp.route("/settings/new", methods=["GET", "POST"])
@role_required("Admin")
def setting_new():
    """Add New Setting (Admin only)."""
    if request.method == "POST":
        key = (request.form.get("setting_key") or "").strip().lower()
        value = (request.form.get("setting_value") or "").strip()
        desc = (request.form.get("description") or "").strip() or None
        try:
            if not KEY_RE.match(key):
                raise BusinessError("Setting name must be 3-100 characters: lowercase letters, numbers and "
                                    "underscores, starting with a letter (for example library_name).")
            if key in {r["setting_key"] for r in setting.all_settings()}:
                raise BusinessError("A setting with that name already exists.")
            value = _validate(key, value)
            if desc and len(desc) > 255:
                raise BusinessError("Description must be at most 255 characters.")
            setting_id = next_id("system_settings", "setting_id", "ST", 2)
            setting.create(setting_id, key, value, desc, g.user["user_id"])
            db.commit()
        except BusinessError as e:
            # Stay on this screen with the message and keep what was typed (Post/Redirect/Get)
            db.rollback()
            flash(str(e), "danger")
            session["setting_form"] = {"setting_key": request.form.get("setting_key", ""),
                                       "setting_value": request.form.get("setting_value", ""),
                                       "description": request.form.get("description", "")}
            return redirect(url_for("admin.setting_new"))
        flash(f"Setting {key} added ({setting_id}).", "success")
        return redirect(url_for("admin.setting_new"))   # stay on this screen, form cleared, ready for the next one
    return render_template("admin/setting_form.html", form=session.pop("setting_form", {}))


@bp.route("/settings", methods=["GET", "POST"])
@role_required("Admin")
def settings():
    rows = setting.all_settings()
    if request.method == "POST":
        for r in rows:
            new = _validate(r["setting_key"], request.form.get(r["setting_id"]))
            if new != r["setting_value"]:
                setting.update(r["setting_id"], new, g.user["user_id"])
        db.commit()
        flash("Settings saved.", "success")
        return redirect(url_for("admin.settings"))
    return render_template("admin/settings.html", rows=rows)
