"""Manage Fines (Librarian/Admin) and Member: View Fine Details."""
from flask import abort, Blueprint, render_template, request, redirect, url_for, flash, g

from app.decorators import role_required, member_required, STAFF
from app.models import fine as fine_model, damage_lost as dl_model
from app.services import fine_service

bp = Blueprint("fines", __name__)


@bp.route("/fines")
@role_required(*STAFF)
def index():
    status, q = request.args.get("status", ""), request.args.get("q", "").strip()
    return render_template("librarian/fines.html", rows=fine_model.search(status or None, q),
                           status=status, q=q)


@bp.route("/fines/<fine_id>/payment", methods=["GET", "POST"])
@role_required(*STAFF)
def payment(fine_id):
    """Fine Payment screen: opened after an overdue book is returned."""
    f = fine_model.detail(fine_id)
    if not f:
        abort(404)
    if request.method == "POST":
        status = fine_service.settle(fine_id, request.form)
        flash({"Paid": f"Payment confirmed for fine {fine_id}.",
               "Waived": f"Fine {fine_id} fully waived."}.get(status, f"Fine {fine_id} saved as Unpaid."), "success")
        return redirect(url_for("fines.index") if request.args.get("back") == "fines" else url_for("loans.index"))
    return render_template("librarian/fine_payment.html", f=f, per_day=fine_service.fine_for_days(1),
                           back_url=url_for("fines.index") if request.args.get("back") == "fines" else url_for("loans.index"),
                           back_name="Manage Fines" if request.args.get("back") == "fines" else "Return a Book")


@bp.route("/payments/fine-lost/<fine_id>/<damage_id>", methods=["GET", "POST"])
@role_required(*STAFF)
def fine_lost_payment(fine_id, damage_id):
    """Fine & Lost Payment screen: overdue fine + lost charge of the same loan, paid together."""
    f, d = fine_model.detail(fine_id), dl_model.detail(damage_id)
    if not f or not d or f["loan_id"] != d["loan_id"]:
        abort(404)
    if f["paid_status"] == "Unpaid" and d["paid_status"] != "Unpaid":
        return redirect(url_for("fines.payment", fine_id=fine_id))
    if d["paid_status"] == "Unpaid" and f["paid_status"] != "Unpaid":
        return redirect(url_for("damage_lost.payment", damage_id=damage_id, back="loans"))
    if request.method == "POST":
        a, b = fine_service.settle_fine_and_lost(fine_id, damage_id, request.form)
        flash(f"Fine {fine_id} ({a}) and lost charge {damage_id} ({b}) saved for loan {f['loan_id']}.", "success")
        return redirect(url_for("loans.index"))
    return render_template("librarian/fine_lost_payment.html", f=f, d=d, per_day=fine_service.fine_for_days(1))


@bp.route("/fines/sync", methods=["POST"])
@role_required(*STAFF)
def sync():
    n = fine_service.sync_overdue(g.user["user_id"])
    flash(f"Overdue fines calculated for {n} overdue loan(s).", "success")
    return redirect(url_for("fines.index"))


@bp.route("/fines/<kind>/<record_id>/pay", methods=["POST"])
@role_required(*STAFF)
def pay(kind, record_id):
    fine_service.pay("fines" if kind == "fine" else "damage_lost", record_id, request.form.get("payment_method"))
    flash("Payment recorded.", "success")
    return redirect(request.referrer or url_for("fines.index"))


@bp.route("/fines/<kind>/<record_id>/waive", methods=["POST"])
@role_required(*STAFF)
def waive(kind, record_id):
    fine_service.waive("fines" if kind == "fine" else "damage_lost", record_id,
                       request.form.get("amount"), full=request.form.get("full") == "1")
    flash("Waiver recorded.", "success")
    return redirect(request.referrer or url_for("fines.index"))


@bp.route("/my/fines")
@member_required
def my_fines():
    mid = g.user["member_id"]
    return render_template("member/my_fines.html", fines=fine_model.search(member_id=mid),
                           total=fine_model.total_unpaid(mid))


@bp.route("/my/charges")
@member_required
def my_charges():
    """Damage / loss charges (damage_lost table) of the signed-in member."""
    mid = g.user["member_id"]
    return render_template("member/my_charges.html", charges=dl_model.search(member_id=mid),
                           total=dl_model.total_unpaid(mid))

