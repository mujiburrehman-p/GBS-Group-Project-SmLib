"""Member: Search Catalogue and View Book Details."""
from flask import Blueprint, render_template, request, abort, g

from app.decorators import login_required
from app.models import book as book_model, loan, reservation
from app.models.category import categories

bp = Blueprint("catalog", __name__)


@bp.route("/catalog")
@login_required
def index():
    q, cat = request.args.get("q", "").strip(), request.args.get("category", "")
    return render_template("member/catalog.html", rows=book_model.search(q, cat or None), q=q, cat=cat,
                           categories=categories.all(), issuable=book_model.issuable)


@bp.route("/catalog/<book_id>")
@login_required
def detail(book_id):
    book = book_model.get(book_id)
    if not book:
        abort(404)
    mine = None
    my_loan = None
    mid = g.user["member_id"]
    if mid:
        mine = reservation.active_for(mid, book_id)
        my_loan = loan.has_active(mid, book_id)
    return render_template("member/book.html", b=book, free=book_model.issuable(book),
                           my_reservation=mine, on_loan=my_loan)
