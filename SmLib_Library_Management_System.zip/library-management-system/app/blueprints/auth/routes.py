"""Login -> Authenticate user -> Authorise role -> Logout, self-registration and profile."""
import re
import pymysql
from flask import Blueprint, render_template, request, redirect, url_for, flash, session, g

from app import db
from app.decorators import login_required
from app.extensions import hash_password, check_password
from app.models import user as user_model, member as member_model
from app.services.id_generator import next_id
from app.utils import BusinessError, clean, valid_password

bp = Blueprint("auth", __name__)
USERNAME_RE = re.compile(r"^[A-Za-z0-9]{5,50}$")


def _safe_next(target):
    return target if target and target.startswith("/") and not target.startswith("//") else None


@bp.route("/login", methods=["GET", "POST"])
def login():
    if g.user:
        return redirect(url_for("dashboard.index"))
    if request.method == "POST":
        username = (request.form.get("username") or "").strip()
        password = request.form.get("password") or ""
        u = user_model.by_username(username)
        if not u or not check_password(password, u["password_hash"]):
            flash("Invalid username or password.", "danger")
        elif u["status"] != "Active" or (u["member_id"] and u["member_status"] != "Active"):
            flash("Your account is inactive. Please contact the library administrator.", "danger")
        else:
            next_url = _safe_next(request.args.get("next"))
            session.clear()
            session["user"] = {"user_id": u["user_id"], "username": u["username"], "role": u["user_role"],
                               "member_id": u["member_id"], "name": u["member_name"] or u["username"]}
            return redirect(next_url or url_for("dashboard.index"))
    return render_template("auth/login.html")


@bp.route("/forgot-password")
def forgot_password():
    """Placeholder: password recovery is planned as a future enhancement."""
    flash("Future Enhancements", "info")
    return redirect(url_for("auth.login"))


@bp.route("/logout", methods=["POST"])
def logout():
    session.clear()
    flash("You have been logged out.", "info")
    return redirect(url_for("auth.login"))


def valid_username(username):
    if not USERNAME_RE.match(username or ""):
        raise BusinessError("Username must be 5-50 characters: letters and numbers only.")


def create_login(member_id, username, password, role):
    """Create the users row for a member (used by registration and by staff)."""
    valid_username(username)
    valid_password(password)
    if user_model.by_username(username):
        raise BusinessError("That username is already taken.")
    user_model.create(next_id("users", "user_id", "U"), username, hash_password(password), role, member_id)


def update_login(row, form, role):
    """Edit screens: optionally change the username and/or set a new password (both optional).

    * login exists: blank username = keep it; blank password = keep it
    * no login yet: filling in username + password creates one
    """
    username = (form.get("username") or "").strip()
    password = form.get("password") or ""
    if row["user_id"]:
        if username and username != row["username"]:
            valid_username(username)
            other = user_model.by_username(username)
            if other and other["user_id"] != row["user_id"]:
                raise BusinessError("That username is already taken.")
            user_model.set_username(row["user_id"], username)
        if password:
            valid_password(password)
            user_model.set_password(row["user_id"], hash_password(password))
    elif username or password:
        if not username:
            raise BusinessError("Enter a username too, or leave the login account details empty.")
        create_login(row["member_id"], username, password, role)


@bp.route("/register", methods=["GET", "POST"])
def register():
    if g.user:
        return redirect(url_for("dashboard.index"))
    if request.method == "POST":
        try:
            d = clean(request.form, ["id_no", "member_name", "email", "phone", "address", "member_type", "username"])
            for field, label in (("id_no", "ID number"), ("member_name", "Full name"), ("email", "Email")):
                if not d[field]:
                    raise BusinessError(f"{label} is required.")
            if d["member_type"] not in ("Student", "Staff"):
                raise BusinessError("Choose Student or Staff.")
            valid_password(request.form.get("password"), request.form.get("confirm"))
            d["expiry_date"] = None
            member_id = next_id("members", "member_id", "M")
            member_model.create(member_id, d)
            create_login(member_id, d["username"], request.form.get("password"), "Member")
            db.commit()
        except (BusinessError, pymysql.IntegrityError) as e:
            # Stay on the Register screen, show the message and keep what the user typed
            db.rollback()
            msg = str(e) if isinstance(e, BusinessError) else \
                "That username, ID number or email is already registered."
            flash(msg, "danger")
            # Post/Redirect/Get: keep the typed values (never the passwords) and show the form again
            session["reg_form"] = {k: request.form.get(k, "") for k in
                                   ("member_name", "member_type", "id_no", "email", "phone", "address", "username")}
            return redirect(url_for("auth.register"))
        flash("Registration successful. You can now log in.", "success")
        return redirect(url_for("auth.login"))
    return render_template("auth/register.html", form=session.pop("reg_form", {}))


@bp.route("/profile", methods=["GET", "POST"])
@login_required
def profile():
    u = g.user
    member = member_model.get(u["member_id"]) if u["member_id"] else None
    if request.method == "POST":
        if request.form.get("action") == "details":
            if not member:
                raise BusinessError("The Admin account has no member profile to edit.")
            d = clean(request.form, ["member_name", "email", "phone", "address"])
            if not d["member_name"] or not d["email"]:
                raise BusinessError("Name and email are required.")
            member_model.update_contact(member["member_id"], d["member_name"], d["email"], d["phone"], d["address"])
            db.commit()
            session["user"] = {**u, "name": d["member_name"]}
            flash("Profile updated.", "success")
        else:
            row = user_model.by_id(u["user_id"])
            if not check_password(request.form.get("current") or "", row["password_hash"]):
                raise BusinessError("Your current password is incorrect.")
            valid_password(request.form.get("new"), request.form.get("confirm"))
            user_model.set_password(u["user_id"], hash_password(request.form["new"]))
            db.commit()
            flash("Password changed.", "success")
        return redirect(url_for("auth.profile"))
    return render_template("member/profile.html", member=member)
