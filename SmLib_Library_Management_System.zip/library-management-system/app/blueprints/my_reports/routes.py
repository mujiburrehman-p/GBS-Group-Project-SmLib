"""My Reports - a Member's own loans, reservations and fines (read-only, PDF/print)."""
import csv
import io
from datetime import date, datetime
from decimal import Decimal

from datetime import timedelta

from flask import Blueprint, render_template, Response, abort, g, request, flash

from app.decorators import member_required
from app.models import loan, reservation, fine, damage_lost
from app.blueprints.reports.routes import build_pdf, MONEY_COLS
from app.services import fine_service
from app.utils import to_date

bp = Blueprint("my_reports", __name__, url_prefix="/my/reports")

TABS = [("current", "My Current Loans"), ("previous", "My Previous Loans"), ("history", "My Borrowing History"),
        ("overdue", "My Overdue Loan"), ("reservations", "My Active Reservation"),
        ("reshistory", "My Reservation History"), ("payments", "My Payment History"),
        ("unpaid", "Unpaid Fines & Charges"), ("paid", "Paid Fines & Charges")]


def _money(v):
    return f"£{Decimal(str(v)):,.2f}"


def _charges(mid, status):
    """Overdue fines and damage / loss charges for one member as one list."""
    rows = []
    for f in fine.search(status=None if status == "Settled" else status, member_id=mid):
        if status == "Settled" and f["status"] == "Unpaid":
            continue
        rows.append(dict(kind="Overdue fine", ref=f["fine_id"], title=f["title"], on=f["paid_date"] if status == "Paid" else f["fine_date"],
                         amount=f["fine_amount"], waived_amount=f["waived_amount"], net_amount=f["net_amount"], status=f["status"],
                         payment_method=f["payment_method"], paid_date=f["paid_date"], date_on=f["fine_date"]))
    for d in damage_lost.search(status=None if status == "Settled" else status, member_id=mid):
        if status == "Settled" and d["status"] == "Unpaid":
            continue
        rows.append(dict(kind=f"{d['damage_type']} book", ref=d["damage_id"], title=d["title"], on=d["record_date"],
                         amount=d["amount"], waived_amount=d["waived_amount"], net_amount=d["net_amount"], status=d["status"],
                         payment_method=d["payment_method"], paid_date=d["paid_date"], date_on=d["record_date"]))
    return rows


# Which date each report is filtered on (From date / To date)
DATE_OF = {
    "current": lambda r: r["issue_date"], "previous": lambda r: r["return_date"] or r["issue_date"],
    "history": lambda r: r["issue_date"], "overdue": lambda r: r["due_date"],
    "reservations": lambda r: r["reservation_date"], "reshistory": lambda r: r["reservation_date"],
    "payments": lambda r: r["paid_date"] or r["date_on"], "unpaid": lambda r: r["date_on"],
    "paid": lambda r: r["paid_date"] or r["date_on"],
}
DATE_LABEL = {
    "current": "Issued date", "previous": "Returned / lost date", "history": "Issued date", "overdue": "Due date",
    "reservations": "Reserved date", "reshistory": "Reserved date", "payments": "Payment date (or record date)",
    "unpaid": "Fine / record date", "paid": "Payment date",
}


def parse_range():
    """From date / To date from the query string (YYYY-MM-DD); a bad range is reported and ignored."""
    out = []
    for name, label in (("from", "From date"), ("to", "To date")):
        raw = (request.args.get(name) or "").strip()
        try:
            out.append(datetime.strptime(raw, "%Y-%m-%d").date() if raw else None)
        except ValueError:
            flash(f"{label} is not a valid date.", "danger")
            out.append(None)
    if out[0] and out[1] and out[0] > out[1]:
        flash("From date cannot be after To date, so the date filter was not applied.", "danger")
        out = [None, None]
    return out[0], out[1]


def build(key, mid, dfrom=None, dto=None):
    today = date.today()

    def F(rows):
        if not (dfrom or dto):
            return rows
        keep = []
        for r in rows:
            d = to_date(DATE_OF[key](r))
            if d and (not dfrom or d >= dfrom) and (not dto or d <= dto):
                keep.append(r)
        return keep
    if key == "current":
        rows = F(loan.search(status="Issued", member_id=mid))
        for r in rows:
            late = max(0, (today - to_date(r["due_date"])).days) if r["due_date"] else 0
            r["days_late"] = late
            r["state"] = "Overdue" if late else "On time"
        cols = [("loan_id", "Loan"), ("title", "Book"), ("shelf_location", "Shelf"), ("issue_date", "Issued"),
                ("due_date", "Due"), ("renewal_count", "Renewals"), ("days_late", "Days late"), ("state", "Status")]
        summary = [("Books on loan", str(len(rows))), ("Overdue", str(sum(1 for r in rows if r["days_late"])))]
    elif key == "previous":
        rows = F([r for r in loan.search(member_id=mid) if r["status"] != "Issued"])
        cols = [("loan_id", "Loan"), ("title", "Book"), ("issue_date", "Issued"), ("due_date", "Due"),
                ("return_date", "Returned"), ("renewal_count", "Renewals"), ("status", "Status")]
        summary = [("Previous loans", str(len(rows)))]
    elif key == "history":
        rows = F(loan.search(member_id=mid))
        for r in rows:
            late = max(0, (today - to_date(r["due_date"])).days) if r["status"] == "Issued" and r["due_date"] else 0
            r["state"] = "Overdue" if late else r["status"]
        cols = [("loan_id", "Loan"), ("title", "Book"), ("issue_date", "Issued"), ("due_date", "Due"),
                ("return_date", "Returned / lost on"), ("renewal_count", "Renewals"), ("state", "Status")]
        summary = [("Total loans", str(len(rows))),
                   ("Returned", str(sum(1 for r in rows if r["status"] == "Returned"))),
                   ("On loan now", str(sum(1 for r in rows if r["status"] == "Issued"))),
                   ("Lost", str(sum(1 for r in rows if r["status"] == "Lost")))]
    elif key == "overdue":
        rows = []
        for r in loan.search(status="Issued", member_id=mid):
            late = (today - to_date(r["due_date"])).days if r["due_date"] else 0
            if late > 0:
                r["days_late"] = late
                r["est_fine"] = fine_service.fine_for_days(late)
                rows.append(r)
        rows = F(rows)
        cols = [("loan_id", "Loan"), ("title", "Book"), ("shelf_location", "Shelf"), ("issue_date", "Issued"),
                ("due_date", "Due"), ("days_late", "Days overdue"), ("est_fine", "Estimated fine")]
        total = sum((Decimal(str(r["est_fine"])) for r in rows), Decimal("0"))
        summary = [("Overdue loans", str(len(rows))), ("Estimated fines", _money(total))]
    elif key == "reshistory":
        active = {r["reservation_id"] for r in reservation.search(status="Active", member_id=mid)}
        rows = F([r for r in reservation.search(member_id=mid) if r["reservation_id"] not in active])
        cols = [("reservation_id", "Reservation"), ("title", "Book"), ("shelf_location", "Shelf"),
                ("reservation_date", "Reserved on"), ("status", "Status"), ("expiry_date", "Hold until"), ("loan_id", "Loan")]
        summary = [("Past reservations", str(len(rows))),
                   ("Fulfilled", str(sum(1 for r in rows if r["status"] == "Fulfilled"))),
                   ("Cancelled / expired", str(sum(1 for r in rows if r["status"] != "Fulfilled")))]
    elif key == "payments":
        rows = F(_charges(mid, "Settled"))
        cols = [("kind", "Type"), ("ref", "Reference"), ("title", "Book"), ("date_on", "Date"), ("amount", "Amount"),
                ("waived_amount", "Waived"), ("net_amount", "Paid"), ("payment_method", "Payment method"),
                ("paid_date", "Payment date"), ("status", "Status")]
        total = sum((Decimal(str(r["net_amount"])) for r in rows), Decimal("0"))
        summary = [("Payments", str(len(rows))), ("Total paid", _money(total))]
    elif key == "reservations":
        rows = F(reservation.search(status="Active", member_id=mid))
        cols = [("reservation_id", "Reservation"), ("title", "Book"), ("shelf_location", "Shelf"),
                ("reservation_date", "Reserved on"), ("status", "Status"), ("expiry_date", "Hold until")]
        summary = [("Active reservations", str(len(rows))),
                   ("Ready to collect", str(sum(1 for r in rows if r["status"] == "Ready")))]
    elif key in ("unpaid", "paid"):
        rows = F(_charges(mid, "Unpaid" if key == "unpaid" else "Paid"))
        cols = [("kind", "Type"), ("ref", "Reference"), ("title", "Book"),
                ("on_date", "Date" if key == "unpaid" else "Paid / recorded on"),
                ("amount", "Amount"), ("waived_amount", "Waived"), ("net_amount", "To pay" if key == "unpaid" else "Paid"),
                ("status", "Status")]
        for r in rows:
            r["on_date"] = r["on"]
        total = sum((Decimal(str(r["net_amount"])) for r in rows), Decimal("0"))
        summary = [("Items", str(len(rows))),
                   ("Total unpaid" if key == "unpaid" else "Total paid", _money(total))]
    else:
        abort(404)
    if dfrom or dto:
        summary = summary + [("Period (" + DATE_LABEL[key] + ")",
                              (f"{dfrom:%d %b %Y}" if dfrom else "Beginning") + " to " + (f"{dto:%d %b %Y}" if dto else "Today"))]
    return dict(TABS)[key], cols, rows, summary


def with_total(cols, rows):
    """Add the bottom total row: 'Net Total' with every money column summed, or a record count when the report has no amounts."""
    if not rows:
        return rows
    money = [k for k, _ in cols if k in MONEY_COLS]
    tot = {k: "" for k, _ in cols}
    tot["_total"] = True
    if money:
        tot[cols[0][0]] = "Net Total"
        for k in money:
            tot[k] = sum((Decimal(str(r[k])) for r in rows if r.get(k) is not None), Decimal("0")).quantize(Decimal("0.01"))
    else:
        tot[cols[0][0]] = "Total"
        tot[cols[1][0]] = f"{len(rows)} record(s)"
    return rows + [tot]


@bp.route("/")
@member_required
def index():
    return view("current")


@bp.route("/<key>")
@member_required
def view(key):
    dfrom, dto = parse_range()
    title, cols, rows, summary = build(key, g.user["member_id"], dfrom, dto)
    qs = {k: v for k, v in (("from", dfrom.isoformat() if dfrom else ""), ("to", dto.isoformat() if dto else "")) if v}
    today = date.today()
    presets = [("Last 30 days", (today - timedelta(days=30)).isoformat(), today.isoformat()),
               ("This month", today.replace(day=1).isoformat(), today.isoformat()),
               ("This year", today.replace(month=1, day=1).isoformat(), today.isoformat())]
    count = len(rows)
    rows = with_total(cols, rows)
    return render_template("member/my_reports.html", tabs=TABS, key=key, title=title, cols=cols, rows=rows, count=count,
                           summary=summary, money_cols=MONEY_COLS, qs=qs, dfrom=dfrom, dto=dto,
                           date_label=DATE_LABEL[key], presets=presets)


@bp.route("/<key>/pdf")
@member_required
def pdf(key):
    title, cols, rows, summary = build(key, g.user["member_id"], *parse_range())
    rows = with_total(cols, rows)
    return Response(build_pdf(title, cols, rows, summary, g.user), mimetype="application/pdf",
                    headers={"Content-Disposition": f"attachment; filename=smlib_my_{key}_{date.today()}.pdf"})


@bp.route("/<key>/csv")
@member_required
def csv_export(key):
    title, cols, rows, summary = build(key, g.user["member_id"], *parse_range())
    rows = with_total(cols, rows)
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow([label for _, label in cols])
    for r in rows:
        w.writerow(["" if r.get(k) is None else r.get(k) for k, _ in cols])
    return Response(buf.getvalue(), mimetype="text/csv",
                    headers={"Content-Disposition": f"attachment; filename=smlib_my_{key}_{date.today()}.csv"})
