"""Administrator Reports (Admin only): 15 parameterised reports with PDF / CSV export and a bottom total row.

Every report takes its parameters from the query string (?status=Active&from=2026-10-01&to=2026-10-31), so the same
choices are used by the screen, the PDF and the CSV download."""
import csv
import io
from datetime import date, datetime, timedelta
from decimal import Decimal

from flask import Blueprint, render_template, Response, abort, g, request, flash

from app import db
from app.blueprints.reports.routes import build_pdf, MONEY_COLS
from app.decorators import role_required
from app.services.fine_service import fine_for_days
from app.utils import to_date

bp = Blueprint("admin_reports", __name__, url_prefix="/admin/reports")

ALL = "All"
# ---------------------------------------------------------------- parameter definitions
PARAMS = {
    "member_type": ("Member type", [ALL, "Student", "Staff"]),
    "status": ("Status", [ALL, "Active", "Inactive"]),
    "stock": ("Show", [ALL, "Available", "Damaged", "Lost", "Scrapped"]),
    "loan_status": ("Loan status", [ALL, "Issued", "Returned", "Overdue", "Lost"]),
    "top": ("Top", ["10", "20", "50", ALL]),
    "activity": ("Activity", [ALL, "Book issued", "Book returned", "Fine", "Damaged / Scrapped / Lost", "Reservation", "Member joined"]),
    "pay_status": ("Payment status", [ALL, "Unpaid", "Paid", "Waived"]),
    "pay_status_dl": ("Payment status", [ALL, "Unpaid", "Paid", "Waived", "No charge"]),
    "waiver": ("Waiver type", [ALL, "Not Waived", "Partially Waived", "Fully Waived"]),
    "method": ("Payment method", [ALL, "Cash", "Card", "No charge"]),
    "from": ("From date", "date"),
    "to": ("To date", "date"),
    "jfrom": ("Join date from", "date"),
    "jto": ("Join date to", "date"),
    "rtype": ("Type", [ALL, "Fine", "Damaged", "Lost"]),
    "rpay": ("Payment status", [ALL, "Paid", "Unpaid"]),
    "today_status": ("Status", [ALL, "Issued", "Returned", "Lost"]),
    "rsv_status": ("Status", [ALL, "Pending", "Ready", "Fulfilled", "Cancelled", "Expired"]),
    "rfrom": ("Reserve date from", "date"),
    "rto": ("Reserve date to", "date"),
    "efrom": ("Expiry date from", "date"),
    "eto": ("Expiry date to", "date"),
    "mfrom": ("Month from", "month"),
    "mto": ("Month to", "month"),
}
DEFAULTS = {"top": "10"}


def _parse_params(names):
    """Read, validate and return {name: value}; bad dates / ranges are reported and ignored."""
    out = {}
    for n in names:
        label, opts = PARAMS[n]
        raw = (request.args.get(n) or "").strip()
        if opts in ("date", "month"):
            try:
                if not raw:
                    out[n] = None
                elif opts == "month":
                    out[n] = datetime.strptime(raw[:7], "%Y-%m").date()       # first day of the month
                else:
                    out[n] = datetime.strptime(raw, "%Y-%m-%d").date()
            except ValueError:
                flash(f"{label} is not a valid {'month' if opts == 'month' else 'date'}.", "danger")
                out[n] = None
        else:
            out[n] = raw if raw in opts else DEFAULTS.get(n, ALL)
    for lo, hi, what in (("from", "to", "From date cannot be after To date"), ("jfrom", "jto", "Join date from cannot be after Join date to"),
                         ("rfrom", "rto", "Reserve date from cannot be after Reserve date to"), ("efrom", "eto", "Expiry date from cannot be after Expiry date to"),
                         ("mfrom", "mto", "Month from cannot be after Month to")):
        if out.get(lo) and out.get(hi) and out[lo] > out[hi]:
            flash(what + ", so the dates were not applied.", "danger")
            out[lo] = out[hi] = None
    return out


def _range(col, p, where, args, lo="from", hi="to"):
    if p.get(lo):
        where.append(f"{col} >= %s")
        args.append(p[lo])
    if p.get(hi):
        where.append(f"{col} < %s")                          # exclusive next day: works for DATE and DATETIME
        args.append(p[hi] + timedelta(days=1))


def _eq(col, p, name, where, args):
    if p.get(name) and p[name] != ALL:
        where.append(f"{col} = %s")
        args.append(p[name])


def _w(where):
    return (" WHERE " + " AND ".join(where)) if where else ""


# ---------------------------------------------------------------- the reports
def r_dashboard(p):
    n = lambda sql, *a: (db.one(sql, a) or {"n": 0})["n"] or 0
    today = date.today()
    money = lambda v: f"£{Decimal(str(v or 0)):,.2f}"
    rows = []

    def add(group, metric, value): rows.append(dict(grp=group, metric=metric, value=str(value)))
    add("Books", "Book titles", n("SELECT COUNT(*) AS n FROM books"))
    add("Books", "Total copies (usable, excl. damaged / lost / scrapped)", n("SELECT SUM(total_copies - damaged_copies - lost_copies - scrapped_copies) AS n FROM books"))
    add("Books", "Available copies", n("SELECT SUM(available_copies) AS n FROM books"))
    add("Books", "Copies on loan", n("SELECT COUNT(*) AS n FROM loans WHERE status = 'Issued'"))
    add("Books", "Damaged copies", n("SELECT SUM(damaged_copies) AS n FROM books"))
    add("Books", "Lost copies", n("SELECT SUM(lost_copies) AS n FROM books"))
    add("Books", "Scrapped copies", n("SELECT SUM(scrapped_copies) AS n FROM books"))
    add("Books", "Categories / Authors / Publishers",
        f"{n('SELECT COUNT(*) AS n FROM categories')} / {n('SELECT COUNT(*) AS n FROM authors')} / {n('SELECT COUNT(*) AS n FROM publishers')}")
    add("Members", "Active students", n("SELECT COUNT(*) AS n FROM members WHERE member_type = 'Student' AND status = 'Active'"))
    add("Members", "Active staff", n("SELECT COUNT(*) AS n FROM members WHERE member_type = 'Staff' AND status = 'Active'"))
    add("Members", "Active librarians", n("SELECT COUNT(*) AS n FROM members WHERE member_type = 'Librarian' AND status = 'Active'"))
    add("Members", "Inactive members (all types)", n("SELECT COUNT(*) AS n FROM members WHERE status = 'Inactive'"))
    add("Circulation", "Loans issued (all time)", n("SELECT COUNT(*) AS n FROM loans"))
    add("Circulation", "Overdue loans now", n("SELECT COUNT(*) AS n FROM loans WHERE status = 'Issued' AND due_date < %s", today))
    add("Circulation", "Active reservations (Pending / Ready)", n("SELECT COUNT(*) AS n FROM reservations WHERE status IN ('Pending', 'Ready')"))
    add("Fines & charges", "Unpaid overdue fines (net)", money(n("SELECT SUM(net_amount) AS n FROM fines WHERE paid_status = 'Unpaid'")))
    add("Fines & charges", "Unpaid damaged / lost charges (net)", money(n("SELECT SUM(net_amount) AS n FROM damage_lost WHERE paid_status = 'Unpaid'")))
    add("Fines & charges", "Total paid (fines + charges, net)", money(n("SELECT SUM(net_amount) AS n FROM fines WHERE paid_status = 'Paid'") + n("SELECT SUM(net_amount) AS n FROM damage_lost WHERE paid_status = 'Paid'")))
    add("Fines & charges", "Total waived", money(n("SELECT SUM(waived_amount) AS n FROM fines") + n("SELECT SUM(waived_amount) AS n FROM damage_lost")))
    add("System", "User accounts (Active)", n("SELECT COUNT(*) AS n FROM users WHERE status = 'Active'"))
    return dict(cols=[("grp", "Group"), ("metric", "Statistic"), ("value", "Value")], rows=rows, sum=[])


def r_activity(p):
    who = "COALESCE(u.full_name, u.username)"
    kinds = []
    w, a = [], []
    _range("l.issue_date", p, w, a)
    kinds.append(("Book issued", f"SELECT l.issue_date AS on_date, l.loan_id AS ref, l.member_id, m.member_name, b.title AS detail, {who} AS by_user "
                  "FROM loans l JOIN members m ON m.member_id = l.member_id JOIN books b ON b.book_id = l.book_id JOIN users u ON u.user_id = l.issued_by" + _w(w), a))
    w, a = ["l.status = 'Returned'"], []
    _range("l.return_date", p, w, a)
    kinds.append(("Book returned", f"SELECT l.return_date AS on_date, l.loan_id AS ref, l.member_id, m.member_name, b.title AS detail, {who} AS by_user "
                  "FROM loans l JOIN members m ON m.member_id = l.member_id JOIN books b ON b.book_id = l.book_id JOIN users u ON u.user_id = l.returned_to" + _w(w), a))
    w, a = [], []
    _range("f.fine_date", p, w, a)
    kinds.append(("Fine", f"SELECT f.fine_date AS on_date, f.fine_id AS ref, l.member_id, m.member_name, b.title AS detail, {who} AS by_user "
                  "FROM fines f JOIN loans l ON l.loan_id = f.loan_id JOIN members m ON m.member_id = l.member_id JOIN books b ON b.book_id = l.book_id "
                  "JOIN users u ON u.user_id = f.created_by" + _w(w), a))
    w, a = [], []
    _range("d.record_date", p, w, a)
    kinds.append(("Damaged / Scrapped / Lost", f"SELECT d.record_date AS on_date, d.damage_id AS ref, d.member_id, m.member_name, b.title AS detail, {who} AS by_user "
                  "FROM damage_lost d LEFT JOIN members m ON m.member_id = d.member_id JOIN books b ON b.book_id = d.book_id JOIN users u ON u.user_id = d.created_by" + _w(w), a))
    w, a = [], []
    _range("r.reservation_date", p, w, a)
    kinds.append(("Reservation", "SELECT r.reservation_date AS on_date, r.reservation_id AS ref, r.member_id, m.member_name, b.title AS detail, m.member_name AS by_user "
                  "FROM reservations r JOIN members m ON m.member_id = r.member_id JOIN books b ON b.book_id = r.book_id" + _w(w), a))
    w, a = [], []
    _range("m.joined_date", p, w, a)
    kinds.append(("Member joined", "SELECT m.joined_date AS on_date, m.member_id AS ref, m.member_id, m.member_name, m.member_type AS detail, 'System' AS by_user FROM members m" + _w(w), a))
    rows = []
    for kind, sql, args in kinds:
        if p["activity"] != ALL and p["activity"] != kind:
            continue
        for r in db.query(sql, args):
            r["activity"] = kind
            rows.append(r)
    rows.sort(key=lambda r: (str(r["on_date"]), r["ref"]), reverse=True)
    rows = rows[:2000]
    return dict(cols=[("on_date", "Date"), ("activity", "Activity"), ("ref", "Reference"), ("member_id", "Member ID"),
                      ("member_name", "Member"), ("detail", "Book / Detail"), ("by_user", "Done by")], rows=rows, sum=[])


def r_members(p):
    w, a = ["m.member_type IN ('Student', 'Staff')"], []
    _eq("m.member_type", p, "member_type", w, a)
    _eq("m.status", p, "status", w, a)
    _range("m.joined_date", p, w, a, "jfrom", "jto")
    rows = db.query("SELECT m.*, (SELECT COUNT(*) FROM loans l WHERE l.member_id = m.member_id AND l.status = 'Issued') AS on_loan "
                    "FROM members m" + _w(w) + " ORDER BY m.member_type, LENGTH(m.member_id), m.member_id", a)
    return dict(cols=[("member_id", "Member ID"), ("id_no", "ID number"), ("member_name", "Name"), ("member_type", "Type"), ("email", "Email"),
                      ("phone", "Phone"), ("status", "Status"), ("joined_date", "Joined"), ("expiry_date", "Ends"), ("on_loan", "On loan")],
                rows=rows, sum=["on_loan"])


def r_librarians(p):
    w, a = ["m.member_type = 'Librarian'"], []
    _eq("m.status", p, "status", w, a)
    _range("m.joined_date", p, w, a, "jfrom", "jto")
    rows = db.query("SELECT m.*, u.username, u.user_id FROM members m LEFT JOIN users u ON u.member_id = m.member_id" + _w(w)
                    + " ORDER BY LENGTH(m.member_id), m.member_id", a)
    return dict(cols=[("member_id", "Member ID"), ("id_no", "ID number"), ("member_name", "Name"), ("username", "Username"), ("user_id", "User ID"),
                      ("email", "Email"), ("phone", "Phone"), ("status", "Status"), ("joined_date", "Joined")], rows=rows, sum=[])


def r_categories(p):
    rows = db.query("SELECT c.*, (SELECT COUNT(*) FROM books b WHERE b.category_id = c.category_id) AS books FROM categories c ORDER BY c.category_name")
    return dict(cols=[("category_id", "Category ID"), ("category_name", "Category"), ("description", "Description"), ("books", "Books"),
                      ("created_date", "Created")], rows=rows, sum=["books"])


def r_authors(p):
    rows = db.query("SELECT a.*, (SELECT COUNT(*) FROM books b WHERE b.author_id = a.author_id) AS books FROM authors a ORDER BY a.author_name")
    return dict(cols=[("author_id", "Author ID"), ("author_name", "Author"), ("description", "Description"), ("books", "Books"),
                      ("created_date", "Created")], rows=rows, sum=["books"])


def r_publishers(p):
    rows = db.query("SELECT p.*, (SELECT COUNT(*) FROM books b WHERE b.publisher_id = p.publisher_id) AS books FROM publishers p ORDER BY p.publisher_name")
    return dict(cols=[("publisher_id", "Publisher ID"), ("publisher_name", "Publisher"), ("address", "Address"), ("email", "Email"),
                      ("phone", "Phone"), ("books", "Books"), ("created_date", "Created")], rows=rows, sum=["books"])


def r_inventory(p):
    w, a = [], []
    col = {"Available": "b.available_copies", "Damaged": "b.damaged_copies", "Lost": "b.lost_copies", "Scrapped": "b.scrapped_copies"}.get(p["stock"])
    if col:
        w.append(col + " > 0")
    rows = db.query("SELECT b.book_id, b.title, b.isbn, b.shelf_location, b.total_copies, b.available_copies, b.damaged_copies, b.lost_copies, b.scrapped_copies, au.author_name, c.category_name, "
                    "(b.total_copies - b.available_copies - b.damaged_copies - b.lost_copies - b.scrapped_copies) AS on_loan "
                    "FROM books b LEFT JOIN authors au ON au.author_id = b.author_id LEFT JOIN categories c ON c.category_id = b.category_id"
                    + _w(w) + " ORDER BY LENGTH(b.book_id), b.book_id", a)
    return dict(cols=[("book_id", "Book ID"), ("title", "Title"), ("isbn", "ISBN"), ("author_name", "Author"), ("category_name", "Category"),
                      ("shelf_location", "Shelf"), ("total_copies", "Total"), ("available_copies", "Available"), ("on_loan", "On loan"),
                      ("damaged_copies", "Damaged"), ("lost_copies", "Lost"), ("scrapped_copies", "Scrapped")], rows=rows,
                sum=["total_copies", "available_copies", "on_loan", "damaged_copies", "lost_copies", "scrapped_copies"])


def r_loans(p):
    w, a = [], []
    today = date.today()
    st = p["loan_status"]
    if st == "Overdue":
        w.append("l.status = 'Issued' AND l.due_date < %s")
        a.append(today)
    elif st != ALL:
        w.append("l.status = %s")
        a.append(st)
    _range("l.issue_date", p, w, a)
    rows = db.query("SELECT l.*, m.member_name, b.title FROM loans l JOIN members m ON m.member_id = l.member_id JOIN books b ON b.book_id = l.book_id"
                    + _w(w) + " ORDER BY LENGTH(l.loan_id), l.loan_id", a)
    for r in rows:
        late = (today - to_date(r["due_date"])).days if r["status"] == "Issued" else 0
        r["days_late"] = late if late > 0 else 0
        r["state"] = "Overdue" if late > 0 else r["status"]
    return dict(cols=[("loan_id", "Loan"), ("member_id", "Member ID"), ("member_name", "Member"), ("book_id", "Book ID"), ("title", "Book"),
                      ("issue_date", "Issued"), ("due_date", "Due"), ("return_date", "Returned / lost on"), ("renewal_count", "Renewals"),
                      ("days_late", "Days overdue"), ("state", "Status")], rows=rows, sum=["renewal_count", "days_late"])


def r_today_loans(p):
    """Loans issued today (the day the report is run), with the status they have now."""
    w, a = ["l.issue_date = %s"], [date.today()]
    _eq("l.status", p, "today_status", w, a)
    rows = db.query("SELECT l.*, m.member_name, b.title, COALESCE(u.full_name, u.username) AS issued_by_name FROM loans l "
                    "JOIN members m ON m.member_id = l.member_id JOIN books b ON b.book_id = l.book_id LEFT JOIN users u ON u.user_id = l.issued_by"
                    + _w(w) + " ORDER BY LENGTH(l.loan_id), l.loan_id", a)
    for r in rows:
        r["state"] = r["status"]
    return dict(cols=[("loan_id", "Loan"), ("member_id", "Member ID"), ("member_name", "Member"), ("book_id", "Book ID"), ("title", "Book"),
                      ("issue_date", "Issued"), ("due_date", "Due"), ("return_date", "Returned / lost on"), ("issued_by_name", "Issued by"), ("state", "Status")],
                rows=rows, sum=[])


def r_reservations(p):
    w, a = [], []
    _eq("r.status", p, "rsv_status", w, a)
    _range("r.reservation_date", p, w, a, "rfrom", "rto")
    _range("r.expiry_date", p, w, a, "efrom", "eto")
    rows = db.query("SELECT r.*, m.member_name, b.title FROM reservations r JOIN members m ON m.member_id = r.member_id "
                    "JOIN books b ON b.book_id = r.book_id" + _w(w) + " ORDER BY r.reservation_date, LENGTH(r.reservation_id), r.reservation_id", a)
    return dict(cols=[("reservation_id", "Reservation ID"), ("reservation_date", "Reserved on"), ("member_id", "Member ID"), ("member_name", "Member"),
                      ("book_id", "Book ID"), ("title", "Book"), ("status", "Status"), ("expiry_date", "Hold until / expiry date"), ("loan_id", "Loan")],
                rows=rows, sum=[])


def r_popular(p):
    w, a = [], []
    _range("l.issue_date", p, w, a)
    rows = db.query("SELECT b.book_id, b.title, au.author_name, c.category_name, COUNT(l.loan_id) AS times "
                    "FROM loans l JOIN books b ON b.book_id = l.book_id LEFT JOIN authors au ON au.author_id = b.author_id "
                    "LEFT JOIN categories c ON c.category_id = b.category_id" + _w(w)
                    + " GROUP BY b.book_id, b.title, au.author_name, c.category_name ORDER BY times DESC, b.title", a)
    if p["top"] != ALL:
        rows = rows[:int(p["top"])]
    for i, r in enumerate(rows, 1):
        r["rank"] = i
    return dict(cols=[("rank", "Rank"), ("book_id", "Book ID"), ("title", "Title"), ("author_name", "Author"), ("category_name", "Category"),
                      ("times", "Times borrowed")], rows=rows, sum=["times"])


def r_fines(p):
    w, a = [], []
    _eq("f.paid_status", p, "pay_status", w, a)
    _eq("f.waiver_type", p, "waiver", w, a)
    _eq("f.payment_method", p, "method", w, a)
    _range("f.fine_date", p, w, a)
    rows = db.query("SELECT f.*, l.member_id, l.book_id, m.member_name, b.title FROM fines f JOIN loans l ON l.loan_id = f.loan_id "
                    "JOIN members m ON m.member_id = l.member_id JOIN books b ON b.book_id = l.book_id" + _w(w)
                    + " ORDER BY LENGTH(f.fine_id), f.fine_id", a)
    for r in rows:
        r["status"] = r["paid_status"]
    return dict(cols=[("fine_id", "Fine ID"), ("fine_date", "Fine date"), ("member_id", "Member ID"), ("member_name", "Member"), ("book_id", "Book ID"),
                      ("loan_id", "Loan"), ("fine_amount", "Fine"), ("waived_amount", "Waived"), ("net_amount", "Net"), ("waiver_type", "Waiver type"),
                      ("status", "Payment status"), ("payment_method", "Payment method"), ("paid_date", "Payment date")],
                rows=rows, sum=["fine_amount", "waived_amount", "net_amount"])


def _next_month(d):
    return date(d.year + (d.month == 12), d.month % 12 + 1, 1)


def r_revenue(p):
    """Monthly financial analysis by the month the fine / record was raised, with Fines, Damaged and Lost shown separately.
    Damaged includes scrapped copies (a scrapped copy is a damaged copy taken out of use).
    Collected = net amount already Paid; Outstanding = net amount still Unpaid (waived money is never collected)."""
    kinds = [("f", "Fine"), ("d", "Damaged"), ("l", "Lost")]
    show = [k for k in kinds if p["rtype"] in (ALL, k[1])]
    fw, fa, dw, da = [], [], [], []
    if p.get("mfrom"):
        fw.append("f.fine_date >= %s"); fa.append(p["mfrom"]); dw.append("d.record_date >= %s"); da.append(p["mfrom"])
    if p.get("mto"):
        nxt = _next_month(p["mto"])
        fw.append("f.fine_date < %s"); fa.append(nxt); dw.append("d.record_date < %s"); da.append(nxt)
    if p["rpay"] != ALL:
        fw.append("f.paid_status = %s"); fa.append(p["rpay"]); dw.append("d.paid_status = %s"); da.append(p["rpay"])
    for key, fcol, dcol in (("method", "f.payment_method", "d.payment_method"), ("waiver", "f.waiver_type", "d.waiver_type")):
        if p[key] != ALL:
            fw.append(f"{fcol} = %s"); fa.append(p[key]); dw.append(f"{dcol} = %s"); da.append(p[key])
    sources = []
    if ("f", "Fine") in show:
        sources.append(("f", db.query("SELECT f.fine_date AS dt, f.fine_amount AS gross, f.waived_amount AS waived, f.net_amount AS net, f.paid_status FROM fines f" + _w(fw), fa)))
    for pre, name in (("d", "Damaged"), ("l", "Lost")):
        if (pre, name) in show:
            types = "('Damaged', 'Scrapped')" if pre == "d" else "('Lost')"
            sources.append((pre, db.query("SELECT d.record_date AS dt, d.amount AS gross, d.waived_amount AS waived, d.net_amount AS net, d.paid_status "
                                          "FROM damage_lost d" + _w(dw + [f"d.damage_type IN {types}"]), da)))
    zero = lambda: dict({pre + c: (0 if c == "_n" else Decimal("0")) for pre, _ in kinds for c in ("_n", "_gross", "_waived", "_net")},
                        tot_net=Decimal("0"), collected=Decimal("0"), outstanding=Decimal("0"))
    months = {}
    for pre, src in sources:
        for r in src:
            d = to_date(r["dt"]); m = months.setdefault(date(d.year, d.month, 1), zero())
            m[pre + "_n"] += 1
            for k, c in (("gross", "_gross"), ("waived", "_waived"), ("net", "_net")):
                m[pre + c] += Decimal(str(r[k] or 0))
            net = Decimal(str(r["net"] or 0)); m["tot_net"] += net
            if r["paid_status"] == "Paid":
                m["collected"] += net
            elif r["paid_status"] == "Unpaid":
                m["outstanding"] += net
    start = p.get("mfrom") or (min(months) if months else None); end = p.get("mto") or (max(months) if months else None)
    rows, cur = [], start
    while cur and end and cur <= end and len(rows) < 120:     # every month of the range is shown, also months without any money
        m = months.get(cur) or zero(); m["month"] = cur.strftime("%b %Y"); rows.append(m); cur = _next_month(cur)
    cols, sums = [("month", "Month")], []
    for pre, name in show:
        g = "Fines" if name == "Fine" else name
        cols += [(pre + "_n", "Fines" if name == "Fine" else f"{name} records"), (pre + "_gross", f"{g} charged"),
                 (pre + "_waived", f"{g} waived"), (pre + "_net", f"{g} net")]
        sums += [pre + c for c in ("_n", "_gross", "_waived", "_net")]
    cols += [("tot_net", "Total net revenue"), ("collected", "Collected (Paid)"), ("outstanding", "Outstanding (Unpaid)")]
    return dict(cols=cols, rows=rows, sum=sums + ["tot_net", "collected", "outstanding"])


def _dl(kind, params_full):
    def run(p):
        w, a = ["d.damage_type = %s"], [kind]
        status_expr = "CASE WHEN d.amount = 0 AND d.paid_status = 'Unpaid' THEN 'No charge' ELSE d.paid_status END"
        if params_full:
            if p["pay_status_dl"] != ALL:
                w.append(status_expr + " = %s")
                a.append(p["pay_status_dl"])
            _eq("d.waiver_type", p, "waiver", w, a)
            _eq("d.payment_method", p, "method", w, a)
        _range("d.record_date", p, w, a)
        rows = db.query(f"SELECT d.*, {status_expr} AS status, m.member_name, b.title FROM damage_lost d "
                        "LEFT JOIN members m ON m.member_id = d.member_id JOIN books b ON b.book_id = d.book_id" + _w(w)
                        + " ORDER BY LENGTH(d.damage_id), d.damage_id", a)
        return dict(cols=[("damage_id", "Record ID"), ("record_date", "Record date"), ("member_id", "Member ID"), ("member_name", "Member"),
                          ("book_id", "Book ID"), ("title", "Book"), ("loan_id", "Loan"), ("amount", "Amount"), ("waived_amount", "Waived"),
                          ("net_amount", "Net"), ("waiver_type", "Waiver type"), ("status", "Payment status"), ("payment_method", "Payment method"),
                          ("paid_date", "Payment date")], rows=rows, sum=["amount", "waived_amount", "net_amount"])
    return run


REPORTS = {
    "dashboard": ("Dashboard & Statistics", "Overview", [], r_dashboard),
    "activity": ("System Activity", "Overview", ["activity", "from", "to"], r_activity),
    "members": ("Members List", "Lists", ["member_type", "status", "jfrom", "jto"], r_members),
    "librarians": ("Librarian List", "Lists", ["status", "jfrom", "jto"], r_librarians),
    "categories": ("Category List", "Lists", [], r_categories),
    "authors": ("Author List", "Lists", [], r_authors),
    "publishers": ("Publication List", "Lists", [], r_publishers),
    "inventory": ("Book Inventory", "Lists", ["stock"], r_inventory),
    "loans": ("Loan", "Circulation", ["loan_status", "from", "to"], r_loans),
    "today_loans": ("Today Loan", "Circulation", ["today_status"], r_today_loans),
    "reservations": ("Reservation Report", "Circulation", ["rsv_status", "rfrom", "rto", "efrom", "eto"], r_reservations),
    "popular": ("Most Borrowed Books", "Circulation", ["top", "from", "to"], r_popular),
    "fines": ("Fine", "Fines & charges", ["pay_status", "waiver", "method", "from", "to"], r_fines),
    "damaged": ("Damaged", "Fines & charges", ["pay_status_dl", "waiver", "method", "from", "to"], _dl("Damaged", True)),
    "lost": ("Lost", "Fines & charges", ["pay_status_dl", "waiver", "method", "from", "to"], _dl("Lost", True)),
    "scrapped": ("Scrapped", "Fines & charges", ["from", "to"], _dl("Scrapped", False)),
    "revenue": ("Library Revenue Report", "Fines & charges", ["mfrom", "mto", "rtype", "rpay", "method", "waiver"], r_revenue),
}


def _sel_text(names, p):
    parts = []
    for n in names:
        label, opts = PARAMS[n]
        v = p.get(n)
        if opts in ("date", "month"):
            if v:
                parts.append(f"{label}: {v:%b %Y}" if opts == "month" else f"{label}: {v:%d %b %Y}")
        elif v and v != ALL:
            parts.append(f"{label}: {v}")
    return "; ".join(parts) or "All records"


def with_total(cols, rows, sum_cols):
    """Bottom row: 'Net Total' when the report has money columns, otherwise 'Total'; plus the record count."""
    if not rows:
        return rows
    tot = {k: "" for k, _ in cols}
    tot["_total"] = True
    money = [k for k in sum_cols if k in MONEY_COLS]
    tot[cols[0][0]] = "Net Total" if money else "Total"
    tot[cols[1][0]] = f"{len(rows)} record(s)"
    for k in sum_cols:
        vals = [r[k] for r in rows if r.get(k) is not None]
        if k in MONEY_COLS:
            tot[k] = sum((Decimal(str(v)) for v in vals), Decimal("0")).quantize(Decimal("0.01"))
        else:
            tot[k] = sum(int(v) for v in vals)
    return rows + [tot]


LIBRARIAN_KEYS = ("members", "categories", "authors", "publishers", "inventory", "loans", "today_loans", "reservations", "popular", "fines", "damaged", "lost", "scrapped")


def _visible():
    """Administrator: all reports. Librarian: the list / circulation / fine reports (no dashboard, activity, librarians, revenue)."""
    if g.user["role"] == "Admin":
        return REPORTS
    return {k: v for k, v in REPORTS.items() if k in LIBRARIAN_KEYS}


def _page(**kw):
    return render_template("admin/admin_reports.html", bpname=request.blueprint, PARAMS=PARAMS, page_title="Administrator Reports" if g.user["role"] == "Admin" else "Reports", **kw)


def _build(key):
    if key not in REPORTS:
        abort(404)
    if key not in _visible():
        abort(403)
    title, group, names, fn = REPORTS[key]
    p = _parse_params(names)
    res = fn(p)
    rows = res["rows"]
    summary = [("Records", str(len(rows))), ("Parameters", _sel_text(names, p))]
    return title, names, p, res["cols"], rows, summary, res["sum"]


@bp.route("/")
@role_required("Admin", "Librarian")
def index():
    return _page(reports=_visible(), key=None)


@bp.route("/<key>")
@role_required("Admin", "Librarian")
def view(key):
    title, names, p, cols, rows, summary, sum_cols = _build(key)
    count = len(rows)
    rows = with_total(cols, rows, sum_cols)
    qs = {n: ((v.strftime('%Y-%m') if PARAMS[n][1] == 'month' else v.isoformat()) if hasattr(v, "isoformat") else v) for n, v in p.items() if v and v != ALL and not (n in DEFAULTS and v == DEFAULTS[n])}
    return _page(reports=_visible(), key=key, title=title, names=names, p=p, cols=cols,
                 rows=rows, count=count, summary=summary, money_cols=MONEY_COLS, qs=qs)


def _qs_keep():
    return request.query_string.decode()


@bp.route("/<key>/pdf")
@role_required("Admin", "Librarian")
def pdf(key):
    title, names, p, cols, rows, summary, sum_cols = _build(key)
    rows = with_total(cols, rows, sum_cols)
    return Response(build_pdf(title, cols, rows, summary, g.user), mimetype="application/pdf",
                    headers={"Content-Disposition": f"attachment; filename=smlib_admin_{key}_{date.today()}.pdf"})


@bp.route("/<key>/csv")
@role_required("Admin", "Librarian")
def csv_export(key):
    title, names, p, cols, rows, summary, sum_cols = _build(key)
    rows = with_total(cols, rows, sum_cols)
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow([label for _, label in cols])
    for r in rows:
        w.writerow(["" if r.get(k) is None else r.get(k) for k, _ in cols])
    return Response(buf.getvalue(), mimetype="text/csv",
                    headers={"Content-Disposition": f"attachment; filename=smlib_admin_{key}_{date.today()}.csv"})
