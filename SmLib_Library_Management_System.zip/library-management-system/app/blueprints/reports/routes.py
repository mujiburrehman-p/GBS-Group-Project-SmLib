"""Generate All Report - Librarian and Admin, with CSV and PDF export.

Two read-only amount-checking reports (fines and damage/lost) are visible to the Admin only."""
import csv
import io
from datetime import date

from decimal import Decimal

from flask import Blueprint, render_template, Response, abort, g

from app import db
from app.decorators import role_required, STAFF
from app.services.fine_service import fine_for_days
from app.utils import to_date

bp = Blueprint("reports", __name__, url_prefix="/reports")

REPORTS = {
    "overdue": ("Overdue loans",
        "SELECT l.loan_id, l.member_id, m.member_name, b.title, l.issue_date, l.due_date FROM loans l "
        "JOIN members m ON m.member_id = l.member_id JOIN books b ON b.book_id = l.book_id "
        "WHERE l.status = 'Issued' AND l.due_date < %s ORDER BY LENGTH(l.loan_id), l.loan_id",
        [("loan_id", "Loan"), ("member_id", "Member ID"), ("member_name", "Member"), ("title", "Book"),
         ("issue_date", "Issued"), ("due_date", "Due"), ("days_overdue", "Days overdue"),
         ("est_fine", "Estimated fine")]),
    "current_loans": ("Books currently on loan",
        "SELECT l.loan_id, l.member_id, m.member_name, b.title, l.issue_date, l.due_date, l.renewal_count "
        "FROM loans l JOIN members m ON m.member_id = l.member_id JOIN books b ON b.book_id = l.book_id "
        "WHERE l.status = 'Issued' ORDER BY LENGTH(l.loan_id), l.loan_id",
        [("loan_id", "Loan"), ("member_id", "Member ID"), ("member_name", "Member"), ("title", "Book"),
         ("issue_date", "Issued"), ("due_date", "Due"), ("renewal_count", "Renewals")]),
    "inventory": ("Book inventory",
        "SELECT b.book_id, b.title, c.category_name, b.shelf_location, b.total_copies, b.available_copies, "
        "(SELECT COUNT(*) FROM loans l WHERE l.book_id = b.book_id AND l.status = 'Issued') AS issued_copies, "
        "b.damaged_copies, b.scrapped_copies, b.lost_copies FROM books b LEFT JOIN categories c ON c.category_id = b.category_id "
        "ORDER BY LENGTH(b.book_id), b.book_id",
        [("book_id", "Book ID"), ("title", "Title"), ("category_name", "Category"), ("shelf_location", "Shelf"),
         ("total_copies", "Total"), ("available_copies", "Available"), ("issued_copies", "Issued"),
         ("damaged_copies", "Damaged"), ("scrapped_copies", "Scrapped"), ("lost_copies", "Lost")]),
    "popular": ("Most borrowed books",
        "SELECT * FROM (SELECT b.book_id, b.title, COUNT(l.loan_id) AS times_borrowed FROM books b "
        "LEFT JOIN loans l ON l.book_id = b.book_id GROUP BY b.book_id, b.title "
        "ORDER BY times_borrowed DESC, b.title LIMIT 20) top20 ORDER BY LENGTH(book_id), book_id",
        [("book_id", "Book ID"), ("title", "Title"), ("times_borrowed", "Times borrowed")]),
    "fines": ("Fines",
        "SELECT f.fine_id, l.member_id, m.member_name, b.title, f.fine_amount, f.paid_status AS status, f.waiver_type, f.waived_amount, f.net_amount, "
        " f.fine_date, f.paid_date, f.payment_method FROM fines f JOIN loans l ON l.loan_id = f.loan_id "
        "JOIN members m ON m.member_id = l.member_id JOIN books b ON b.book_id = l.book_id ORDER BY LENGTH(f.fine_id), f.fine_id",
        [("fine_id", "Fine"), ("member_id", "Member ID"), ("member_name", "Member"), ("title", "Book"),
         ("fine_amount", "Fine"), ("status", "Payment Status"), ("waiver_type", "Waiver type"),
         ("waived_amount", "Waived"), ("net_amount", "Net"),
         ("fine_date", "Date"), ("paid_date", "Paid on"), ("payment_method", "Method")]),
    "damage": ("Damaged, scrapped and lost books",
        "SELECT d.damage_id, d.record_date, b.title, d.damage_type, d.member_id, d.amount, "
        "CASE WHEN d.amount = 0 AND d.paid_status = 'Unpaid' THEN 'No charge' ELSE d.paid_status END AS status, d.waiver_type, d.waived_amount, d.net_amount FROM damage_lost d JOIN books b ON b.book_id = d.book_id "
        "ORDER BY LENGTH(d.damage_id), d.damage_id",
        [("damage_id", "Record"), ("record_date", "Date"), ("title", "Book"), ("damage_type", "Type"),
         ("member_id", "Member ID"), ("amount", "Amount"), ("status", "Payment Status"), ("waiver_type", "Waiver type"),
         ("waived_amount", "Waived"), ("net_amount", "Net")]),
    "fines_amounts": ("Fines - amount check (Admin)",
        "SELECT f.fine_id, l.member_id, m.member_name, b.title, f.fine_amount, f.paid_status AS status, f.waiver_type, f.waived_amount, f.net_amount, "
        " f.fine_date, f.paid_date FROM fines f JOIN loans l ON l.loan_id = f.loan_id "
        "JOIN members m ON m.member_id = l.member_id JOIN books b ON b.book_id = l.book_id "
        "ORDER BY LENGTH(f.fine_id), f.fine_id",
        [("fine_id", "Fine"), ("member_id", "Member ID"), ("member_name", "Member"), ("title", "Book"),
         ("fine_amount", "Fine"), ("status", "Payment Status"), ("waiver_type", "Waiver type"),
         ("waived_amount", "Waived"), ("net_amount", "Net"),
         ("expected_net", "Expected net"), ("fine_date", "Date"),
         ("amount_check", "Amount check")]),
    "damage_amounts": ("Damaged / lost - amount check (Admin)",
        "SELECT d.damage_id, d.record_date, b.title, d.damage_type, d.member_id, d.amount, "
        "CASE WHEN d.amount = 0 AND d.paid_status = 'Unpaid' THEN 'No charge' ELSE d.paid_status END AS status, d.waiver_type, d.waived_amount, d.net_amount FROM damage_lost d JOIN books b ON b.book_id = d.book_id "
        "ORDER BY LENGTH(d.damage_id), d.damage_id",
        [("damage_id", "Record"), ("record_date", "Date"), ("title", "Book"), ("damage_type", "Type"),
         ("member_id", "Member ID"), ("amount", "Amount"), ("status", "Payment Status"), ("waiver_type", "Waiver type"),
         ("waived_amount", "Waived"), ("net_amount", "Net"),
         ("expected_net", "Expected net"), ("amount_check", "Amount check")]),
    "members": ("Member activity",
        "SELECT m.member_id, m.member_name, m.member_type, m.status, "
        "(SELECT COUNT(*) FROM loans l WHERE l.member_id = m.member_id) AS total_loans, "
        "(SELECT COUNT(*) FROM loans l WHERE l.member_id = m.member_id AND l.status = 'Issued') AS active_loans "
        "FROM members m ORDER BY LENGTH(m.member_id), m.member_id",
        [("member_id", "Member ID"), ("member_name", "Name"), ("member_type", "Type"), ("status", "Status"),
         ("total_loans", "Total loans"), ("active_loans", "Active loans")]),
}


ADMIN_ONLY = {"fines_amounts", "damage_amounts"}
MONEY_COLS = ("fine_amount", "waived_amount", "net_amount", "amount", "est_fine", "expected_net",
              "f_gross", "f_waived", "f_net", "d_gross", "d_waived", "d_net", "l_gross", "l_waived", "l_net", "tot_net", "collected", "outstanding")


def visible_reports():
    if g.user and g.user["role"] == "Admin":
        return REPORTS
    return {k: v for k, v in REPORTS.items() if k not in ADMIN_ONLY}


def _amount_check(r, gross_key):
    """Read-only audit of one fine / damage record: net = amount - waived, waived <= amount, status rules."""
    gross, waived, net = (Decimal(str(r[gross_key])), Decimal(str(r["waived_amount"])), Decimal(str(r["net_amount"])))
    r["expected_net"] = gross - waived
    problems = []
    if net != gross - waived:
        problems.append("Net is not amount minus waived")
    if waived > gross or gross < 0 or waived < 0:
        problems.append("Waived is more than the amount")
    if r["status"] == "Waived" and waived != gross:
        problems.append("Status Waived but not fully waived")
    r["amount_check"] = "OK" if not problems else "CHECK: " + "; ".join(problems)


def _summary(key, rows):
    gk = "fine_amount" if key == "fines_amounts" else "amount"
    d = lambda k: sum((Decimal(str(r[k])) for r in rows), Decimal("0"))
    by = lambda st: sum((Decimal(str(r["net_amount"])) for r in rows if r["status"] == st), Decimal("0"))
    return [("Records", str(len(rows))), ("Total amount", f"\u00a3{d(gk):,.2f}"),
            ("Total waived", f"\u00a3{d('waived_amount'):,.2f}"), ("Total net", f"\u00a3{d('net_amount'):,.2f}"),
            ("Net paid", f"\u00a3{by('Paid'):,.2f}"), ("Net unpaid (outstanding)", f"\u00a3{by('Unpaid'):,.2f}"),
            ("Records needing a check", str(sum(1 for r in rows if r["amount_check"] != "OK")))]


def _run(key):
    if key not in REPORTS:
        abort(404)
    if key in ADMIN_ONLY and g.user["role"] != "Admin":
        abort(403)
    title, sql, cols = REPORTS[key]
    today = date.today()
    rows = db.query(sql, (today,) if "%s" in sql else ())
    summary = None
    if key == "overdue":
        for r in rows:
            r["days_overdue"] = (today - to_date(r["due_date"])).days
            r["est_fine"] = fine_for_days(r["days_overdue"])
    if key in ADMIN_ONLY:
        for r in rows:
            _amount_check(r, "fine_amount" if key == "fines_amounts" else "amount")
        summary = _summary(key, rows)
    return title, cols, rows, summary


def _cell(r, k):
    v = r.get(k)
    if v is None:
        return "-"
    if v == "":
        return ""
    if "date" in k:
        try:
            return to_date(v).strftime("%d %b %Y") if to_date(v) else "-"
        except ValueError:                      # a total-row label such as "10 record(s)" in a date column
            return str(v)
    if k in MONEY_COLS:
        return f"\u00a3{float(v):,.2f}"
    return str(v)


@bp.route("/")
@role_required(*STAFF)
def index():
    return render_template("librarian/reports.html", reports=visible_reports(), key=None)


@bp.route("/<key>")
@role_required(*STAFF)
def view(key):
    title, cols, rows, summary = _run(key)
    return render_template("librarian/reports.html", reports=visible_reports(), key=key, title=title,
                           cols=cols, rows=rows, summary=summary, money_cols=MONEY_COLS)


@bp.route("/<key>/csv")
@role_required(*STAFF)
def export(key):
    title, cols, rows, summary = _run(key)
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow([label for _, label in cols])
    for r in rows:
        w.writerow(["" if r.get(k) is None else r.get(k) for k, _ in cols])
    return Response(buf.getvalue(), mimetype="text/csv",
                    headers={"Content-Disposition": f"attachment; filename=smlib_{key}_{date.today()}.csv"})


def build_pdf(title, cols, rows, summary, user):
    """Landscape A4 PDF of one report; returns the PDF bytes."""
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4, landscape
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.units import mm
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Table, TableStyle, Spacer

    ss = getSampleStyleSheet()
    cell = ParagraphStyle("c", parent=ss["Normal"], fontSize=7.5, leading=9)
    head = ParagraphStyle("h", parent=cell, textColor=colors.white, fontName="Helvetica-Bold")
    buf = io.BytesIO()
    from datetime import datetime
    from reportlab.pdfgen import canvas as rl_canvas
    W, H = landscape(A4)
    who = f"{(user or {}).get('member_id') or (user or {}).get('user_id') or ''} {(user or {}).get('name') or ''}".strip()
    stamp = datetime.now().strftime("%d/%m/%Y %H:%M")
    ink = colors.HexColor("#1f2a44")

    class NumberedCanvas(rl_canvas.Canvas):
        """Two-pass canvas so the footer can show 'Page current/total'."""
        def __init__(self, *a, **k):
            super().__init__(*a, **k)
            self._saved = []

        def showPage(self):
            self._saved.append(dict(self.__dict__))
            self._startPage()

        def save(self):
            total = len(self._saved)
            for st in self._saved:
                self.__dict__.update(st)
                self._decorate(total)
                super().showPage()
            super().save()

        def _decorate(self, total):
            self.saveState()
            self.setFillColor(ink)
            self.setFont("Helvetica-Bold", 9)                 # header left / right: bold
            self.drawString(12 * mm, H - 9 * mm, "SmLib")
            self.drawRightString(W - 12 * mm, H - 9 * mm, who)
            self.setFont("Helvetica-Bold", 12)                # header centre: report title, bold
            self.drawCentredString(W / 2, H - 9 * mm, title.upper())
            self.setStrokeColor(colors.HexColor("#c9d4ee"))
            self.line(12 * mm, H - 11.5 * mm, W - 12 * mm, H - 11.5 * mm)
            self.line(12 * mm, 12 * mm, W - 12 * mm, 12 * mm)
            self.setFont("Helvetica-Bold", 8)                 # footer: bold
            self.drawString(12 * mm, 8 * mm, stamp)
            self.drawRightString(W - 12 * mm, 8 * mm, f"Page {self._pageNumber}/{total}")
            self.restoreState()

    doc = SimpleDocTemplate(buf, pagesize=landscape(A4), leftMargin=12 * mm, rightMargin=12 * mm,
                            topMargin=18 * mm, bottomMargin=16 * mm, title=f"SmLib - {title}")
    story = [Spacer(1, 2)]
    if summary:
        st = Table([[Paragraph(f"<b>{a}</b>", cell), Paragraph(b, cell)] for a, b in summary], colWidths=[60 * mm, 40 * mm])
        st.setStyle(TableStyle([("GRID", (0, 0), (-1, -1), .25, colors.HexColor("#c9d4ee")),
                                ("BACKGROUND", (0, 0), (0, -1), colors.HexColor("#eef3ff"))]))
        story += [st, Spacer(1, 8)]
    data = [[Paragraph(label, head) for _, label in cols]]
    for r in rows:
        data.append([Paragraph(_cell(r, k).replace("&", "&amp;").replace("<", "&lt;"), cell) for k, _ in cols])
    if len(data) == 1:
        data.append([Paragraph("Nothing to report.", cell)] + [""] * (len(cols) - 1))
    t = Table(data, repeatRows=1, colWidths=[(landscape(A4)[0] - 24 * mm) / len(cols)] * len(cols))
    t.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1456c8")),
                           ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f3f6ff")]),
                           ("GRID", (0, 0), (-1, -1), .25, colors.HexColor("#c9d4ee")),
                           ("VALIGN", (0, 0), (-1, -1), "TOP")]))
    story.append(t)
    doc.build(story, canvasmaker=NumberedCanvas)
    return buf.getvalue()


@bp.route("/<key>/pdf")
@role_required(*STAFF)
def export_pdf(key):
    title, cols, rows, summary = _run(key)
    return Response(build_pdf(title, cols, rows, summary, g.user), mimetype="application/pdf",
                    headers={"Content-Disposition": f"attachment; filename=smlib_{key}_{date.today()}.pdf"})
