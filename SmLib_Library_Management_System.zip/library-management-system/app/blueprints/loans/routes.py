"""Issue Books, Return Books, renewals and Member: View Loan Details."""
from datetime import date
from decimal import Decimal
from flask import Blueprint, render_template, request, redirect, url_for, flash, g

from app.decorators import role_required, member_required, STAFF
from app.models import loan as loan_model, member as member_model, book as book_model, fine as fine_model
from app.services import loan_service, fine_service, reservation_service, damage_service
from app.utils import BusinessError

bp = Blueprint("loans", __name__)


@bp.route("/loans")
@role_required(*STAFF)
def index():
    # Return a Book shows loans that are still out: All = On loan + Overdue (returned / lost loans are not listed)
    status, q = request.args.get("status", ""), request.args.get("q", "").strip()
    if status not in ("OnLoan", "Overdue"):
        status = ""
    rows = loan_model.search(status or "Issued", q, today=date.today())
    return render_template("librarian/loans.html", rows=rows, status=status, q=q,
                           fine_for_days=fine_service.fine_for_days)


@bp.route("/loans/issue", methods=["GET", "POST"])
@role_required(*STAFF)
def issue():
    if request.method == "POST":
        member_id = (request.form.get("member_id") or "").strip().upper()
        book_id = (request.form.get("book_id") or "").strip().upper()
        reservation_service.expire_old()   # release lapsed holds first (explicit POST action)
        loan_id, due = loan_service.issue(book_id, member_id, g.user)
        bk, mb = book_model.get(book_id), member_model.get(member_id)
        flash(f"This book {book_id} - {bk['title']} is issued to {member_id} - {mb['member_name']}. "
              f"Loan {loan_id}, due back on {due:%d %b %Y}.", "success")
        return redirect(url_for("loans.issue"))     # stay on Issue Book to issue another book / person
    members = member_model.options()
    if g.user["role"] != "Admin":       # a Librarian issues to Staff and Student members only
        members = [m for m in members if m["member_type"] != "Librarian"]
    return render_template("librarian/issue.html", members=members,
                           books=[b for b in book_model.search() if book_model.issuable(b) > 0],   # Available 0 (after held copies) is not offered
                           pre_member=request.args.get("member_id", ""),
                           pre_book=request.args.get("book_id", ""))


@bp.route("/loans/<loan_id>/return", methods=["POST"])
@role_required(*STAFF)
def return_book(loan_id):
    reservation_service.expire_old()
    days, fine_id = loan_service.return_loan(loan_id, g.user)
    if fine_id:
        flash(f"Loan {loan_id} returned {days} day(s) late. Overdue fine {fine_id} was recorded - confirm the payment below or pay later.", "warning")
        return redirect(url_for("fines.payment", fine_id=fine_id))
    else:
        flash(f"Loan {loan_id} returned.", "success")
    return redirect(request.referrer or url_for("loans.index"))


@bp.route("/loans/<loan_id>/lost", methods=["POST"])
@role_required(*STAFF)
def lost(loan_id):
    """Lost button on Return a Book: after the confirmation the loss is recorded at once.
    The member is charged the book price (replacement cost). If the loan is overdue the overdue fine is
    created too and the Fine Payment screen opens; otherwise the Lost charge payment screen opens."""
    loan = loan_model.get(loan_id)
    if not loan:
        raise BusinessError("Loan not found.")
    book = book_model.get(loan["book_id"])
    price = Decimal(str(book["price"] or 0))
    damage_id = damage_service.record(g.user, loan["book_id"], "Lost", loan_id, price,
                                      "Lost on loan - replacement cost charged")
    fine = fine_model.by_loan(loan_id)
    if fine and fine["paid_status"] == "Unpaid" and price > 0:      # overdue AND lost: one combined payment screen
        flash(f"Book {loan['book_id']} of loan {loan_id} recorded as Lost ({damage_id}, charge £{price:.2f}) and overdue fine "
              f"{fine['fine_id']} was recorded - confirm the payment below or pay later.", "warning")
        return redirect(url_for("fines.fine_lost_payment", fine_id=fine["fine_id"], damage_id=damage_id))
    if fine and fine["paid_status"] == "Unpaid":
        flash(f"Book {loan['book_id']} of loan {loan_id} recorded as Lost ({damage_id}, charge £{price:.2f}). "
              f"Overdue fine {fine['fine_id']} was recorded - confirm the payment below or pay later.", "warning")
        return redirect(url_for("fines.payment", fine_id=fine["fine_id"]))
    flash(f"Book {loan['book_id']} of loan {loan_id} recorded as Lost ({damage_id}, charge £{price:.2f}).", "warning")
    if price > 0:
        return redirect(url_for("damage_lost.payment", damage_id=damage_id, back="loans"))
    return redirect(url_for("loans.index"))


@bp.route("/loans/<loan_id>/renew", methods=["POST"])
@role_required(*STAFF)
def renew(loan_id):
    new_due = loan_service.renew(loan_id, g.user)
    flash(f"Loan {loan_id} renewed. New due date: {new_due:%d %b %Y}.", "success")
    return redirect(request.referrer or url_for("loans.index"))


@bp.route("/my/loans")
@member_required
def my_loans():
    rows = loan_model.search(member_id=g.user["member_id"], today=date.today())
    return render_template("member/my_loans.html", rows=rows, fine_for_days=fine_service.fine_for_days)
