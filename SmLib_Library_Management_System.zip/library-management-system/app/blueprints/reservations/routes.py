"""Member: Reserve Book. Staff: manage reservations."""
from datetime import date

from flask import Blueprint, render_template, request, redirect, url_for, flash, g

from app.decorators import role_required, member_required, login_required, STAFF
from app.models import reservation as res_model, book as book_model, member as member_model
from app.services import reservation_service, loan_service
from app.utils import BusinessError
from app.utils import to_date

bp = Blueprint("reservations", __name__)


@bp.route("/reservations")
@role_required(*STAFF)
def index():
    """Read-only view: nothing is written to the database when this page is opened or refreshed."""
    status, q = request.args.get("status", "Active"), request.args.get("q", "").strip()
    rows = res_model.search(status or None, q=q)
    _mark_lapsed(rows)
    return render_template("librarian/reservations.html", rows=rows, status=status, q=q)


def _mark_lapsed(rows):
    """Show a Ready reservation whose hold date has passed as Expired (display only, no database write)."""
    today = date.today()
    for r in rows:
        if r["status"] == "Ready" and r["expiry_date"] and to_date(r["expiry_date"]) < today:
            r["status"] = "Expired"


@bp.route("/reservations/expire", methods=["POST"])
@role_required(*STAFF)
def expire():
    """Explicit action: release lapsed holds and promote the next person in each queue."""
    n = reservation_service.expire_old()
    flash(f"{n} expired hold(s) released.", "success")
    return redirect(url_for("reservations.index"))


@bp.route("/reserve/<book_id>", methods=["POST"])
@member_required
def reserve(book_id):
    reservation_service.expire_old()
    r = reservation_service.reserve(g.user["member_id"], book_id)
    if r["status"] == "Ready":
        flash(f"A copy is being held for you until {to_date(r['expiry_date']):%d %b %Y}. Please collect it from the library.",
              "success")
    else:
        flash("Reservation placed. You will be at the front of the queue when a copy is returned.", "success")
    return redirect(url_for("reservations.my_reservations"))


@bp.route("/reservations/<reservation_id>/issue", methods=["POST"])
@role_required(*STAFF)
def issue(reservation_id):
    """Issue button on the Reservations screen: after the confirmation box the book is issued at once."""
    reservation_service.expire_old()
    r = res_model.get(reservation_id)
    if not r:
        raise BusinessError("Reservation not found.")
    if r["status"] != "Ready":
        raise BusinessError(f"Reservation {reservation_id} is {r['status']} - only a Ready reservation can be issued.")
    loan_id, due = loan_service.issue(r["book_id"], r["member_id"], g.user)
    bk, mb = book_model.get(r["book_id"]), member_model.get(r["member_id"])
    flash(f"This book {r['book_id']} - {bk['title']} is issued to {r['member_id']} - {mb['member_name']} "
          f"(reservation {reservation_id}). Loan {loan_id}, due back on {due:%d %b %Y}.", "success")
    return redirect(url_for("reservations.index"))


@bp.route("/reservations/<reservation_id>/cancel", methods=["POST"])
@login_required
def cancel(reservation_id):
    reservation_service.expire_old()
    own = None if g.user["role"] in STAFF else g.user["member_id"]
    reservation_service.cancel(reservation_id, own)
    flash(f"Reservation {reservation_id} cancelled.", "success")
    return redirect(request.referrer or url_for("reservations.my_reservations"))


@bp.route("/my/reservations")
@member_required
def my_reservations():
    rows = res_model.search(member_id=g.user["member_id"])
    _mark_lapsed(rows)
    return render_template("member/my_reservations.html", rows=rows)
