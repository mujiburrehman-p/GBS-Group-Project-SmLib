"""MySQL access helpers (PyMySQL, raw SQL so every schema constraint is honoured)."""
import pymysql
from pymysql.cursors import DictCursor
from flask import g, current_app


def get_db():
    if "db" not in g:
        c = current_app.config
        g.db = pymysql.connect(
            host=c["DB_HOST"], port=c["DB_PORT"], user=c["DB_USER"],
            password=c["DB_PASSWORD"], database=c["DB_NAME"],
            charset="utf8mb4", cursorclass=DictCursor, autocommit=False,
        )
    return g.db


def close_db(exc=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()          # closing without commit rolls back any open transaction


def query(sql, args=()):
    with get_db().cursor() as cur:
        cur.execute(sql, args)
        return list(cur.fetchall())


def one(sql, args=()):
    rows = query(sql, args)
    return rows[0] if rows else None


def execute(sql, args=()):
    with get_db().cursor() as cur:
        cur.execute(sql, args)
        return cur.rowcount


def commit():
    get_db().commit()


def rollback():
    get_db().rollback()
