"""D6 books."""
from app import db

COLS = ("b.book_id, b.title, b.isbn, b.author_id, b.publisher_id, b.category_id, b.publish_year, b.edition, b.price, "
        "b.shelf_location, b.product_description, b.total_copies, b.available_copies, b.damaged_copies, b.lost_copies, "
        "b.scrapped_copies, b.created_by, b.created_date, (b.cover_page IS NOT NULL) AS has_cover")
# the cover image itself (a large BLOB) is never selected in lists; it is read only by cover()
SEL = ("SELECT " + COLS + ", a.author_name, p.publisher_name, c.category_name, "
       "(SELECT COUNT(*) FROM loans l WHERE l.book_id = b.book_id AND l.status = 'Issued') AS issued_copies, "
       "(SELECT COUNT(*) FROM reservations r WHERE r.book_id = b.book_id AND r.status = 'Ready' AND r.expiry_date >= CURRENT_DATE) AS held_copies "
       "FROM books b LEFT JOIN authors a ON a.author_id = b.author_id "
       "LEFT JOIN publishers p ON p.publisher_id = b.publisher_id "
       "LEFT JOIN categories c ON c.category_id = b.category_id")

FIELDS = ["title", "isbn", "author_id", "publisher_id", "category_id", "publish_year",
          "edition", "price", "shelf_location", "product_description"]
MAX_COVER_BYTES = 2 * 1024 * 1024
MAX_DESCRIPTION = 255


def issuable(book):
    """Copies on the shelf that can be issued (copies held for Ready reservations are excluded)."""
    return max(0, book["available_copies"] - book["held_copies"])


def search(q=None, category_id=None):
    sql, args, where = SEL, [], []
    if q:
        where.append("(b.title LIKE %s OR a.author_name LIKE %s OR b.isbn LIKE %s OR b.book_id LIKE %s)")
        args += [f"%{q}%"] * 4
    if category_id:
        where.append("b.category_id = %s")
        args.append(category_id)
    if where:
        sql += " WHERE " + " AND ".join(where)
    return db.query(sql + " ORDER BY LENGTH(b.book_id), b.book_id LIMIT 5000", args)


def get(book_id):
    return db.one(SEL + " WHERE b.book_id = %s", (book_id,))


def lock(book_id):
    """Lock the row inside a transaction so two librarians cannot issue the last copy twice."""
    return db.one("SELECT book_id FROM books WHERE book_id = %s FOR UPDATE", (book_id,))


def isbn_taken(isbn, exclude_id=None):
    r = db.one("SELECT book_id FROM books WHERE isbn = %s", (isbn,))
    return bool(r and r["book_id"] != exclude_id)


def create(book_id, d, total, created_by, cover=None):
    db.execute("INSERT INTO books (book_id, title, isbn, author_id, publisher_id, category_id, publish_year, "
               "edition, price, shelf_location, product_description, cover_page, total_copies, available_copies, "
               "damaged_copies, lost_copies, scrapped_copies, created_by) "
               "VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,0,0,0,%s)",
               (book_id, d["title"], d["isbn"], d["author_id"], d["publisher_id"], d["category_id"],
                d["publish_year"], d["edition"], d["price"], d["shelf_location"], d["product_description"],
                cover, total, total, created_by))


def update(book_id, d, add_copies=0, cover=None, remove_cover=False):
    """Update the details of a book. add_copies (>= 0) is added to BOTH total_copies and available_copies
    in the same statement (relative update), so total = available + issued + damaged + lost + scrapped always holds."""
    db.execute("UPDATE books SET title=%s, isbn=%s, author_id=%s, publisher_id=%s, category_id=%s, "
               "publish_year=%s, edition=%s, price=%s, shelf_location=%s, product_description=%s, "
               "total_copies = total_copies + %s, available_copies = available_copies + %s WHERE book_id=%s",
               (d["title"], d["isbn"], d["author_id"], d["publisher_id"], d["category_id"],
                d["publish_year"], d["edition"], d["price"], d["shelf_location"], d["product_description"],
                add_copies, add_copies, book_id))
    if cover is not None:                                   # a new image replaces the old one
        db.execute("UPDATE books SET cover_page = %s WHERE book_id = %s", (cover, book_id))
    elif remove_cover:
        db.execute("UPDATE books SET cover_page = NULL WHERE book_id = %s", (book_id,))


def cover(book_id):
    """The cover image bytes of a book, or None."""
    r = db.one("SELECT cover_page FROM books WHERE book_id = %s", (book_id,))
    return bytes(r["cover_page"]) if r and r["cover_page"] else None


def image_type(data):
    """Detect the image type from the first bytes (never trust the file name). None if not an allowed image."""
    if data[:8] == b"\x89PNG\r\n\x1a\n":
        return "image/png"
    if data[:3] == b"\xff\xd8\xff":
        return "image/jpeg"
    if data[:6] in (b"GIF87a", b"GIF89a"):
        return "image/gif"
    if data[:4] == b"RIFF" and data[8:12] == b"WEBP":
        return "image/webp"
    return None


def adjust(book_id, available=0, damaged=0, lost=0, scrapped=0):
    db.execute("UPDATE books SET available_copies = available_copies + %s, damaged_copies = damaged_copies + %s, "
               "lost_copies = lost_copies + %s, scrapped_copies = scrapped_copies + %s WHERE book_id = %s",
               (available, damaged, lost, scrapped, book_id))


def delete(book_id):
    db.execute("DELETE FROM books WHERE book_id = %s", (book_id,))
