"""Generic CRUD for the three master tables (authors, publishers, categories)."""
from app import db
from app.services.id_generator import next_id


class Lookup:
    def __init__(self, table, pk, prefix, fields, label, plural):
        self.table, self.pk, self.prefix = table, pk, prefix
        self.fields, self.label, self.plural = fields, label, plural   # fields[0] is the name column

    def all(self, q=None):
        sql = (f"SELECT t.*, (SELECT COUNT(*) FROM books b WHERE b.{self.pk} = t.{self.pk}) AS book_count "
               f"FROM {self.table} t")
        args = ()
        if q:
            sql += f" WHERE t.{self.fields[0]} LIKE %s"
            args = (f"%{q}%",)
        return db.query(sql + f" ORDER BY LENGTH(t.{self.pk}), t.{self.pk}", args)

    def get(self, id_):
        return db.one(f"SELECT * FROM {self.table} WHERE {self.pk} = %s", (id_,))

    def create(self, data, user_id):
        new_id = next_id(self.table, self.pk, self.prefix)
        cols = [self.pk] + self.fields + ["created_by"]
        db.execute(f"INSERT INTO {self.table} ({', '.join(cols)}) VALUES ({', '.join(['%s'] * len(cols))})",
                   [new_id] + [data.get(f) for f in self.fields] + [user_id])
        return new_id

    def update(self, id_, data):
        sets = ", ".join(f"{f} = %s" for f in self.fields)
        db.execute(f"UPDATE {self.table} SET {sets} WHERE {self.pk} = %s",
                   [data.get(f) for f in self.fields] + [id_])

    def delete(self, id_):
        db.execute(f"DELETE FROM {self.table} WHERE {self.pk} = %s", (id_,))
