from app.models.lookup import Lookup
authors = Lookup("authors", "author_id", "A", ["author_name", "description"], "Author", "Authors")
