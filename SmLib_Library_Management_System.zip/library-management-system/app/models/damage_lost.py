"""D9 damage_lost."""
from app import db

STATUS = "CASE WHEN d.amount = 0 AND d.paid_status = 'Unpaid' THEN 'No charge' ELSE d.paid_status END"
SEL = ("SELECT d.*, " + STATUS + " AS status, b.title, m.member_name, ln.issue_date AS loan_date "
       "FROM damage_lost d JOIN books b ON b.book_id = d.book_id "
       "LEFT JOIN members m ON m.member_id = d.member_id LEFT JOIN loans ln ON ln.loan_id = d.loan_id")


def get(damage_id):
    return db.one(SEL + " WHERE d.damage_id = %s", (damage_id,))


def detail(damage_id):
    """Record + book + (optional) loan and member details for the payment screen."""
    return db.one("SELECT d.*, " + STATUS + " AS status, b.title, b.isbn, b.shelf_location, "
                  "ln.issue_date, ln.due_date, ln.return_date, ln.status AS loan_status, "
                  "m.member_name, m.id_no, m.member_type, m.email, m.phone, m.address, m.status AS member_status "
                  "FROM damage_lost d JOIN books b ON b.book_id = d.book_id "
                  "LEFT JOIN loans ln ON ln.loan_id = d.loan_id LEFT JOIN members m ON m.member_id = d.member_id "
                  "WHERE d.damage_id = %s", (damage_id,))


def search(status=None, damage_type=None, q=None, member_id=None):
    sql, args, where = SEL, [], []
    if status:
        where.append(STATUS + " = %s")
        args.append(status)
    if damage_type:
        where.append("d.damage_type = %s")
        args.append(damage_type)
    if member_id:
        where.append("d.member_id = %s")
        args.append(member_id)
    if q:
        where.append("(b.title LIKE %s OR d.damage_id LIKE %s OR m.member_name LIKE %s)")
        args += [f"%{q}%"] * 3
    if where:
        sql += " WHERE " + " AND ".join(where)
    return db.query(sql + " ORDER BY LENGTH(d.damage_id), d.damage_id LIMIT 5000", args)


def create(damage_id, book_id, loan_id, member_id, amount, damage_type, today, remark, user_id):
    db.execute("INSERT INTO damage_lost (damage_id, book_id, loan_id, member_id, amount, waived_amount, "
               "paid_status, waiver_type, record_date, paid_date, damage_type, payment_method, remark, created_by) "
               "VALUES (%s,%s,%s,%s,%s,0,'Unpaid','Not Waived',%s,%s,%s,%s,%s,%s)",
               (damage_id, book_id, loan_id, member_id, amount, today, today if not amount else None, damage_type,
                "No charge" if not amount else None, remark, user_id))


def total_unpaid(member_id=None):
    sql = "SELECT COALESCE(SUM(net_amount), 0) AS t FROM damage_lost WHERE paid_status = 'Unpaid'"
    args = ()
    if member_id:
        sql += " AND member_id = %s"
        args = (member_id,)
    return db.one(sql, args)["t"]


def total_paid(member_id=None):
    sql = "SELECT COALESCE(SUM(net_amount), 0) AS t FROM damage_lost WHERE paid_status = 'Paid'"
    args = ()
    if member_id:
        sql += " AND member_id = %s"
        args = (member_id,)
    return db.one(sql, args)["t"]
