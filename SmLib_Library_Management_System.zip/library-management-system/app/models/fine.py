"""D8 fines."""
from app import db

STATUS = "f.paid_status"
SEL = ("SELECT f.*, " + STATUS + " AS status, l.member_id, l.book_id, l.due_date, l.return_date, m.member_name, b.title "
       "FROM fines f JOIN loans l ON l.loan_id = f.loan_id JOIN members m ON m.member_id = l.member_id "
       "JOIN books b ON b.book_id = l.book_id")


def get(fine_id):
    return db.one(SEL + " WHERE f.fine_id = %s", (fine_id,))


def detail(fine_id):
    """Fine + loan + full member + book details for the payment screen."""
    return db.one("SELECT f.*, f.paid_status AS status, l.member_id, l.book_id, l.issue_date, l.due_date, l.return_date, "
                  "m.member_name, m.id_no, m.member_type, m.email, m.phone, m.address, m.status AS member_status, "
                  "b.title, b.isbn, b.shelf_location "
                  "FROM fines f JOIN loans l ON l.loan_id = f.loan_id JOIN members m ON m.member_id = l.member_id "
                  "JOIN books b ON b.book_id = l.book_id WHERE f.fine_id = %s", (fine_id,))


def by_loan(loan_id):
    return db.one("SELECT f.*, " + STATUS + " AS status FROM fines f WHERE f.loan_id = %s", (loan_id,))


def search(status=None, q=None, member_id=None):
    sql, args, where = SEL, [], []
    if status:
        where.append(STATUS + " = %s")
        args.append(status)
    if member_id:
        where.append("l.member_id = %s")
        args.append(member_id)
    if q:
        where.append("(m.member_name LIKE %s OR b.title LIKE %s OR f.fine_id LIKE %s OR l.member_id LIKE %s)")
        args += [f"%{q}%"] * 4
    if where:
        sql += " WHERE " + " AND ".join(where)
    return db.query(sql + " ORDER BY LENGTH(f.fine_id), f.fine_id LIMIT 5000", args)


def create(fine_id, loan_id, amount, today, user_id, remark=None):
    db.execute("INSERT INTO fines (fine_id, loan_id, fine_amount, waived_amount, paid_status, waiver_type, "
               "fine_date, remark, created_by) VALUES (%s,%s,%s,0,'Unpaid','Not Waived',%s,%s,%s)",
               (fine_id, loan_id, amount, today, remark, user_id))


def reprice(fine_id, amount):
    """Only used while the fine is Unpaid and nothing has been waived."""
    db.execute("UPDATE fines SET fine_amount=%s WHERE fine_id=%s AND paid_status='Unpaid' "
               "AND waiver_type='Not Waived'", (amount, fine_id))


def total_unpaid(member_id=None):
    sql = ("SELECT COALESCE(SUM(f.net_amount), 0) AS t FROM fines f JOIN loans l ON l.loan_id = f.loan_id "
           "WHERE f.paid_status = 'Unpaid' ")
    args = ()
    if member_id:
        sql += " AND l.member_id = %s"
        args = (member_id,)
    return db.one(sql, args)["t"]


def total_paid(member_id=None):
    sql = ("SELECT COALESCE(SUM(f.net_amount), 0) AS t FROM fines f JOIN loans l ON l.loan_id = f.loan_id "
           "WHERE f.paid_status = 'Paid'")
    args = ()
    if member_id:
        sql += " AND l.member_id = %s"
        args = (member_id,)
    return db.one(sql, args)["t"]
