"""D10 reservations."""
from app import db

SEL = ("SELECT r.*, m.member_name, m.member_type, b.title, b.shelf_location FROM reservations r "
       "JOIN members m ON m.member_id = r.member_id JOIN books b ON b.book_id = r.book_id")


def get(reservation_id):
    return db.one(SEL + " WHERE r.reservation_id = %s", (reservation_id,))


def search(status=None, member_id=None, q=None):
    sql, args, where = SEL, [], []
    if status == "Active":
        where.append("(r.status = 'Pending' OR (r.status = 'Ready' AND r.expiry_date >= CURRENT_DATE))")
    elif status:
        where.append("r.status = %s")
        args.append(status)
    if member_id:
        where.append("r.member_id = %s")
        args.append(member_id)
    if q:
        where.append("(m.member_name LIKE %s OR b.title LIKE %s OR r.reservation_id LIKE %s)")
        args += [f"%{q}%"] * 3
    if where:
        sql += " WHERE " + " AND ".join(where)
    return db.query(sql + " ORDER BY LENGTH(r.reservation_id), r.reservation_id LIMIT 5000", args)


def active_for(member_id, book_id):
    return db.one("SELECT * FROM reservations WHERE member_id = %s AND book_id = %s "
                  "AND status IN ('Pending', 'Ready')", (member_id, book_id))


def create(reservation_id, member_id, book_id):
    db.execute("INSERT INTO reservations (reservation_id, member_id, book_id, status) "
               "VALUES (%s,%s,%s,'Pending')", (reservation_id, member_id, book_id))


def set_status(reservation_id, status, expiry_date=None, loan_id=None):
    db.execute("UPDATE reservations SET status=%s, expiry_date=%s, loan_id=COALESCE(%s, loan_id) "
               "WHERE reservation_id=%s", (status, expiry_date, loan_id, reservation_id))


def queue(book_id):
    """Pending reservations for a book, oldest first."""
    return db.query("SELECT * FROM reservations WHERE book_id = %s AND status = 'Pending' "
                    "ORDER BY reservation_date, reservation_id", (book_id,))


def expired_ready(today):
    return db.query("SELECT * FROM reservations WHERE status = 'Ready' AND expiry_date < %s", (today,))
