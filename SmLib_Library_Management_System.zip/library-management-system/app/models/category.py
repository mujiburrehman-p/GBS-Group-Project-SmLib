from app.models.lookup import Lookup
categories = Lookup("categories", "category_id", "C", ["category_name", "description"], "Category", "Categories")
