"""D2 members."""
from datetime import date

from app import db

FIELDS = ["id_no", "member_name", "email", "phone", "address", "member_type", "expiry_date"]


def get(member_id):
    return db.one("SELECT m.*, u.user_id, u.username, u.user_role FROM members m "
                  "LEFT JOIN users u ON u.member_id = m.member_id WHERE m.member_id = %s", (member_id,))


def search(q=None, types=("Student", "Staff"), status=None):
    sql = ("SELECT m.*, u.username, "
           "(SELECT COUNT(*) FROM loans l WHERE l.member_id = m.member_id AND l.status = 'Issued') AS active_loans "
           "FROM members m LEFT JOIN users u ON u.member_id = m.member_id "
           f"WHERE m.member_type IN ({', '.join(['%s'] * len(types))})")
    args = list(types)
    if q:
        sql += " AND (m.member_name LIKE %s OR m.id_no LIKE %s OR m.email LIKE %s OR m.member_id LIKE %s)"
        args += [f"%{q}%"] * 4
    if status:
        sql += " AND m.status = %s"
        args.append(status)
    return db.query(sql + " ORDER BY LENGTH(m.member_id), m.member_id", args)


def create(member_id, d):
    db.execute("INSERT INTO members (member_id, id_no, member_name, email, phone, address, member_type, "
               "status, joined_date, expiry_date) VALUES (%s,%s,%s,%s,%s,%s,%s,'Active',CURRENT_DATE,%s)",
               (member_id, d["id_no"], d["member_name"], d["email"], d["phone"], d["address"],
                d["member_type"], d.get("expiry_date")))


def update(member_id, d):
    db.execute("UPDATE members SET id_no=%s, member_name=%s, email=%s, phone=%s, address=%s, "
               "member_type=%s, expiry_date=%s WHERE member_id=%s",
               (d["id_no"], d["member_name"], d["email"], d["phone"], d["address"],
                d["member_type"], d.get("expiry_date"), member_id))


def update_contact(member_id, member_name, email, phone, address):
    db.execute("UPDATE members SET member_name=%s, email=%s, phone=%s, address=%s WHERE member_id=%s",
               (member_name, email, phone, address, member_id))


def set_status(member_id, status):
    """Deactivating stamps expiry_date with today's date; activating clears it (NULL)."""
    if status == "Inactive":
        db.execute("UPDATE members SET status = %s, expiry_date = %s WHERE member_id = %s", (status, date.today(), member_id))
    else:
        db.execute("UPDATE members SET status = %s, expiry_date = NULL WHERE member_id = %s", (status, member_id))


def options():
    return db.query("SELECT member_id, member_name, member_type FROM members "
                    "WHERE status = 'Active' ORDER BY LENGTH(member_id), member_id")
