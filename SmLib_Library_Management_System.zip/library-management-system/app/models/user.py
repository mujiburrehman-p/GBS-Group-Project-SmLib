"""D1 users."""
from app import db

SEL = ("SELECT u.*, COALESCE(m.member_name, u.full_name) AS member_name, m.status AS member_status FROM users u "
       "LEFT JOIN members m ON m.member_id = u.member_id")


def by_username(username):
    return db.one(SEL + " WHERE u.username = %s", (username,))


def by_id(user_id):
    return db.one(SEL + " WHERE u.user_id = %s", (user_id,))


def by_member(member_id):
    return db.one(SEL + " WHERE u.member_id = %s", (member_id,))


def create(user_id, username, password_hash, role, member_id):
    db.execute("INSERT INTO users (user_id, username, password_hash, user_role, status, member_id) "
               "VALUES (%s, %s, %s, %s, 'Active', %s)", (user_id, username, password_hash, role, member_id))


def set_status(user_id, status):
    db.execute("UPDATE users SET status = %s WHERE user_id = %s", (status, user_id))


def set_password(user_id, password_hash):
    db.execute("UPDATE users SET password_hash = %s WHERE user_id = %s", (password_hash, user_id))


def set_username(user_id, username):
    db.execute("UPDATE users SET username = %s WHERE user_id = %s", (username, user_id))


def librarians(q=None, status=None):
    sql = ("SELECT m.*, u.user_id, u.username, u.status AS user_status FROM members m "
           "JOIN users u ON u.member_id = m.member_id WHERE u.user_role = 'Librarian'")
    args = []
    if q:
        sql += (" AND (m.member_name LIKE %s OR m.id_no LIKE %s OR m.email LIKE %s "
                "OR m.member_id LIKE %s OR u.username LIKE %s)")
        args += [f"%{q}%"] * 5
    if status:
        sql += " AND m.status = %s"
        args.append(status)
    return db.query(sql + " ORDER BY LENGTH(m.member_id), m.member_id", args)
