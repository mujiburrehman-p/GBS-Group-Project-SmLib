from app.models.lookup import Lookup
publishers = Lookup("publishers", "publisher_id", "P",
                    ["publisher_name", "address", "email", "phone"], "Publisher", "Publishers")
