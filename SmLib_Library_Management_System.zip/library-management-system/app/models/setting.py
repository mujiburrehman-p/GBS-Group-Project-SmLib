"""D11 system_settings."""
from decimal import Decimal
from app import db


def all_settings():
    return db.query("SELECT * FROM system_settings ORDER BY setting_id")


def as_map():
    return {r["setting_key"]: r["setting_value"] for r in all_settings()}


def get_int(key, default):
    r = db.one("SELECT setting_value FROM system_settings WHERE setting_key = %s", (key,))
    try:
        return int(r["setting_value"])
    except (TypeError, ValueError, KeyError):
        return default


def get_money(key, default):
    r = db.one("SELECT setting_value FROM system_settings WHERE setting_key = %s", (key,))
    try:
        return Decimal(r["setting_value"])
    except (TypeError, ArithmeticError, KeyError):
        return Decimal(str(default))


def create(setting_id, key, value, description, user_id):
    db.execute("INSERT INTO system_settings (setting_id, setting_key, setting_value, description, updated_by) "
               "VALUES (%s, %s, %s, %s, %s)", (setting_id, key, value, description, user_id))


def update(setting_id, value, user_id):
    db.execute("UPDATE system_settings SET setting_value = %s, updated_by = %s WHERE setting_id = %s",
               (value, user_id, setting_id))
