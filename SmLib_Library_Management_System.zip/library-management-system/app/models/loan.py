"""D7 loans."""
from app import db

SEL = ("SELECT l.*, m.member_name, m.member_type, b.title, b.shelf_location, "
       "COALESCE(ui.member_id, ui.user_role) AS issued_by_name, ur.username AS returned_to_name "
       "FROM loans l JOIN members m ON m.member_id = l.member_id JOIN books b ON b.book_id = l.book_id "
       "JOIN users ui ON ui.user_id = l.issued_by LEFT JOIN users ur ON ur.user_id = l.returned_to")


def get(loan_id):
    return db.one(SEL + " WHERE l.loan_id = %s", (loan_id,))


def lock(loan_id):
    return db.one("SELECT * FROM loans WHERE loan_id = %s FOR UPDATE", (loan_id,))


def search(status=None, q=None, member_id=None, book_id=None, today=None, exclude_librarians=False):
    sql, args, where = SEL, [], []
    if status == "Overdue":
        where.append("l.status = 'Issued' AND l.due_date < %s")
        args.append(today)
    elif status == "OnLoan":            # issued and not yet overdue
        where.append("l.status = 'Issued' AND l.due_date >= %s")
        args.append(today)
    elif status:
        where.append("l.status = %s")
        args.append(status)
    if member_id:
        where.append("l.member_id = %s")
        args.append(member_id)
    if book_id:
        where.append("l.book_id = %s")
        args.append(book_id)
    if exclude_librarians:
        where.append("m.member_type <> 'Librarian'")
    if q:
        where.append("(m.member_name LIKE %s OR b.title LIKE %s OR l.loan_id LIKE %s OR l.member_id LIKE %s)")
        args += [f"%{q}%"] * 4
    if where:
        sql += " WHERE " + " AND ".join(where)
    return db.query(sql + " ORDER BY LENGTH(l.loan_id), l.loan_id LIMIT 5000", args)


def count_active(member_id):
    return db.one("SELECT COUNT(*) AS n FROM loans WHERE member_id = %s AND status = 'Issued'",
                  (member_id,))["n"]


def has_active(member_id, book_id):
    return db.one("SELECT 1 AS x FROM loans WHERE member_id = %s AND book_id = %s AND status = 'Issued'",
                  (member_id, book_id)) is not None


def create(loan_id, member_id, book_id, issue_date, due_date, issued_by):
    db.execute("INSERT INTO loans (loan_id, member_id, book_id, issue_date, due_date, status, renewal_count, "
               "issued_by) VALUES (%s,%s,%s,%s,%s,'Issued',0,%s)",
               (loan_id, member_id, book_id, issue_date, due_date, issued_by))


def mark_returned(loan_id, return_date, user_id):
    db.execute("UPDATE loans SET status='Returned', return_date=%s, returned_to=%s WHERE loan_id=%s",
               (return_date, user_id, loan_id))


def mark_lost(loan_id, lost_date):
    """Loan becomes Lost; return_date holds the date it was recorded as lost (the loan is closed on that date)."""
    db.execute("UPDATE loans SET status='Lost', return_date=%s WHERE loan_id=%s", (lost_date, loan_id))


def renew(loan_id, new_due, today):
    db.execute("UPDATE loans SET due_date=%s, renewal_count=renewal_count+1, last_renewed_on=%s "
               "WHERE loan_id=%s", (new_due, today, loan_id))


def overdue_open(today):
    return db.query("SELECT * FROM loans WHERE status = 'Issued' AND due_date < %s", (today,))
