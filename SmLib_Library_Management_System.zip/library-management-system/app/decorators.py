"""Access control: @login_required and @role_required('Admin', 'Librarian')."""
from functools import wraps
from flask import g, redirect, url_for, flash, request, abort

STAFF = ("Admin", "Librarian")


def login_required(view):
    @wraps(view)
    def wrapped(*a, **kw):
        if g.user is None:
            flash("Please log in to continue.", "warning")
            return redirect(url_for("auth.login", next=request.path))
        return view(*a, **kw)
    return wrapped


def role_required(*roles):
    def deco(view):
        @wraps(view)
        @login_required
        def wrapped(*a, **kw):
            if g.user["role"] not in roles:
                abort(403)
            return view(*a, **kw)
        return wrapped
    return deco


def member_required(view):
    """Pages for people who borrow (need a members row): Member and Librarian accounts."""
    @wraps(view)
    @login_required
    def wrapped(*a, **kw):
        if not g.user["member_id"]:
            abort(403)
        return view(*a, **kw)
    return wrapped
