"""Reservation rules: queueing, holding a copy (Ready), expiry."""
from datetime import date, timedelta

from app import db
from app.models import book as book_model, reservation as res_model, setting, member as member_model, loan as loan_model
from app.services.id_generator import next_id
from app.utils import BusinessError, to_date


def check_member_active(member, today=None):
    today = today or date.today()
    if not member:
        raise BusinessError("Member not found.")
    if member["status"] != "Active":
        raise BusinessError(f"{member['member_name']}'s membership is inactive.")
    exp = to_date(member["expiry_date"])
    if exp and exp < today:
        raise BusinessError(f"{member['member_name']}'s membership expired on {exp:%d %b %Y}.")


def promote(book_id, today=None):
    """Give free copies to the oldest Pending reservations; they become Ready and are held."""
    today = today or date.today()
    book = book_model.get(book_id)
    if not book:
        return
    free = book_model.issuable(book)
    hold = setting.get_int("reservation_hold_days", 3)
    for r in res_model.queue(book_id):
        if free <= 0:
            break
        res_model.set_status(r["reservation_id"], "Ready", today + timedelta(days=hold))
        free -= 1


def expire_old(today=None):
    """Ready reservations past their expiry date become Expired and the next person is promoted."""
    today = today or date.today()
    rows = res_model.expired_ready(today)
    for r in rows:
        res_model.set_status(r["reservation_id"], "Expired")
        promote(r["book_id"], today)
    db.commit()
    return len(rows)


def reserve(member_id, book_id):
    member = member_model.get(member_id)
    check_member_active(member)
    book = book_model.get(book_id)
    if not book:
        raise BusinessError("Book not found.")
    if loan_model.has_active(member_id, book_id):
        raise BusinessError("You already have this book on loan.")
    if res_model.active_for(member_id, book_id):
        raise BusinessError("You already have an active reservation for this book.")
    rid = next_id("reservations", "reservation_id", "R")
    res_model.create(rid, member_id, book_id)
    promote(book_id)
    db.commit()
    return res_model.get(rid)


def cancel(reservation_id, member_id=None):
    r = res_model.get(reservation_id)
    if not r or (member_id and r["member_id"] != member_id):
        raise BusinessError("Reservation not found.")
    if r["status"] not in ("Pending", "Ready"):
        raise BusinessError("Only Pending or Ready reservations can be cancelled.")
    res_model.set_status(reservation_id, "Cancelled")
    promote(r["book_id"])
    db.commit()
