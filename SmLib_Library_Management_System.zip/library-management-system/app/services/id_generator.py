"""Readable primary-key codes: U001, M001, B001, L001, DL001 ..."""
from app import db


def next_id(table, column, prefix, width=3):
    rows = db.query(f"SELECT {column} AS v FROM {table} WHERE {column} LIKE %s", (prefix + "%",))
    nums = [int(r["v"][len(prefix):]) for r in rows if r["v"][len(prefix):].isdigit()]
    return f"{prefix}{(max(nums) + 1 if nums else 1):0{width}d}"
