"""Overdue fines, payments and waivers (used for both fines and damage_lost charges)."""
from datetime import date
from decimal import Decimal

from app import db
from app.models import fine as fine_model, loan as loan_model, setting
from app.services.id_generator import next_id
from app.utils import BusinessError, money, to_date

# table -> (primary key column, amount column)
TABLES = {"fines": ("fine_id", "fine_amount"), "damage_lost": ("damage_id", "amount")}


def fine_for_days(days):
    return (Decimal(days) * setting.get_money("fine_per_day", "0.50")).quantize(Decimal("0.01"))


def upsert_fine(loan_id, days, user_id, today=None, remark=None):
    """One overdue fine per loan: create it, or re-price it while it is still Unpaid."""
    today = today or date.today()
    amount = fine_for_days(days)
    existing = fine_model.by_loan(loan_id)
    if existing:
        fine_model.reprice(existing["fine_id"], amount)
        return existing["fine_id"]
    fine_id = next_id("fines", "fine_id", "F")
    fine_model.create(fine_id, loan_id, amount, today, user_id, remark)
    return fine_id


def sync_overdue(user_id, today=None):
    """Create/update fines for loans that are overdue right now and not yet returned."""
    today = today or date.today()
    n = 0
    for loan in loan_model.overdue_open(today):
        days = (today - to_date(loan["due_date"])).days
        if days > 0:
            upsert_fine(loan["loan_id"], days, user_id, today, "Overdue fine (calculated automatically)")
            n += 1
    db.commit()
    return n


def _load(kind, record_id):
    pk, amt = TABLES[kind]
    r = db.one(f"SELECT * FROM {kind} WHERE {pk} = %s", (record_id,))
    if not r:
        raise BusinessError("Record not found.")
    if r["paid_status"] != "Unpaid":
        raise BusinessError("Only Unpaid items can be paid or waived.")
    return pk, amt, r


def pay(kind, record_id, method, today=None):
    if method not in ("Cash", "Card"):
        raise BusinessError("Choose a payment method (Cash or Card).")
    pk, amt, r = _load(kind, record_id)
    db.execute(f"UPDATE {kind} SET paid_status='Paid', paid_date=%s, payment_method=%s WHERE {pk}=%s",
               (today or date.today(), method, record_id))
    db.commit()


def waive(kind, record_id, amount=None, full=False):
    """Waive part (Partially Waived, still Unpaid) or all (Fully Waived, status Waived, method No charge)."""
    pk, amt, r = _load(kind, record_id)
    total = Decimal(str(r[amt]))
    w = total if full else money(amount)
    if w <= 0 or w > total:
        raise BusinessError(f"The waived amount must be between 0.01 and {total}.")
    full_waiver = w == total
    db.execute(f"UPDATE {kind} SET waived_amount=%s, waiver_type=%s, paid_status=%s, payment_method=%s, paid_date=%s "
               f"WHERE {pk}=%s",
               (w, "Fully Waived" if full_waiver else "Partially Waived", "Waived" if full_waiver else "Unpaid",
                "No charge" if full_waiver else None, date.today() if full_waiver else None, record_id))
    db.commit()


PAID_STATUSES = ("Unpaid", "Paid", "Waived")


def waiver_type_for(amount, waived):
    """Waiver type follows from the waived amount (the screen shows it, it is not typed in)."""
    return "Not Waived" if waived == 0 else ("Fully Waived" if waived == amount else "Partially Waived")


def settle(fine_id, form, today=None):
    """Fine Payment screen (after an overdue return or from Manage Fines)."""
    return _settle("fines", fine_id, form, today)


def settle_charge(damage_id, form, today=None):
    """Damaged / Scrapped / Lost Payment screen."""
    return _settle("damage_lost", damage_id, form, today)


def _settle(kind, record_id, form, today=None, commit=True):
    """Save waived_amount, waiver_type, payment_method (Payment Status is derived) and remark.
    The amount is display only. Every rule of the table is checked here with a clear message."""
    today = today or date.today()
    pk, amt = TABLES[kind]
    word = "fine" if kind == "fines" else "charge"
    r = db.one(f"SELECT * FROM {kind} WHERE {pk} = %s", (record_id,))
    if not r:
        raise BusinessError("Record not found.")
    if r["paid_status"] != "Unpaid":
        raise BusinessError(f"This {word} is already settled. Only an Unpaid {word} can be changed.")
    amount, waived = money(r[amt]), money(form.get("waived_amount") or 0)
    method = (form.get("payment_method") or "").strip() or None
    remark = (form.get("remark") or "").strip() or None
    if amount <= 0:
        raise BusinessError(f"This {word} has no amount to pay.")
    if waived < 0:
        raise BusinessError("Amounts cannot be negative.")
    if waived > amount:
        raise BusinessError(f"The waived amount cannot be more than the {word} amount.")
    # Payment Status is display only: it follows from the waived amount and the payment method
    if waived == amount:
        status, method = "Waived", "No charge"
    elif method in ("Cash", "Card"):
        status = "Paid"
    elif method == "No charge":
        raise BusinessError(f"'No charge' is only for a fully waived {word} (waived amount = {word} amount).")
    else:
        raise BusinessError("Payment method is mandatory - choose Cash or Card to confirm the payment (or use Pay Later).")
    db.execute(f"UPDATE {kind} SET waived_amount=%s, waiver_type=%s, paid_status=%s, payment_method=%s, "
               f"paid_date=%s, remark=%s WHERE {pk}=%s",
               (waived, waiver_type_for(amount, waived), status, method,
                today if status in ("Paid", "Waived") else None, remark, record_id))
    if commit:
        db.commit()
    return status


def settle_fine_and_lost(fine_id, damage_id, form, today=None):
    """Fine & Lost Payment screen: the overdue fine and the lost charge of one loan are saved together.
    One payment method is used for whichever of the two still has an amount to pay; both are validated and
    saved in one transaction (nothing is saved when either side is refused)."""
    fine = db.one("SELECT loan_id FROM fines WHERE fine_id = %s", (fine_id,))
    lost = db.one("SELECT loan_id FROM damage_lost WHERE damage_id = %s", (damage_id,))
    if not fine or not lost or fine["loan_id"] != lost["loan_id"]:
        raise BusinessError("The fine and the lost charge do not belong to the same loan.")
    method = form.get("payment_method")
    try:
        a = _settle("fines", fine_id, {"waived_amount": form.get("fine_waived_amount"), "payment_method": method,
                                       "remark": form.get("fine_remark")}, today, commit=False)
        b = _settle("damage_lost", damage_id, {"waived_amount": form.get("lost_waived_amount"), "payment_method": method,
                                               "remark": form.get("lost_remark")}, today, commit=False)
    except BusinessError:
        db.rollback()
        raise
    db.commit()
    return a, b
