"""Damaged / Scrapped / Lost copies and their effect on loans and book counts."""
from datetime import date

from app import db
from app.models import book as book_model, loan as loan_model, damage_lost as dl_model
from app.services import fine_service, loan_service
from app.services.id_generator import next_id
from app.utils import BusinessError, money, to_date


def record(user, book_id, damage_type, loan_id, amount, remark):
    today = date.today()
    if damage_type not in ("Damaged", "Scrapped", "Lost"):
        raise BusinessError("Choose Damaged, Scrapped or Lost.")
    if not book_model.lock(book_id):
        raise BusinessError("Book not found.")
    book = book_model.get(book_id)

    if damage_type == "Scrapped" and (loan_id or money(amount or 0) != 0):
        raise BusinessError("A scrapped copy is taken from the shelf: it cannot be linked to a loan or charged to a member.")

    member_id, loan = None, None
    if loan_id:
        loan = loan_model.lock(loan_id)
        if not loan or loan["book_id"] != book_id:
            raise BusinessError("That loan does not belong to the selected book.")
        if loan["status"] != "Issued":
            raise BusinessError("Only a book that is currently on loan can be linked to a member charge.")
        member_id = loan["member_id"]
        loan_service.ensure_can_handle(user, member_id, "record a damaged, scrapped or lost book")

    amount = money(amount or 0)
    if amount < 0:
        raise BusinessError("The amount cannot be negative.")
    if amount > 0 and not member_id:
        raise BusinessError("To charge an amount, select the loan the book was borrowed on.")

    # Every record moves one copy out of circulation into its own counter:
    #   Damaged -> damaged_copies + 1,  Lost -> lost_copies + 1,  Scrapped -> scrapped_copies + 1
    if loan:
        d_avail = 0                                      # the copy was on loan, it does not come from the shelf
    else:
        if book["available_copies"] < 1:
            raise BusinessError(f"There is no available copy on the shelf to mark as {damage_type.lower()}.")
        d_avail = -1                                     # a copy is taken from the shelf
    counters = {"damaged": 0, "lost": 0, "scrapped": 0}
    counters[damage_type.lower()] = 1
    # Rule decided here, before anything is saved (the database CHECK chk_books_counts is the final guard):
    #   books.total_copies >= available + damaged + lost + scrapped
    in_circulation = (book["available_copies"] + d_avail + book["damaged_copies"] + counters["damaged"]
                      + book["lost_copies"] + counters["lost"] + book["scrapped_copies"] + counters["scrapped"])
    if book["total_copies"] < in_circulation:
        raise BusinessError(f"Not saved: total copies ({book['total_copies']}) must be at least available + damaged + "
                            f"lost + scrapped ({in_circulation}).")
    if loan:
        if damage_type == "Lost":                        # lost while on loan
            loan_model.mark_lost(loan_id, today)
        else:                                            # Damaged / Scrapped: the copy comes back unusable
            loan_model.mark_returned(loan_id, today, user["user_id"])
        days = (today - to_date(loan["due_date"])).days
        if days > 0:                                     # overdue until today: overdue fine is created as well
            fine_service.upsert_fine(loan_id, days, user["user_id"], today, f"Overdue before {damage_type.lower()}")
    book_model.adjust(book_id, available=d_avail, **counters)

    damage_id = next_id("damage_lost", "damage_id", "DL")
    dl_model.create(damage_id, book_id, loan_id, member_id, amount, damage_type, today,
                    remark, user["user_id"])
    db.commit()
    return damage_id
