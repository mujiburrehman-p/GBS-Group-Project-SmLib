"""Lending rules: issue, return, renew."""
from datetime import date, timedelta

from app import db
from app.models import book as book_model, loan as loan_model, member as member_model, setting
from app.models import reservation as res_model
from app.services import fine_service, reservation_service
from app.services.id_generator import next_id
from app.utils import BusinessError, to_date


def ensure_can_handle(user, member_id, action):
    """Admin may handle loans of every member. A Librarian may handle loans of Staff and Student members only;
    anything for a Librarian member (return, renew, lost, damaged) is done by the Admin."""
    if user["role"] == "Admin":
        return
    borrower = member_model.get(member_id)
    if borrower and borrower["member_type"] == "Librarian":
        raise BusinessError(f"Only an Admin can {action} for a Librarian.")


def issue(book_id, member_id, issuer):
    today = date.today()
    member = member_model.get(member_id)
    reservation_service.check_member_active(member, today)
    if member["member_type"] == "Librarian" and issuer["role"] != "Admin":
        raise BusinessError("Only an Admin can issue books to a Librarian.")

    if not book_model.lock(book_id):
        raise BusinessError("Book not found.")
    book = book_model.get(book_id)

    limit = setting.get_int("max_books_per_member", 3)
    if loan_model.count_active(member_id) >= limit:
        raise BusinessError(f"{member['member_name']} already has the maximum of {limit} books on loan.")
    if loan_model.has_active(member_id, book_id):
        raise BusinessError("This member already has this book on loan.")

    res = res_model.active_for(member_id, book_id)
    free = book_model.issuable(book) + (1 if res and res["status"] == "Ready" else 0)
    if free <= 0:
        raise BusinessError("No copy is available to issue (copies may be on loan or held for reservations).")

    loan_id = next_id("loans", "loan_id", "L")
    due = today + timedelta(days=setting.get_int("loan_days", 14))
    loan_model.create(loan_id, member_id, book_id, today, due, issuer["user_id"])
    book_model.adjust(book_id, available=-1)
    if res:
        res_model.set_status(res["reservation_id"], "Fulfilled", None, loan_id)
    db.commit()
    return loan_id, due


def return_loan(loan_id, user):
    """Process a return. Admin: any loan. Librarian: loans of Staff and Student members only
    (a return for a Librarian is processed by the Admin)."""
    user_id = user["user_id"]
    today = date.today()
    loan = loan_model.lock(loan_id)
    if not loan:
        raise BusinessError("Loan not found.")
    if loan["status"] != "Issued":
        raise BusinessError("This loan is not currently issued.")
    ensure_can_handle(user, loan["member_id"], "process a book return")
    book_model.lock(loan["book_id"])
    loan_model.mark_returned(loan_id, today, user_id)
    book_model.adjust(loan["book_id"], available=1)

    days = (today - to_date(loan["due_date"])).days
    fine_id = None
    if days > 0:
        fine_id = fine_service.upsert_fine(loan_id, days, user_id, today, f"Returned {days} day(s) late")
    reservation_service.promote(loan["book_id"], today)
    db.commit()
    return max(days, 0), fine_id


def renew(loan_id, user):
    today = date.today()
    loan = loan_model.lock(loan_id)
    if not loan or loan["status"] != "Issued":
        raise BusinessError("Only a loan that is currently issued can be renewed.")
    ensure_can_handle(user, loan["member_id"], "renew a loan")
    due = to_date(loan["due_date"])
    if due < today:
        raise BusinessError("An overdue loan cannot be renewed. Return the book first.")
    wait = setting.get_int("renewal_after_days", 10)
    opens = to_date(loan["issue_date"]) + timedelta(days=wait)
    if today < opens:
        raise BusinessError(f"A book can be renewed only after {wait} days from the issue date. "
                            f"Loan {loan_id} can be renewed from {opens.strftime('%d %b %Y')}.")
    limit = setting.get_int("max_renewals", 1)
    if loan["renewal_count"] >= limit:
        raise BusinessError(f"This loan has already been renewed the maximum of {limit} time(s).")
    waiting = db.one("SELECT COUNT(*) AS n FROM reservations WHERE book_id = %s AND member_id <> %s "
                     "AND status IN ('Pending', 'Ready')", (loan["book_id"], loan["member_id"]))["n"]
    if waiting:
        raise BusinessError("Another member has reserved this book, so it cannot be renewed.")
    new_due = due + timedelta(days=setting.get_int("loan_days", 14))
    loan_model.renew(loan_id, new_due, today)
    db.commit()
    return new_due
