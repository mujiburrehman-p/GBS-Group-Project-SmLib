// Mobile sidebar
document.addEventListener('click', e => {
  if (e.target.closest('#menuBtn')) document.getElementById('sidebar').classList.toggle('open');
  if (e.target.closest('.flash button')) { const f = e.target.closest('.flash'); if (f.id === 'regError') f.hidden = true; else f.remove(); }
});
// Record IDs (M001, B001, L001, F001, DL001, R001, U001, C001, A001, P001, ST01) are shown BOLD and RED
// in confirmation boxes and in confirmation messages.
const ID_RE = /\b(DL\d{3}|ST\d{2}|[MBLFRUCAP]\d{3})\b/g;
function showWithIds(el, msg) {
  el.textContent = '';
  let last = 0, m;
  ID_RE.lastIndex = 0;
  while ((m = ID_RE.exec(msg)) !== null) {
    el.appendChild(document.createTextNode(msg.slice(last, m.index)));
    const b = document.createElement('strong'); b.className = 'idref'; b.textContent = m[0];
    el.appendChild(b);
    last = m.index + m[0].length;
  }
  el.appendChild(document.createTextNode(msg.slice(last)));
}
document.querySelectorAll('.flash > span').forEach(sp => { if (sp.textContent.trim()) showWithIds(sp, sp.textContent); });
// All record IDs shown in tables, detail boxes and cards are BOLD (text nodes only; inputs and the red confirmation IDs are left alone)
(function () {
  const skip = 'script,style,input,select,option,textarea,button,b,strong,.idref';
  const walker = document.createTreeWalker(document.querySelector('main') || document.body, NodeFilter.SHOW_TEXT);
  const nodes = [];
  for (let n = walker.nextNode(); n; n = walker.nextNode()) {
    const p = n.parentElement;
    if (p && !p.closest(skip) && p.closest('td,dd,.cardid,.muted') && ID_RE.test(n.nodeValue)) nodes.push(n);
    ID_RE.lastIndex = 0;
  }
  nodes.forEach(n => {
    const msg = n.nodeValue, frag = document.createDocumentFragment();
    let last = 0, m;
    ID_RE.lastIndex = 0;
    while ((m = ID_RE.exec(msg)) !== null) {
      frag.appendChild(document.createTextNode(msg.slice(last, m.index)));
      const b = document.createElement('b'); b.textContent = m[0]; frag.appendChild(b);
      last = m.index + m[0].length;
    }
    frag.appendChild(document.createTextNode(msg.slice(last)));
    n.parentNode.replaceChild(frag, n);
  });
})();
// Confirmation dialog: <form data-confirm="Are you sure?"> - same dialog style as Register (Cancel is the default)
(function () {
  const modal = document.getElementById('confirmModal');
  if (!modal) return;
  const text = document.getElementById('confirmText');
  const title = document.getElementById('confirmTitle');
  const ok = document.getElementById('confirmOk');
  const cancel = document.getElementById('confirmCancel');
  let pending = null;
  const close = () => { modal.hidden = true; pending = null; };
  document.addEventListener('submit', e => {
    const form = e.target, msg = form.dataset && form.dataset.confirm;
    if (!msg || form.dataset.confirmed === '1') return;
    e.preventDefault();
    pending = {form, submitter: e.submitter};
    showWithIds(text, msg);
    title.textContent = form.dataset.confirmTitle ? 'Confirmation (' + form.dataset.confirmTitle + ')' : 'Confirmation';
    modal.hidden = false;
    cancel.focus();
  });
  cancel.addEventListener('click', close);
  modal.addEventListener('click', e => { if (e.target === modal) close(); });
  document.addEventListener('keydown', e => { if (e.key === 'Escape' && !modal.hidden) close(); });
  ok.addEventListener('click', () => {
    if (!pending) return;
    const {form, submitter} = pending;
    form.dataset.confirmed = '1';
    close();
    form.requestSubmit(submitter || undefined);
  });
})();
// Live table filter: <input data-filter="#tableId">
document.querySelectorAll('input[data-filter]').forEach(inp => {
  inp.addEventListener('input', () => {
    const q = inp.value.toLowerCase();
    document.querySelectorAll(inp.dataset.filter + ' tbody tr').forEach(tr => {
      tr.style.display = tr.textContent.toLowerCase().includes(q) ? '' : 'none';
    });
  });
});
// Show/hide password
document.querySelectorAll('[data-toggle-password]').forEach(b => {
  b.addEventListener('click', () => {
    const f = document.querySelector(b.dataset.togglePassword);
    f.type = f.type === 'password' ? 'text' : 'password';
  });
});
// Auto-hide success messages
setTimeout(() => document.querySelectorAll('.flash.success').forEach(f => f.remove()), 6000);

// Register: confirmation dialog (Cancel is the default) -> Confirm submits the form
(function () {
  const form = document.querySelector('[data-register-confirm]');
  if (!form) return;
  const modal = document.getElementById('regModal');
  const cancel = document.getElementById('regCancel');
  const confirmBtn = document.getElementById('regConfirm');
  let confirmed = false;
  const close = () => { modal.hidden = true; };
  form.addEventListener('submit', e => {
    if (confirmed) return;
    e.preventDefault();
    if (!form.reportValidity()) return;
    const err = document.getElementById('regError');
    const pw = form.elements['password'].value, cf = form.elements['confirm'].value;
    const problem = pw.length < 8 ? 'Password must be at least 8 characters.'
                  : pw !== cf ? 'Passwords do not match.' : '';
    if (problem) {                       // stay on this screen and show the message
      err.firstElementChild.textContent = problem;
      err.hidden = false;
      err.scrollIntoView({behavior: 'smooth', block: 'center'});
      return;
    }
    err.hidden = true;
    modal.hidden = false;
    cancel.focus();                       // default button = Cancel
  });
  cancel.addEventListener('click', close);  // data stays in the form
  modal.addEventListener('click', e => { if (e.target === modal) close(); });
  document.addEventListener('keydown', e => { if (e.key === 'Escape' && !modal.hidden) close(); });
  confirmBtn.addEventListener('click', () => {
    confirmed = true;
    close();
    form.submit();
  });
})();

// Analogue clock (with seconds) and today's day/date
(function () {
  const h = document.getElementById('cl-h'), m = document.getElementById('cl-m'), sec = document.getElementById('cl-s');
  const dateEl = document.getElementById('todayDate');
  const tick = () => {
    const n = new Date();
    const s = n.getSeconds(), mi = n.getMinutes() + s / 60, hr = (n.getHours() % 12) + mi / 60;
    if (sec) {
      sec.setAttribute('transform', `rotate(${s * 6} 50 50)`);
      m.setAttribute('transform', `rotate(${mi * 6} 50 50)`);
      h.setAttribute('transform', `rotate(${hr * 30} 50 50)`);
    }
    if (dateEl) dateEl.textContent = n.toLocaleDateString('en-GB', {weekday: 'long', day: '2-digit', month: 'long', year: 'numeric'}).replace(/^(\w+) /, '$1, ');
  };
  tick(); setInterval(tick, 1000);
})();

// Prevent duplicate submissions: a form can only be sent once (double-click, impatient clicks).
document.addEventListener('submit', e => {
  const form = e.target;
  if (!form || form.tagName !== 'FORM' || (form.method || '').toLowerCase() !== 'post') return;
  if (form.dataset.sending === '1') { e.preventDefault(); return; }
  setTimeout(() => {
    if (e.defaultPrevented) return;            // cancelled (validation, confirmation dialog)
    form.dataset.sending = '1';
    form.querySelectorAll('button:not([type=button]), input[type=submit]').forEach(b => { b.disabled = true; });
  }, 0);
});

// Back / Forward: if the browser restores a page from its cache, reload it so it shows the latest data
// (a reload is a plain GET - it never repeats a form submission).
window.addEventListener('pageshow', e => {
  const nav = performance.getEntriesByType('navigation')[0];
  if (e.persisted || (nav && nav.type === 'back_forward')) {
    document.querySelectorAll('form').forEach(f => {
      delete f.dataset.sending; delete f.dataset.confirmed;
      f.querySelectorAll('button, input[type=submit]').forEach(b => { b.disabled = false; });
    });
    if (e.persisted) window.location.reload();
  }
});
// Flash messages (errors, success) disappear by themselves after 5 seconds
document.querySelectorAll('.content .flash:not(#regError)').forEach(f => {
  setTimeout(() => { f.style.transition = 'opacity .5s'; f.style.opacity = '0'; setTimeout(() => f.remove(), 500); }, 5000);
});
// System Settings: Save is enabled only when a value was changed
(function () {
  const f = document.getElementById('settingsForm'); if (!f) return;
  const btn = document.getElementById('saveSettings');
  const inputs = [...f.querySelectorAll('tbody input')];
  const orig = inputs.map(i => i.value);
  const changed = () => inputs.some((i, n) => i.value !== orig[n]);
  const sync = () => { btn.disabled = !changed(); };
  inputs.forEach(i => i.addEventListener('input', sync));
  f.addEventListener('submit', e => { if (!changed()) { e.preventDefault(); e.stopPropagation(); } });
  window.addEventListener('pageshow', sync);
})();
// Manage Profile: Save details is enabled only when a value was changed
(function () {
  const f = document.getElementById('detailsForm'); if (!f) return;
  const btn = document.getElementById('saveDetails');
  const inputs = [...f.querySelectorAll('input:not([type=hidden])')];
  const orig = inputs.map(i => i.value);
  const changed = () => inputs.some((i, n) => i.value !== orig[n]);
  const sync = () => { btn.disabled = !changed(); };
  inputs.forEach(i => i.addEventListener('input', sync));
  f.addEventListener('submit', e => { if (!changed()) { e.preventDefault(); e.stopPropagation(); } });
  window.addEventListener('pageshow', sync);
})();
// Edit screens: <form data-track-changes> - Save ([data-savebtn]) is enabled only when a value was changed
document.querySelectorAll('form[data-track-changes]').forEach(f => {
  const btn = f.querySelector('[data-savebtn]');
  const fields = [...f.querySelectorAll('input:not([type=hidden]):not([type=submit]), select, textarea')];
  const val = el => (el.type === 'checkbox' || el.type === 'radio') ? String(el.checked) : el.value;
  const orig = fields.map(val);
  const changed = () => fields.some((el, n) => val(el) !== orig[n]);
  const sync = () => { if (btn) btn.disabled = !changed(); };
  fields.forEach(el => { el.addEventListener('input', sync); el.addEventListener('change', sync); });
  f.addEventListener('submit', e => { if (!changed()) { e.preventDefault(); e.stopPropagation(); } });
  window.addEventListener('pageshow', sync);
});
// Issue Book: Issue is enabled only when Member and Book are filled; confirmation names them; Cancel clears the fields
(function () {
  const f = document.getElementById('issueForm'); if (!f) return;
  const m = f.elements.member_id, b = f.elements.book_id;
  const btn = document.getElementById('issueBtn');
  const label = (list, v) => { const o = [...document.querySelectorAll('#' + list + ' option')].find(x => x.value.toUpperCase() === v.trim().toUpperCase()); return o ? v.trim().toUpperCase() + ' - ' + o.textContent : v.trim(); };
  const sync = () => { btn.disabled = !(m.value.trim() && b.value.trim()); };
  [m, b].forEach(i => i.addEventListener('input', sync));
  f.addEventListener('submit', e => {
    if (!(m.value.trim() && b.value.trim())) { e.preventDefault(); e.stopPropagation(); return; }
    f.dataset.confirm = 'Issue book ' + label('books', b.value) + ' to ' + label('members', m.value) + '?';
  });
  document.getElementById('issueCancel').addEventListener('click', () => { m.value = ''; b.value = ''; sync(); m.focus(); });
  window.addEventListener('pageshow', sync); sync();
})();
