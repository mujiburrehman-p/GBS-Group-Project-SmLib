"""Small helpers shared by routes and services."""
from datetime import date, datetime
from decimal import Decimal, InvalidOperation


class BusinessError(Exception):
    """A rule of the library was broken; the message is shown to the user."""


def to_date(value):
    """DB drivers return date objects; this also accepts ISO strings."""
    if value is None or isinstance(value, date) and not isinstance(value, datetime):
        return value
    if isinstance(value, datetime):
        return value.date()
    return datetime.strptime(str(value)[:10], "%Y-%m-%d").date()


def clean(form, fields):
    """Pick fields from a form; strip text and turn blanks into None."""
    out = {}
    for f in fields:
        v = (form.get(f) or "").strip()
        out[f] = v if v else None
    return out


def money(value):
    try:
        return Decimal(str(value)).quantize(Decimal("0.01"))
    except (InvalidOperation, TypeError):
        raise BusinessError("Please enter a valid amount.")


def to_int(value, label, minimum=None):
    try:
        n = int(str(value).strip())
    except (ValueError, TypeError):
        raise BusinessError(f"{label} must be a whole number.")
    if minimum is not None and n < minimum:
        raise BusinessError(f"{label} must be at least {minimum}.")
    return n


def valid_password(pw, confirm=None):
    if pw is None or len(pw) < 8:
        raise BusinessError("Password must be at least 8 characters.")
    if len(pw.encode("utf-8")) > 72:
        raise BusinessError("Password must be at most 72 characters.")
    if confirm is not None and pw != confirm:
        raise BusinessError("Passwords do not match.")
