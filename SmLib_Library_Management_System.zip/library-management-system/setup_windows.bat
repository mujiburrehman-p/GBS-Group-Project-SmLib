@echo off
REM ===== SmLib FIRST-TIME SETUP (Windows). Double-click this file. =====
cd /d "%~dp0"
echo.
echo [1/5] Creating virtual environment...
if not exist venv (python -m venv venv)
if errorlevel 1 (echo Python was not found. Install Python from python.org and tick "Add Python to PATH". & pause & exit /b 1)
call venv\Scripts\activate
echo.
echo [2/5] Installing packages...
python -m pip install --quiet -r requirements.txt
if errorlevel 1 (echo Package install failed. & pause & exit /b 1)
echo.
echo [3/5] Settings file...
if not exist .env (
  copy .env.example .env >nul
  echo A file called .env was created. Notepad will open: type your MySQL root password after DB_PASSWORD= , save, and close it.
  notepad .env
)
echo.
echo [4/5] Creating the database...
python scripts\setup_database.py
if errorlevel 1 (echo Database setup failed - read the message above. & pause & exit /b 1)
echo.
echo [5/5] Starting SmLib at http://127.0.0.1:5000  (press Ctrl+C to stop)
start "" http://127.0.0.1:5000
python run.py
pause
