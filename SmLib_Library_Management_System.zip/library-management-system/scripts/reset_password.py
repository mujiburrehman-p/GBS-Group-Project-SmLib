"""Set a new password for any account (use this if you forget the admin password).

  python scripts/reset_password.py admin MyNewPassword123
"""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))

from app import create_app, db                       # noqa: E402
from app.extensions import hash_password             # noqa: E402
from app.models import user as user_model            # noqa: E402
from app.utils import valid_password, BusinessError  # noqa: E402

if len(sys.argv) != 3:
    sys.exit("Usage: python scripts/reset_password.py <username> <new_password>")
username, password = sys.argv[1], sys.argv[2]
app = create_app()
with app.app_context():
    try:
        valid_password(password)
    except BusinessError as e:
        sys.exit(str(e))
    u = user_model.by_username(username)
    if not u:
        sys.exit(f"No user named '{username}'.")
    user_model.set_password(u["user_id"], hash_password(password))
    user_model.set_status(u["user_id"], "Active")
    db.commit()
    print(f"Password for '{username}' changed and account set to Active.")
