"""Diagnose why SmLib will not run:   python scripts/check_setup.py"""
import importlib
import os
import sys

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
sys.path.insert(0, ROOT)
bad = 0


def report(ok, label, hint=""):
    global bad
    print(("[ OK ] " if ok else "[FAIL] ") + label)
    if not ok:
        bad += 1
        if hint:
            print("       -> " + hint)


report(sys.version_info >= (3, 10), f"Python {sys.version.split()[0]} (need 3.10+)", "Install a newer Python from python.org")
for mod, pkg in (("flask", "Flask"), ("pymysql", "PyMySQL"), ("bcrypt", "bcrypt"),
                 ("cryptography", "cryptography"), ("dotenv", "python-dotenv")):
    try:
        importlib.import_module(mod); report(True, f"package {pkg} installed")
    except ImportError:
        report(False, f"package {pkg} missing", "Activate the venv, then run: pip install -r requirements.txt")
report(os.path.exists(os.path.join(ROOT, ".env")), ".env file exists",
       "Copy .env.example to .env and type your MySQL password after DB_PASSWORD=")

try:
    from config import Config
    import pymysql
    report(bool(Config.DB_PASSWORD), "DB_PASSWORD is set in .env",
           "If your MySQL root user has a password, put it in .env (leave empty only if it has none)")
    try:
        conn = pymysql.connect(host=Config.DB_HOST, port=Config.DB_PORT, user=Config.DB_USER,
                               password=Config.DB_PASSWORD, charset="utf8mb4")
        report(True, f"connected to MySQL at {Config.DB_HOST}:{Config.DB_PORT} as {Config.DB_USER}")
        cur = conn.cursor()
        cur.execute("SELECT VERSION()"); v = cur.fetchone()[0]
        ok = "mariadb" in v.lower() or tuple(int(p) for p in v.split("-")[0].split(".")[:3]) >= (8, 0, 16)
        report(ok, f"server version {v} (need MySQL 8.0.16+)", "Install MySQL 8.0 Community Server")
        cur.execute("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema=%s", (Config.DB_NAME,))
        n = cur.fetchone()[0]
        report(n == 11, f"database '{Config.DB_NAME}' has {n} tables (need 11)",
               "Run: python scripts/setup_database.py   (or --reset if it is half-installed)")
        if n == 11:
            cur.execute(f"SELECT COUNT(*) FROM `{Config.DB_NAME}`.users WHERE user_role='Admin'")
            report(cur.fetchone()[0] >= 1, "an Admin account exists", "Run: python scripts/setup_database.py --reset")
            cur.execute(f"SELECT COUNT(*) FROM `{Config.DB_NAME}`.system_settings")
            report(cur.fetchone()[0] >= 5, "system settings exist", "Run: python scripts/setup_database.py --reset")
    except Exception as e:
        report(False, f"MySQL connection failed: {e}",
               "Start MySQL (Windows: Services > MySQL80 > Start) and check DB_USER / DB_PASSWORD in .env")
    try:
        from app import create_app
        create_app(); report(True, "the Flask app loads")
    except Exception as e:
        report(False, f"the Flask app failed to load: {e}")
except Exception as e:
    report(False, f"could not read configuration: {e}")

print("\nEverything looks fine. Run:  python run.py" if not bad else f"\n{bad} problem(s) found - fix them from the top down.")
