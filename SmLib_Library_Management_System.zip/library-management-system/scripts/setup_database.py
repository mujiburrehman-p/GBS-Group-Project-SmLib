"""Create the SmLib database WITHOUT needing the `mysql` command line.

  python scripts/setup_database.py              first-time install (schema + admin + sample data)
  python scripts/setup_database.py --no-sample  install without the demo books/members
  python scripts/setup_database.py --reset      DELETE the database and install again from scratch

Uses the DB_HOST / DB_USER / DB_PASSWORD / DB_NAME values from your .env file.
"""
import argparse
import os
import sys

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
sys.path.insert(0, ROOT)

import pymysql                      # noqa: E402
from config import Config           # noqa: E402


def split_sql(text):
    """Split an SQL script into statements (ignores -- comments, respects quoted text)."""
    stmts, buf, quote, i = [], [], None, 0
    while i < len(text):
        ch = text[i]
        if quote:
            buf.append(ch)
            if ch == "\\" and i + 1 < len(text):
                buf.append(text[i + 1]); i += 1
            elif ch == quote:
                quote = None
        elif ch in ("'", '"', "`"):
            quote = ch; buf.append(ch)
        elif text.startswith("--", i):
            while i < len(text) and text[i] != "\n":
                i += 1
            continue
        elif ch == ";":
            s = "".join(buf).strip()
            if s:
                stmts.append(s)
            buf = []
        else:
            buf.append(ch)
        i += 1
    s = "".join(buf).strip()
    if s:
        stmts.append(s)
    return stmts


def run_file(cur, name, db_name):
    text = open(os.path.join(ROOT, "database", name), encoding="utf-8").read()
    text = text.replace("library_db", db_name)
    for stmt in split_sql(text):
        cur.execute(stmt)
    print(f"  ran database/{name}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--reset", action="store_true", help="drop the database first")
    ap.add_argument("--no-sample", action="store_true", help="skip demo data")
    args = ap.parse_args()
    db_name = Config.DB_NAME

    print(f"Connecting to MySQL at {Config.DB_HOST}:{Config.DB_PORT} as '{Config.DB_USER}' ...")
    try:
        conn = pymysql.connect(host=Config.DB_HOST, port=Config.DB_PORT, user=Config.DB_USER,
                               password=Config.DB_PASSWORD, charset="utf8mb4", autocommit=True)
    except Exception as e:
        print(f"\nCOULD NOT CONNECT: {e}\n"
              "  - Is MySQL running? (Windows: Services > MySQL80 > Start)\n"
              "  - Is DB_PASSWORD in your .env file the MySQL root password?\n"
              "  - Did you copy .env.example to .env ?")
        sys.exit(1)

    cur = conn.cursor()
    cur.execute("SELECT VERSION()")
    version = cur.fetchone()[0]
    print(f"Server version: {version}")
    if "mariadb" in version.lower():
        print("  WARNING: MariaDB detected. SmLib is designed for MySQL 8.0.16+; MariaDB may work but is untested.")
    else:
        parts = tuple(int(p) for p in version.split("-")[0].split(".")[:3])
        if parts < (8, 0, 16):
            print("\nMySQL is too old. Install MySQL 8.0.16 or newer (the schema uses CHECK constraints).")
            sys.exit(1)

    if args.reset:
        cur.execute(f"DROP DATABASE IF EXISTS `{db_name}`")
        print(f"  dropped database {db_name}")
    cur.execute("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = %s AND table_name = 'users'",
                (db_name,))
    if cur.fetchone()[0]:
        print(f"\nThe database '{db_name}' is already installed - nothing to do.\n"
              "Use  python scripts/setup_database.py --reset  to wipe it and start again.")
        return

    print("Installing ...")
    try:
        run_file(cur, "schema.sql", db_name)
        run_file(cur, "seed.sql", db_name)
        if not args.no_sample:
            run_file(cur, "sample_data.sql", db_name)
    except Exception as e:
        print(f"\nSQL ERROR: {e}\nFix the problem, then run with --reset to try again.")
        sys.exit(1)
    print("\nDONE. Start the website with:  python run.py\n"
          "Login: admin / Admin@12345" + ("" if args.no_sample else "   (also librarian / Librarian@123, aisha / Member@123)"))


if __name__ == "__main__":
    main()
