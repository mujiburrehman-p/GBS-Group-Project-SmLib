"""Create/update overdue fines for every loan that is overdue today.

Run it once a day, for example:
  Linux/Mac (cron):   0 1 * * *  cd /path/to/library-management-system && venv/bin/python scripts/update_overdue_fines.py
  Windows:            Task Scheduler -> python scripts/update_overdue_fines.py
Librarians can also press "Calculate fines for overdue loans" on the Fines page.
"""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from app import create_app, db            # noqa: E402
from app.services import fine_service, reservation_service   # noqa: E402

app = create_app()
with app.app_context():
    admin = db.one("SELECT user_id FROM users WHERE user_role = 'Admin' AND status = 'Active' ORDER BY user_id")
    if not admin:
        sys.exit("No active Admin user found - run database/seed.sql first.")
    fines = fine_service.sync_overdue(admin["user_id"])
    expired = reservation_service.expire_old()
    print(f"Overdue fines updated for {fines} loan(s); {expired} reservation hold(s) expired.")
