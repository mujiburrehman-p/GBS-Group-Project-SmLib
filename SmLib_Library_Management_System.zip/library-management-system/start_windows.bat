@echo off
REM ===== Start SmLib (after setup_windows.bat has been run once) =====
cd /d "%~dp0"
call venv\Scripts\activate
start "" http://127.0.0.1:5000
python run.py
pause
