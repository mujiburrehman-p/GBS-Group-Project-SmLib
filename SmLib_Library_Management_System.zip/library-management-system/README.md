# SmLib - Library Management Solutions

Version **2026.10.01** &middot; &copy; 2026 SmLib - Library Management Solutions. All rights reserved.

Web-based **College Library Management System** built with **Flask (Python), MySQL, HTML, CSS and JavaScript**.
It implements the project's use-case diagram (Administrator / Librarian / Member), the context-level DFD and the
11-table database (D1-D11).

## 1. Quick start

### EASIEST WAY (Windows)
1. Install **Python 3.10+** (python.org - tick *Add Python to PATH*) and **MySQL 8.0 Community Server** (remember the root password).
2. Extract the zip. Open the `library-management-system` folder (the one containing `run.py`).
3. **Double-click `setup_windows.bat`.** It creates the environment, installs packages, opens `.env` for your MySQL password,
   creates the database and starts the website at http://127.0.0.1:5000.
4. Next time, just double-click **`start_windows.bat`**.

Mac/Linux: `chmod +x start_mac_linux.sh && ./start_mac_linux.sh` (edit `.env` when asked, then run it again).

### Manual way (any system) - run every command inside the project folder
```bash
python -m venv venv
venv\Scripts\activate            # Windows cmd      (PowerShell: venv\Scripts\Activate.ps1)   (Mac/Linux: source venv/bin/activate)
pip install -r requirements.txt
copy .env.example .env           # Mac/Linux: cp .env.example .env   -> then edit DB_PASSWORD in .env
python scripts/setup_database.py # creates database + admin + sample data (no mysql command needed)
python run.py                    # open http://127.0.0.1:5000
```
Useful scripts: `python scripts/check_setup.py` (tells you what is wrong), `python scripts/setup_database.py --reset`
(wipe and reinstall), `python scripts/reset_password.py admin NewPassword123` (forgot a password).

You can still run the SQL files yourself with `mysql -u root -p < database/schema.sql` etc., but this does **not** work in
PowerShell (the `<` symbol is not supported) - use `cmd`, MySQL Workbench, or `setup_database.py`.

### Default logins

| Role | Username | Password | From |
|---|---|---|---|
| Admin | `admin` | `Admin@12345` | seed.sql (change after first login: *Manage Profile*) |
| Librarians | `mujibur`, `wasim` | `Librarian@123` | sample_data.sql |
| Staff | `abigel`, `timothy`, `kelvin` | `Member@123` | sample_data.sql |
| Students | `yakken`, `lutifyah`, `tahsin`, `irfan`, `oliver`, `george` | `Member@123` | sample_data.sql |
| Inactive (login must fail) | `emily` | `Member@123` | sample_data.sql |
| Expired membership (cannot borrow) | `harry` | `Member@123` | sample_data.sql |

All sample e-mail addresses end in `@smlib.co.uk`. The previous 45-member data set is kept in `database/sample_data_original_college.sql` (tests/test_cases.md was written for that set). See `tests/test_data_guide.md` for every record in the new set.

Students and staff can also **register** themselves on the login page (creates a *Member* account only).

## 2. What each role can do (from the Use Case Diagram)

| Use case | Admin | Librarian | Member |
|---|---|---|---|
| Login / Authenticate / Authorise role / Logout | yes | yes | yes |
| Manage Librarians (create, edit, activate/deactivate, reset password) | yes | - | - |
| Manage Books (+ authors, publishers, categories) | yes | yes | - |
| Manage Members (Students) and Manage Members (Staff), each with search and its own Add Member screen (a Staff screen can only add Staff, a Student screen only Students) | yes | yes | - |
| Issue Books / Return Books (+ renew, mark lost) | yes | yes | - |
| Manage Fines (calculate, pay, waive) and damage/loss charges | yes | yes | - |
| Reports (7 reports, PDF and CSV export, print) | yes | yes | - |
| Amount-check reports: Fines and Damaged / lost (read-only audit of amounts) | yes | - | - |
| Manage System Settings (edit values, Add New Setting) | yes | - | - |
| Manage Profile (details, password) | yes | yes | yes |
| Search Catalogue / View Book Details | yes | yes | yes |
| Reserve Book | - | (as borrower) | yes |
| View Loan Details / View Fine Details | - | (as borrower) | yes |
| My Reports: current loans, previous loans, active reservations, unpaid and paid fines & charges (PDF, print) | - | - | yes |

Data flows follow the DFD: Admin and Librarian send *manage* requests and receive reports, book/member/librarian
records and loan status; Members send search, profile and borrow (reserve) requests and receive search results,
availability, loan details and fine details.

## 3. Folder structure

```
run.py  config.py  requirements.txt  .env.example
app/
  __init__.py        application factory, error handlers, template filters
  db.py              PyMySQL helpers (raw SQL so every schema constraint is honoured)
  extensions.py      bcrypt password hashing + CSRF protection
  decorators.py      @login_required, @role_required("Admin", "Librarian")
  utils.py           validation helpers, BusinessError
  models/            one file per table (SQL queries): user, member, category, publisher, author,
                     book, loan, fine, damage_lost, reservation, setting (+ lookup.py shared by the 3 master tables)
  services/          business rules spanning several tables: loan_service, fine_service,
                     reservation_service, damage_service, id_generator
  blueprints/        routes, one package per feature (auth, dashboard, admin, members, books, catalog,
                     loans, fines, damage_lost, reservations, reports)
  templates/         Jinja2 HTML (base, auth, admin, librarian, member, errors)
  static/            css, js, img (SmLib logo)
database/            schema.sql, seed.sql, sample_data.sql
scripts/             setup_database.py, check_setup.py, reset_password.py, update_overdue_fines.py (daily job)
setup_windows.bat / start_windows.bat / start_mac_linux.sh   one-click launchers

docs/                data_dictionary.md, login_design.png
docs/diagrams/       use-case/, erd/, dfd/ (context, level 0, level-1/, level-2/)
```

## 4. Business rules implemented

* **IDs** are readable codes: U001, M001, B001, L001, F001, DL001, R001 ...
* **Issue:** member must be Active and not expired; max books per member; no duplicate loan of the same book;
  a copy must be free (copies held for a *Ready* reservation of someone else are not issuable);
  due date = today + `loan_days`. Librarians cannot issue to a Librarian - only the Admin can.
* **Return:** copy goes back to `available_copies`; if late, one fine per loan is created
  (`days late x fine_per_day`); the next *Pending* reservation becomes *Ready* and is held for `reservation_hold_days`.
* **Renew:** only after `renewal_after_days` (default 10) from the issue date, up to `max_renewals`; not when overdue or when another member is waiting for the book.
* **Reservations:** Pending -> Ready (copy held) -> Fulfilled when issued; Cancelled; Expired when the hold date passes.
  One active (Pending/Ready) reservation per member per book.
* **Fines:** pay (Cash/Card), waive part (stays Unpaid) or all (status Waived); `net_amount = fine_amount - waived_amount`.
* **Damage / Lost:** *Damaged* = +1 damaged copy, *Scrapped* = +1 scrapped copy, *Lost* = +1 lost copy (each takes the copy out of Available, or closes its loan);
  *Lost* = +1 lost copy and a borrowed copy sets the loan to Lost. A member is charged only when a loan is linked.
* **Invariant kept by the app:** `total_copies = available + issued + damaged + lost + scrapped` (the app checks `total >= available + damaged + lost + scrapped` before saving a record and the database enforces it with `chk_books_counts`).
* **Settings** (loan_days, fine_per_day, max_books_per_member, max_renewals, reservation_hold_days, renewal_after_days) are editable by the Admin.

Run `python scripts/update_overdue_fines.py` daily (cron / Task Scheduler) to create fines for loans that are overdue
but not yet returned, and to expire old reservation holds.

## 5. Notes about the database script

`database/schema.sql` is your `library_schema.docx` with **three fixes** so it runs in MySQL:
1. `chk_books_counts`: `(vailable_copies` -> `(available_copies`
2. `chk_dl_paid` (damage_lost): missing closing bracket and comma
3. `chk_fines_paid` (fines): missing comma after the previous constraint and a missing closing bracket

No table or column design was changed. The one-active-reservation-per-member-per-book rule is not a schema constraint,
so it is enforced in `reservation_service.py`.

## 6. Security

Passwords are bcrypt-hashed; every POST form carries a CSRF token; pages are protected by role decorators;
all SQL uses parameters; sessions are HTTP-only. For real use, set a long random `SECRET_KEY`, change the admin
password and run behind HTTPS.

## 6b. Browser Back, Forward and Refresh

* Opening, refreshing or going Back/Forward to a page only **reads** the database. Nothing is inserted, updated or deleted by a page view (this includes the dashboard and the reservation pages).
* Every change is a `POST` from a button/form (and a confirmation dialog for deletes, waivers, cancellations and status changes). After a successful change the server answers with a redirect (**Post/Redirect/Get**), so pressing Refresh never repeats the change.
* Forms cannot be sent twice (the buttons are disabled after the first click). Failed actions are rolled back and a clear message is shown on the page you were on. Failed registrations stay on the Register screen with your details kept (passwords cleared).
* Pages are sent with `Cache-Control: no-store`, so Back/Forward always show the latest data from MySQL.
* Expired reservation holds are released when staff press **Release expired holds** on the Reservations page, or automatically when a loan is issued/returned or a reservation is made/cancelled. Lapsed holds are shown as *Expired* and no longer block copies in the meantime.
* Test it: `python tests/test_navigation_safety.py`

## 7. Known limits

Lists show up to 500 rows (no paging); one author/category per book; individual copies have no barcode
(book rows hold copy counts); no e-mail notifications.

## 8. Troubleshooting

| Message / problem | Fix |
|---|---|
| `Could not open requirements file` | You are not inside the project folder. `cd` into the folder that contains `requirements.txt`. |
| `python is not recognized` | Reinstall Python and tick *Add Python to PATH*; reopen the terminal. |
| PowerShell: *running scripts is disabled* | Use `cmd` instead, or run `Set-ExecutionPolicy -Scope Process Bypass` first. |
| `mysql is not recognized` | Not needed any more - use `python scripts/setup_database.py`. |
| `Access denied for user 'root'` / `COULD NOT CONNECT` | Wrong `DB_PASSWORD` in `.env`, or MySQL is not running (Windows: Services > MySQL80 > Start). |
| `Unknown database 'library_db'` | The database was not created: run `python scripts/setup_database.py`. |
| `MySQL is too old` / syntax error near CHECK | Install MySQL 8.0.16 or newer. |
| `ModuleNotFoundError` | Activate the venv (`(venv)` shows in the prompt) and run `pip install -r requirements.txt`. |
| Cannot log in as admin | Run `python scripts/reset_password.py admin NewPassword123`. |
| `Address already in use` (port 5000) | Close the other program using it, or change the port in `run.py`: `app.run(debug=True, port=5001)`. |
| Anything else | Run `python scripts/check_setup.py` and read the first `[FAIL]` line. |
